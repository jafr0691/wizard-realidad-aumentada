# waleads
Plugins wp Muestra un boton flotante en el front-end con los diferentes canales sociales y captura los datos del cliente. Tiene panel adminitrativo para configurar los correos de los agente que asisten, como se va a mostrar el boton, el formulario de los canales, muestra los reportes por cada uno de los agantes que asisten a los cliente.
