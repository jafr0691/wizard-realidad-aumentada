<?php
global $wpdb;
if ($_POST['acti'] == 'ip') {

    $visitor  = getIp();
    $datocode = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=" . $visitor));
    $code     = $datocode["geoplugin_countryCode"];
    $pais     = $datocode["geoplugin_countryName"];
    $region   = $datocode["geoplugin_city"];
    $data     = array('ip' => $visitor, 'code' => $code, 'pais' => $pais, 'region' => $region);
    exit(json_encode($data));

} else if ($_POST['acti'] == 'sqlformulario') {

    if (isset($_POST['ifformulario'])) {
        $ifformulario = (empty($_POST['ifformulario'])) ? 0 : $_POST['ifformulario'];
        $wpdb->update($wpdb->prefix . 'sw_formulario',
            array('ifformulario' => $ifformulario),
            array('id_formulario' => 1));

        exit($ifformulario);
    } else {

        $ifcorreo   = $_POST['ifcorreo'];
        $asunto     = $_POST['asunto'];
        $mensaje    = $_POST['mensajecorreo'];
        $ifalert    = $_POST['ifalert'];
        $ifurl      = $_POST['ifurl'];
        $logo    = $_POST['logo'];
        $imagen      = $_POST['imagen'];
        $ifcookies  = $_POST['ifcookies'];
        $alert      = $_POST['alert'];
        $saludo     = $_POST['saludo'];
        $wsp        = $_POST['wsp'];
        $msg        = $_POST['msg'];
        $tlf        = $_POST['tlf'];
        $sms        = $_POST['sms'];
        $tlg        = $_POST['tlg'];
        $skp        = $_POST['skp'];
        $pregunta   = $_POST['pregunta'];
        $opcion1    = $_POST['opcion1'];
        $opcion2    = $_POST['opcion2'];
        $opcion3    = $_POST['opcion3'];
        $opcion4    = $_POST['opcion4'];
        $opcion5    = $_POST['opcion5'];
        $opcion6    = $_POST['opcion6'];
        $opcion7    = $_POST['opcion7'];
        $opcion8    = $_POST['opcion8'];
        $opcion9    = $_POST['opcion9'];
        $opcion10   = $_POST['opcion10'];
        $iflisttext = $_POST['iflisttext'];
        $boton      = $_POST['boton'];
        $wpdb->update($wpdb->prefix . 'sw_formulario',
            array('ifalert' => $ifalert,
                'asunto'        => $asunto,
                'mensaje'       => $mensaje,
                'logo'          => $logo,
                'imagen'        => $imagen,
                'ifcorreo'      => $ifcorreo,
                'ifurl'         => $ifurl,
                'ifcookies'     => $ifcookies,
                'alert'         => $alert,
                'saludo'        => $saludo,
                'wsp'           => $wsp,
                'msg'           => $msg,
                'tlf'           => $tlf,
                'sms'           => $sms,
                'tlg'           => $tlg,
                'skp'           => $skp,
                'ifalert'       => $ifalert,
                'pregunta'      => $pregunta,
                'opcion1'       => $opcion1,
                'opcion2'       => $opcion2,
                'opcion3'       => $opcion3,
                'opcion4'       => $opcion4,
                'opcion5'       => $opcion5,
                'opcion6'       => $opcion6,
                'opcion7'       => $opcion7,
                'opcion8'       => $opcion8,
                'opcion9'       => $opcion9,
                'opcion10'      => $opcion10,
                'iflisttext'    => $iflisttext,
                'boton'         => $boton),
            array('id_formulario' => 1));

        exit(true);
    }
    exit($_POST);
} else if ($_POST['acti'] == 'sqlphpmailer') {
    $setfrom      = $_POST['setfrom'];
    $titlesetfrom = $_POST['titlesetfrom'];
    $codemailer   = $_POST['codemailer'];
    $numeromailer = $_POST['numeromailer'];
    $addreplyto   = $_POST['addreplyto'];
    $titlereplyto = $_POST['titlereplyto'];

    try {
        $wpdb->update($wpdb->prefix . 'sw_phpmailer',
            array('setfrom' => $setfrom, 'titlesetfrom' => $titlesetfrom, 'codemailer' => $codemailer, 'numeromailer' => $numeromailer, 'addreplyto' => $addreplyto, 'titlereplyto' => $titlereplyto),
            array('id' => 1));
        exit(true);
    } catch (Exception $e) {
        exit(false);
    }

} else if ($_POST['acti'] == 'sqlmailchimp') {
    try {

        $api_key = $_POST['api_key'];
        $list_id = $_POST['list_id'];
        $wpdb->update($wpdb->prefix . 'sw_mailchimp',
            array('api_key' => $api_key,
                'list_id'       => $list_id),
            array('id_mailchimp' => 1));

        exit(true);

    } catch (Exception $e) {
        exit(false);
    }
} else if ($_POST['acti'] == 'suspender') {
    $id  = $_POST['id'];
    $ida = $wpdb->get_row("SELECT turno,nombre FROM " . $wpdb->prefix . "sw_agente where id_agente=" . $id);

    if ($ida->turno === "2") {
        $turno = 0;
    } else {
        $turno = 2;
    }
    $wpdb->update($wpdb->prefix . 'sw_agente',
        array('turno' => $turno),
        array('id_agente' => $id));

    $dato = array('turno' => $turno, 'id' => $id);

    exit(json_encode($dato));
} else if ($_POST['acti'] == 'btn-signupr') {

    $errors = array();

    if (!empty($_POST)) {
        $nombre       = $_POST['nombre'];
        $password     = $_POST['password'];
        $con_password = $_POST['con_password'];
        $email        = $_POST['email'];
        $code         = $_POST['code'];
        $linkmsg      = $_POST['msg'];
        $numero       = $_POST['numero'];
        $codesms         = $_POST['codesms'];
        $numsms       = $_POST['sms'];
        $codetlf         = $_POST['codellamada'];
        $numtlf       = $_POST['tlf'];
        $usertlg      = $_POST['tlg'];
        $userskp      = $_POST['skp'];
        $tipo         = $_POST['tipo'];
        $activo       = 1;

        if (isNull($nombre, $password, $con_password, $email, $numero)) {
            $errors[] = "Debe llenar todos los campos";
        }

        if (!isEmail($email)) {
            $errors[] = "Dirección de correo inválida";
        }

        if (numeroExiste($numero)) {
            $errors[] = "Numero ya exite";
        }

        if (!validaPassword($password, $con_password)) {
            $errors[] = "Las contraseñas no coinciden";
        }

        if (emailExiste($email)) {
            $errors[] = "El correo electronico $email ya existe";
        }

        if (count($errors) == 0) {

            $pass_hash = hashPassword($password);
            $token     = generateToken();

            $registro = registraUsuario($pass_hash, $nombre, $email, $code, $numero, $linkmsg, $codetlf, $numtlf, $codesms, $numsms, $userskp, $usertlg, $activo, $token, $tipo);
            if ($registro > 0) {
                $data = true;
                exit($data);

            } else {
                $errors[] = "Error al Registrar";
            }

        }
    }

    exit(resultBlock($errors));
} else if ($_POST['acti'] == 'verEdiAgent') {

    $ida = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_agente ag INNER JOIN " . $wpdb->prefix . "sw_jornada jo where ag.id_agente=" . $_POST['agente'] . " AND ag.id_agente=jo.id_agente");

    if ($ida->tipo == 1) {
        $tipo = "Admin";
    } else {
        $tipo = "Vendedor";
    }
    $dato = array('id' => $ida->id_agente,
        'nombre'           => $ida->nombre,
        'email'            => $ida->email,
        'msg'              => $ida->linkmsg,
        'code'             => $ida->code,
        'numero'           => $ida->numero,
        'codetlf'             => $ida->codetlf,
        'numtlf'           => $ida->numtlf,
        'codesms'             => $ida->codesms,
        'numsms'           => $ida->numsms,
        'usertlg'          => $ida->usertlg,
        'userskp'          => $ida->userskp,
        'tipo'             => $tipo,
        'entrada'          => $ida->entrada,
        'salida'           => $ida->salida);

    exit(json_encode($dato));

} else if ($_POST['acti'] == 'savEditAgente') {
    try {
        $id = $_POST['id'];

        $nombre  = $_POST['nombre'];
        $numero  = $_POST['numero'];
        $linkmsg = $_POST['msged'];
        $codetlf    = $_POST['codellamadaed'];
        $numtlf  = $_POST['tlfed'];
        $codesms    = $_POST['codesmsed'];
        $numsms  = $_POST['smsed'];
        $userskp = $_POST['skped'];
        $usertlg = $_POST['tlged'];
        $email   = $_POST['email'];
        $code    = $_POST['code'];
        $entrada = ($_POST['entrada'] >= 24) ? 23 : $_POST['entrada'];
        $salida  = ($_POST['salida'] >= 24) ? 23 : $_POST['salida'];

        if ($entrada >= $salida) {
            exit(json_encode(array('isif' => false, 'msj' => esc_html__('La hora de entrada y salida no son validas', 'wa-leads'))));
        }

        if (!emailExiste($email)) {
            $wpdb->update($wpdb->prefix . 'sw_agente',
                array('email' => $email),
                array('id_agente' => $id));
        }
        if (!numeroExiste($numero)) {
            $wpdb->update($wpdb->prefix . 'sw_agente',
                array('numero' => $numero),
                array('id_agente' => $id));
        }
        if (isset($_POST['tipo'])) {
            $wpdb->update($wpdb->prefix . 'sw_agente',
                array('tipo' => $_POST['tipo']),
                array('id_agente' => $id));
        }
        $wpdb->update($wpdb->prefix . 'sw_agente',
            array('nombre' => $nombre, 'code' => $code, 'linkmsg' => $linkmsg,'codetlf' => $codetlf, 'numtlf' => $numtlf,'codesms' => $codesms, 'numsms' => $numsms, 'usertlg' => $usertlg, 'userskp' => $userskp),
            array('id_agente' => $id));

        $wpdb->update($wpdb->prefix . 'sw_jornada',
            array('entrada' => $entrada, 'salida' => $salida),
            array('id_agente' => $id));
        exit(json_encode(array('isif' => true, 'msj' => esc_html__('Los datos del usuario fueron cambiados exitosamente', 'wa-leads'))));
    } catch (Exception $e) {
        exit(json_encode(array('isif' => false, 'msj' => esc_html__('ERROR: No se logro guardar los cambios', 'wa-leads'))));
    }
} else if ($_POST['acti'] == 'verAgente') {

    $agentee  = $_POST['agente'];
    $agenJorn = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_agente ag INNER JOIN " . $wpdb->prefix . "sw_jornada jo where ag.id_agente=" . $agentee . " AND ag.id_agente=jo.id_agente");

    if ($agenJorn->tipo == 1) {
        $tipo = "Admin";
    } else {
        $tipo = "Vendedor";
    }
    $a    = array('nombre' => $agenJorn->nombre, 'email' => $agenJorn->email, 'linkmsg' => $agenJorn->linkmsg, 'code' => $agenJorn->code, 'numero' => $agenJorn->numero,'codetlf' => $agenJorn->codetlf, 'numtlf' => $agenJorn->numtlf,'codesms' => $agenJorn->codesms, 'numsms' => $agenJorn->numsms, 'usertlg' => $agenJorn->usertlg, 'userskp' => $agenJorn->userskp, 'turno' => $agenJorn->turno, 'tipo' => $tipo, 'activacion' => $agenJorn->activacion, 'entrada' => $agenJorn->entrada, 'salida' => $agenJorn->salida, 'fechainicio' => date("d/m/Y", strtotime($agenJorn->fechainicio)), 'id' => $agenJorn->id_agente);
    $i    = 0;
    $serv = $wpdb->get_results("SELECT DISTINCT fecha FROM " . $wpdb->prefix . "sw_contactos_whatsapp where id_agente=" . $agentee . " ORDER BY id_contactos DESC");

    if (!empty($serv)) {
        foreach ($serv as $servi) {
            $fechadifer = $servi->fecha;
            $cantserv   = $wpdb->get_row("SELECT COUNT(fecha) as cantidad FROM " . $wpdb->prefix . "sw_contactos_whatsapp where id_agente=" . $agentee . " and fecha='{$fechadifer}'");

            $s[$i] = array('fechaver' => date("d/m/Y", strtotime($servi->fecha)), 'fecha' => $servi->fecha, 'cantidad' => $cantserv->cantidad, 'nu' => $i + 1);
            $i++;
        }
    }

    $datos = array('agente' => $a, 'servicio' => $s);
    exit(json_encode($datos));

} else if ($_POST['acti'] == 'deletAgente') {

    $wpdb->delete($wpdb->prefix . 'sw_agente', array('id_agente' => $_POST['id']));
    $wpdb->delete($wpdb->prefix . 'sw_jornada', array('id_agente' => $_POST['id']));
    $wpdb->delete($wpdb->prefix . 'sw_contactos_whatsapp', array('id_agente' => $_POST['id']));
} else if ($_GET['acti'] == 'reporte') {

    $id    = $_GET['id'];
    $fecha = $_GET['fecha'];
    $num   = 1;
    if ($fecha == 11) {
        $reporcontac = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "sw_contactos_whatsapp where id_agente={$id} ORDER BY id_contactos DESC");
    } else {
        $reporcontac = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "sw_contactos_whatsapp where id_agente={$id} and fecha='{$fecha}' ORDER BY id_contactos DESC");
    }
    $agente = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_agente where id_agente={$id}");

    $html = '<div>';
    if ($fecha == 11) {
        $html .= '<h4>Reporte de los Contactos:</h4>';
    } else {
        $html .= '<h4>Reporte de los Contactos Fecha: <strong>' . date("d/m/Y", strtotime($fecha)) . '</strong></h4>';
    }
    $html .= '<p>Datos del Cliente que los recibio:</p>
<p>Nombre: <strong>' . $agente->nombre . '</strong>, Numero: <strong>' . $agente->numero . '</strong>, Email: <strong>' . $agente->email . '</strong>.</p>
<table class="espacios">
<thead>
<tr>
<th style="width: 20px;">#</th>
<th style="width: 80px">Nombre</th>
<th style="width: 50px">Numero</th>
<th style="width: 70px">Correo</th>
<th style="width: 100px">Mensaje</th>
<th style="width: 100px">Url</th>
<th style="width: 80px">Canal</th>
<th style="width: 50px">Pais</th>
<th style="width: 50px">Hora</th>';
    if ($fecha == 11) {
        $html .= '<th style="width: 50px">Fecha</th>';
    }

    $html .= '</tr>
</thead>
<tbody>';

    foreach ($reporcontac as $datos) {

        $html .= '<tr>
	<td style="width: 20px">' . $num . '</td>
	<td style="width: 80px">' . $datos->nombre . '</td>
	<td style="width: 50px"><a href="https://api.whatsapp.com/send?phone=' . $datos->numero . '" target="_blank">' . $datos->numero . '</a></td>
	<td style="width: 70px; white-space: initial;">' . $datos->correo . '</td>
	<td style="width: 100px">' . $datos->msg . '</td>
	<td style="width: 100px">' . $datos->url . '</td>
	<td style="width: 80px">' . $datos->canal . '</td>
	<td style="width: 50px">' . $datos->pais . '</td>
	<td style="width: 50px">' . $datos->hora . '</td>';
        if ($fecha == 11) {
            $html .= '<td style="width: 50px">' . date("d/m/Y", strtotime($datos->fecha)) . '</td>';
        }

        $html .= '</tr>';

        $num++;
    }

    $html .= '</tbody>
// </table>';
    $mpdf    = new \Mpdf\Mpdf();
    $estilos = file_get_contents(DOCUMENTOturno . "admin/estilos.css");
    $mpdf->SetDisplayMode('fullpage');
    $mpdf->WriteHTML($estilos, 1);
    $mpdf->WriteHTML($html);
    $mpdf->Output();

}
