<?php

global $wpdb;
$n   = absint($_POST['conteo']);
$num = $_POST['num'];

$hora = date('G');
$f    = date("m/d/Y");

$jornada = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "sw_jornada");

foreach ($jornada as $jornagente) {

    $agentetu = $wpdb->get_row("SELECT turno FROM " . $wpdb->prefix . "sw_agente where id_agente=" . $jornagente->id_agente);

    if ($agentetu->turno != 2) {

            if ($hora >= $jornagente->entrada and $hora <= $jornagente->salida) {
                $wpdb->update($wpdb->prefix . "sw_agente",
                    array(
                        'turno' => 1,
                    ),
                    array('id_agente' => $jornagente->id_agente)
                );
            } else {
                $wpdb->update($wpdb->prefix . "sw_agente",
                    array(
                        'turno' => 0,
                    ),
                    array('id_agente' => $jornagente->id_agente)
                );
            }
    }
}

$tc  = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_conteo");
$acn = $wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix . "sw_agente where turno=1");

$deturno = $tc->turno + $n;

if ($deturno > $acn) {
    $deturno = 1;
}
$wpdb->update($wpdb->prefix . "sw_conteo",
    array(
        'turno' => $deturno,
    ),
    array('id' => $tc->id)
);

$numeros = $wpdb->get_results("SELECT code,numero,id_agente,nombre,email,linkmsg,codesms,numsms,codetlf,numtlf,userskp,usertlg FROM " . $wpdb->prefix . "sw_agente where turno=1");
$ifformulario = $wpdb->get_row("SELECT ifformulario,ifalert,ifurl,ifcookies,wsp,msg,tlf,sms,tlg,skp FROM " . $wpdb->prefix . "sw_formulario where id_formulario=1");

$i       = 1;
$listnum = [];
foreach ($numeros as $tlf) {
    $listnum[$i] = $tlf->numero;
    $listcode[$i] = $tlf->code;
    $listnombre[$i] = $tlf->nombre;
    $listemail[$i] = $tlf->email;
    $listelinkmsg[$i] = $tlf->linkmsg;
    $listeuserskyp[$i] = $tlf->userskp;
    $listeusertlg[$i] = $tlf->usertlg;
    $listenumtlf[$i] = $tlf->codetlf.$tlf->numtlf;
    $listenumsms[$i] = $tlf->codesms.$tlf->numsms;
    $i++;
}
$numerotlf = trim($listnum[$deturno]);
$codetlf = trim($listcode[$deturno]);
$nombre = $listnombre[$deturno];
$email = $listemail[$deturno];
$linkmsg = $listelinkmsg[$deturno];
$numsms = trim($listenumsms[$deturno]);
$numtlf = trim($listenumtlf[$deturno]);
$userskp = $listeuserskyp[$deturno];
$usertlg = $listeusertlg[$deturno];
$dato = array("code"=>$codetlf, "numero"=>$numerotlf, "nombre"=>$nombre,"correoreceptor"=>$email,"linkmsg"=>$linkmsg,"numsms"=>$numsms,"numtlf"=>$numtlf,"usertlg"=>$usertlg,"userskp"=>$userskp, "ifformulario"=>$ifformulario->ifformulario, "ifalert"=>$ifformulario->ifalert, "ifurl"=>$ifformulario->ifurl, "ifcookies"=>$ifformulario->ifcookies,"wsp"=>$ifformulario->wsp ,"msg"=>$ifformulario->msg ,"tlf"=>$ifformulario->tlf ,"sms"=>$ifformulario->sms,"tlg"=>$ifformulario->tlg,"skp"=>$ifformulario->skp );
exit(json_encode($dato));