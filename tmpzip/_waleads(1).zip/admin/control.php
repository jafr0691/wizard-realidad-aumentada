    <link rel="stylesheet"  type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!--datables CSS b¨¢sico-->
    <link rel="stylesheet" type="text/css" href="<?php echo ARCHIVOturno; ?>js/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->
    <link rel="stylesheet"  type="text/css" href="<?php echo ARCHIVOturno; ?>js/DataTables-1.10.20/css/dataTables.bootstrap4.css">
    <style type="text/css">
      table tr {
        text-align: center;
      }
      #wpfooter{
          display:none;
      }
    </style>

    <?php

$hora        = date('G');
$h           = date("h:i:s A");
$f           = date("d/m/Y");
$dbphpmailer = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_phpmailer where id=1");

$dbformulario = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_formulario where id_formulario=1");

$dbmailchimp = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_mailchimp where id_mailchimp=1");

?>

    <div class="container" id="listaagente">
            <div class="row">
                <div class="col-sm-3 form-inline">
                    <buttom type="buttom" class="btn btn-success" data-target="#Modalphpmailer" data-toggle="modal">
                        <?php esc_html_e('Configuracion de envios de correo', 'wa-leads');?>
                    </buttom>
                </div>
                <div class="col-sm-2 form-inline">
                    <buttom class="btn btn-success" data-target="#Modalr" data-toggle="modal">
                        <?php esc_html_e('Registrar Agente', 'wa-leads');?>
                    </buttom>
                </div>
                <div class="col-sm-3 form-inline">
          <buttom class="btn btn-success" data-toggle="modal" id="btn-formulario" <?php if ($dbformulario->ifformulario == 0) {echo "disabled='disabled'";}?> data-target="#Modalformulario"><?php esc_html_e('Configurar Formulario', 'wa-leads');?></buttom>
          <input type="checkbox" name="ifformulario" id="ifformulario" class="form-control" value="1" <?php if ($dbformulario->ifformulario == 1) {echo "checked='true''";}?>>
        </div>
                <div class="col-sm-2 form-inline">
          <buttom class="btn btn-success" data-toggle="modal" id="btn-mailchimp" <?php if (($dbformulario->ifcorreo == 0) or ($dbformulario->ifformulario == 0)) {echo "disabled='disabled'";}?> data-target="#Modalmailchimp"><?php esc_html_e('Api Mailchimp', 'wa-leads');?></buttom>
        </div>
                <div class="col-sm-2 text-right">
                    <strong class="btn btn-danger" id="logout" style="display:none;">
                        <?php esc_html_e('Cerrar Sesión', 'wa-leads');?>
                    </strong>
                </div>
                <br>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <strong>
                        <?php esc_html_e('Fecha Actual:', 'wa-leads');?>
                    </strong>
                    <?php echo $f . " " . $h; ?>
                </div>
                <br>

            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="datatablecontrol" style="width:100%">
                            <thead>
                                <tr>
                                    <th scope="col">
                                        <?php esc_html_e('ID', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Nombre', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Email', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('WhatsApp', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Estado', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Suspender', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Editar', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Ver', 'wa-leads');?>
                                    </th>
                                    <th scope="col">
                                        <?php esc_html_e('Eliminar', 'wa-leads');?>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="listbusqueda">
                                <?php
$lista = $wpdb->
    get_results("SELECT * FROM " . $wpdb->prefix . "sw_agente");

foreach ($lista as $agentes) {

    ?>
                                <tr id="list">
                                    <th scope="row">
                                        <?php echo $agentes->id_agente; ?>
                                    </th>
                                    <td>
                                        <?php echo $agentes->nombre; ?>
                                    </td>
                                    <td>
                                        <?php echo $agentes->email; ?>
                                    </td>
                                    <td>
                                        <?php echo $agentes->code . $agentes->numero; ?>
                                    </td>
                                    <td id="turno<?php echo $agentes->id_agente; ?>">
                                        <?php if ($agentes->turno == 0) {
        echo "<div class='btn-danger'>";
        esc_html_e('Inactivo', 'wa-leads');
        echo "</div>";
    } else if ($agentes->turno == 1) {
        echo "<div class='btn-success'>";
        esc_html_e('Activo', 'wa-leads');
        echo "</div>";
    } else {
        echo "<div class='btn-warning'>";
        esc_html_e('Suspendido', 'wa-leads');
        echo "</div>";
    }?>
                                    </td>
                                    <td>
                                        <span class="glyphicon glyphicon-off btn text-warning" onclick="suspender(<?php echo $agentes->id_agente; ?>)">
                                        </span>
                                    </td>
                                    <td>
                                        <span class="glyphicon glyphicon-edit btn text-primary" onclick="editar(<?php echo $agentes->id_agente; ?>)">
                                        </span>
                                    </td>
                                    <td>
                                        <span class="glyphicon glyphicon-list-alt btn text-success" onclick="ver(<?php echo $agentes->id_agente; ?>)">
                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-danger btn delet glyphicon glyphicon-trash" data-id="<?php echo $agentes->id_agente; ?>" data-name="<?php echo $agentes->nombre; ?>" data-target="#Modaldelet" data-toggle="modal" id="delet<?php echo $agentes->id_agente; ?>" title="Eliminar">
                                        </span>
                                    </td>
                                </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<div id="Modalr" class="modal fade" role="dialog">
 <div class="modal-dialog">

  <!-- Modal content-->
  <div class="modal-content">
   <div class="modal-body">
    <div class="panel panel-info">
     <div class="panel-heading">
      <div class="panel-title"><?php esc_html_e('Reg&iacute;strate', 'wa-leads');?></div>
    </div>
    <form id="formregistre">
      <div class="panel-body" >
       <div class="form-horizontal">

        <div class="form-group">
         <label for="nombre" class="col-md-3 control-label"><?php esc_html_e('Nombre:', 'wa-leads');?></label>
         <div class="col-md-9">
          <input type="text" class="form-control" id="nombrer" name="nombre" placeholder="<?php esc_html_e('Nombre', 'wa-leads');?>" value="<?php if (isset($nombre)) {
    echo $nombre;
}
?>" required  autocomplete="off">
       </div>
     </div>

     <div class="form-group">
       <label for="numero" class="col-md-3 control-label"><?php esc_html_e('WhatsApp:', 'wa-leads');?></label>
       <div class="col-md-9" style="display: flex;">
        <div style="width:150px;">
         <select name="code" class="form-control" required="" id="code">
          <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
        </select>
      </div>
      <input type="text" class="form-control" id="numero" name="numero" onkeyUp="return ValNumero(this);" placeholder="<?php esc_html_e('Numero de Whatsapp', 'wa-leads');?>" required autocomplete="off">
    </div>
  </div>

  <div class="form-group">
   <label for="email" class="col-md-3 control-label"><?php esc_html_e('Email', 'wa-leads');?></label>
   <div class="col-md-9">
    <input type="email" class="form-control" id="emailr" name="email" placeholder="<?php esc_html_e('Email', 'wa-leads');?>" value="<?php if (isset($email)) {
    echo $email;
}
?>" required autocomplete="off">
 </div>
</div>
<div class="form-group">
   <label for="msgr" class="col-md-3 control-label"><?php esc_html_e('Link Messenger', 'wa-leads');?></label>
   <div class="col-md-9">
    <input type="text" class="form-control" id="msgr" name="msg" placeholder="<?php esc_html_e('Messenger', 'wa-leads');?>" autocomplete="off">
 </div>
</div>
<div class="form-group">
   <label for="tlfr" class="col-md-3 control-label"><?php esc_html_e('Numero Llamada', 'wa-leads');?></label>
   <div class="col-md-9" style="display: flex;">
        <div style="width:150px;">
         <select name="codellamada" class="form-control" required="" id="codellamada">
          <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
        </select>
      </div>
    <input type="text" class="form-control" id="tlfr" name="tlf" placeholder="<?php esc_html_e('Numero telefonico', 'wa-leads');?>" autocomplete="off">
 </div>
</div>
<div class="form-group">
   <label for="smsr" class="col-md-3 control-label"><?php esc_html_e('Numero SMS', 'wa-leads');?></label>
   <div class="col-md-9" style="display: flex;">
        <div style="width:150px;">
         <select name="codesms" class="form-control" required="" id="codesms">
          <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
        </select>
      </div>
    <input type="text" class="form-control" id="smsr" name="sms" placeholder="<?php esc_html_e('Numero para Mensajes', 'wa-leads');?>" autocomplete="off">
 </div>
</div>
<div class="form-group">
   <label for="tlgr" class="col-md-3 control-label"><?php esc_html_e('Usuario de Telegram', 'wa-leads');?></label>
   <div class="col-md-9">
    <input type="text" class="form-control" id="tlgr" name="tlg" placeholder="<?php esc_html_e('Telegram', 'wa-leads');?>" autocomplete="off">
 </div>
</div>
<div class="form-group">
   <label for="skpr" class="col-md-3 control-label"><?php esc_html_e('Usuario de Skype', 'wa-leads');?></label>
   <div class="col-md-9">
    <input type="text" class="form-control" id="skpr" name="skp" placeholder="<?php esc_html_e('Skype', 'wa-leads');?>" autocomplete="off">
 </div>
</div>
<div class="form-group">
 <label for="password" class="col-md-3 control-label"><?php esc_html_e('Contraseña', 'wa-leads');?></label>
 <div class="col-md-9">
  <input type="password" class="form-control" id="passr" name="password" placeholder="<?php esc_html_e('Contraseña', 'wa-leads');?>"  autocomplete="off">
</div>
</div>

<div class="form-group">
 <label for="con_password" class="col-md-3 control-label"><?php esc_html_e('Confirmar Contraseña', 'wa-leads');?></label>
 <div class="col-md-9">
  <input type="password" class="form-control" id="con_passr" name="con_password" placeholder="<?php esc_html_e('Confirmar Contraseña', 'wa-leads');?>" required autocomplete="off">
</div>
</div>
<div class="form-group">
 <label for="tipo" class="col-md-3 control-label"></label>
 <div class="col-md-9 form-inline">
  Admin
  <input type="radio" class="form-control" id="tipo" name="tipo" required value="1">

  Vendedor
  <input type="radio" class="form-control" id="tipo" name="tipo" required value="0" checked>
</div>
</div>


<div class="form-group">
 <div class="col-md-offset-3 col-md-9">
  <button id="btn-signupr" class="btn btn-info"><span class="glyphicon glyphicon-save"></span> <?php esc_html_e('Registrar', 'wa-leads');?></button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="cargar" width="100px" height="60px">
</div>
</div>
</div>
<div id="errorregist"></div>
</div>
</form>
</div>
</div>
<div class="modal-footer">
  <button class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>

</div>
</div>
<div class="modal fade" id="Modalregistro" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">

    <h4 class="modal-title" id="titlemsj"></h4>
  </div>
  <div class="modal-body text-center" id="imp1">
    <p id="mensaje">El agente: <strong id="Modalemailr"></strong><?php esc_html_e(' fue regiestrado con existo', 'wa-leads');?></p>
  </div>
  <div class="modal-footer">
    <button class="btn btn-success" id="aceptarregistre" data-dismiss="modal"><?php esc_html_e('Aceptar', 'wa-leads');?></button>
    <div id="btnmodal"></div>
  </div>
</div>
</div>
</div>

<div id="Modalphpmailer" class="modal fade" role="dialog">
 <div class="modal-dialog">

  <!-- Modal content-->
  <div class="modal-content">
   <div class="modal-body">
    <div class="panel panel-info">
     <div class="panel-heading">
      <div class="panel-title"><?php esc_html_e('Configuracion de envio de correo', 'wa-leads');?></div>
    </div>
    <form id="formphpmailer">
      <div class="panel-body" >
       <div class="form-horizontal">

        <div id="signupalert" style="display:none" class="alert alert-danger">
         <p><?php esc_html_e('Error:', 'wa-leads');?></p>
         <span></span>
       </div>
<div class="form-group">
     <label for="setfrom" class="col-md-5 control-label"><?php esc_html_e('Email', 'wa-leads');?></label>
     <div class="col-md-7">
      <input type="text" class="form-control" id="setfrom" name="setfrom" placeholder="<?php esc_html_e('Escribir Email', 'wa-leads');?>" value="<?php if (isset($dbphpmailer->setfrom)) {
    echo $dbphpmailer->setfrom;
}
?>" required autocomplete="off">
    </div>
    </div>
   <div class="form-group">
     <label for="titlesetfrom" class="col-md-5 control-label"><?php esc_html_e('Nombre de email', 'wa-leads');?></label>
     <div class="col-md-7">
      <input type="text" class="form-control" id="titlesetfrom" name="titlesetfrom" placeholder="<?php esc_html_e('Escribir', 'wa-leads');?>" value="<?php if (isset($dbphpmailer->titlesetfrom)) {
    echo $dbphpmailer->titlesetfrom;
}
?>" required autocomplete="off">
    </div>
    </div>

<div class="form-group">
 <label for="numero" class="col-md-5 control-label"><?php esc_html_e('Numero de whatsapp contactos pendientes:', 'wa-leads');?></label>
 <div class="col-md-7" style="display: flex;">
  <div style="width:150px;">
   <select name="codemailer" class="form-control" required="" id="codemailer">
    <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
  </select>
</div>
<input type="text" class="form-control" id="numeromailer" name="numeromailer" onkeyUp="return ValNumero(this);" placeholder="<?php esc_html_e('Numero de Whatsapp', 'wa-leads');?>" value="<?php if (isset($dbphpmailer->numeromailer)) {
    echo $dbphpmailer->numeromailer;
}
?>" required autocomplete="off">
</div>
</div>


<div class="form-group">
 <label for="addreplyto" class="col-md-5 control-label"><?php esc_html_e('Email que recibe replica', 'wa-leads');?></label>
 <div class="col-md-7">
  <input type="text" class="form-control" id="addreplyto" name="addreplyto" placeholder="<?php esc_html_e('Escribir correo', 'wa-leads');?>" value="<?php if (isset($dbphpmailer->addreplyto)) {
    echo $dbphpmailer->addreplyto;
}
?>" required autocomplete="off">
</div>
</div>

<div class="form-group">
 <label for="titlereplyto" class="col-md-5 control-label"><?php esc_html_e('Nombre de email replica', 'wa-leads');?></label>
 <div class="col-md-7">
  <input type="text" class="form-control" id="titlereplyto" name="titlereplyto" placeholder="<?php esc_html_e('Escribir', 'wa-leads');?>" value="<?php if (isset($dbphpmailer->titlereplyto)) {
    echo $dbphpmailer->titlereplyto;
}
?>" required autocomplete="off">
</div>
</div>

<div class="form-group">
 <div class="col-md-offset-3 col-md-9">
  <button id="sqlphpmailer" class="btn btn-info"><span class="glyphicon glyphicon-save"></span> <?php esc_html_e('Guardar', 'wa-leads');?></button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="cargarmailer" width="100px" height="60px">
</div>
</div>
</div>
<div id="errorsrphpmailer"></div>
</div>
</form>
</div>
</div>
<div class="modal-footer">
  <button class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>

</div>
</div>
<div id="Modalformulario" class="modal fade" role="dialog">
 <div class="modal-dialog">

  <!-- Modal content-->
  <div class="modal-content">
   <div class="modal-body">
    <div class="panel panel-info">
     <div class="panel-heading" style="height: 54px;">
      <div class="panel-title pull-left"><?php esc_html_e('Configuracion de Formulario', 'wa-leads');?></div>
      <button id="formprede" class="btn btn-secondary pull-right"><?php esc_html_e('Predeterminado', 'wa-leads');?></button>
    </div>
    <form id="formformulario" enctype="multipart/form-data">
      <div class="panel-body" >
       <div class="form-horizontal">

        <div class="form-group">
         <label for="host" class="col-md-5 control-label"><?php esc_html_e('Pedir Correo?', 'wa-leads');?></label>
         <div class="col-md-7 form-inline" id="ifcorreo">
          <?php esc_html_e('Si', 'wa-leads');?>
          <input type="radio" class="form-control" name="ifcorreo" value="1" required  autocomplete="off" <?php if ($dbformulario->ifcorreo == 1) {echo "checked='true'";}?>>
          <?php esc_html_e('No', 'wa-leads');?>
          <input type="radio" class="form-control" name="ifcorreo" value="0" required  autocomplete="off" <?php if ($dbformulario->ifcorreo == 0) {echo "checked='true'";}?>>
        </div>
      </div>
      <div id="divcorreo">
        <div class="form-group">
          <label for="logo" class="col-md-5 control-label"><?php esc_html_e('Imagenes', 'wa-leads');?></label>
          <div class="col-md-3">
            <input type="hidden" id="logoinput" name="logo" onchange="previewImage('logo','logoprev');" value="<?php if (isset($dbformulario->logo)) {
    echo $dbformulario->logo;
}
?>">
           <button type="button" class="btn btn-info" id="logo"><span class="glyphicon glyphicon-folder-open"></span>&nbsp; Logo</button><br>
           <img id="logoprev" width="100" height="90" style="margin-right:25px;" src="<?php if (isset($dbformulario->logo)) {
    echo $dbformulario->logo;
}
?>">
</div>
<div class="col-md-3">
        <input type="hidden" id="imageninput" name="imagen" onchange="previewImage('imagen','imagenprev');" value="<?php if (isset($dbformulario->imagen)) {
    echo $dbformulario->imagen;
}
?>">
         <button type="button" class="btn btn-info" id="imagen"><span class="glyphicon glyphicon-folder-open"></span>&nbsp; Imagen</button><br>
          <img id="imagenprev" for="imagen" width="100" height="90" src="<?php if (isset($dbformulario->imagen)) {
    echo $dbformulario->imagen;
}
?>">
        </div>
      </div>
     <div class="form-group">
      <label for="asunto" class="col-md-5 control-label"><?php esc_html_e('Asunto', 'wa-leads');?></label>
      <div class="col-md-7">
       <input type="text" class="form-control" id="asunto" name="asunto" placeholder="Asunto" value="<?php if (isset($dbformulario->asunto)) {
    echo $dbformulario->asunto;
}
?>" autocomplete="off">
    </div>
  </div>

  <div class="form-group">
    <label for="mensajecorreo" class="col-md-5 control-label"><?php esc_html_e('Mensaje', 'wa-leads');?></label>
    <div class="col-md-7">
     <textarea class="form-control" id="mensajecorreo" name="mensajecorreo" placeholder="<?php esc_html_e('Mensaje', 'wa-leads');?>"  autocomplete="off"><?php if (isset($dbformulario->mensaje)) {
    echo $dbformulario->mensaje;
}
?></textarea>
  </div>
</div>
</div>
  <div class="form-group">
    <label for="saludo" class="col-md-5 control-label"><?php esc_html_e('Saludo', 'wa-leads');?></label>
    <div class="col-md-7">
     <input type="text" class="form-control" id="saludo" name="saludo" placeholder="<?php esc_html_e('Escribir el saludo', 'wa-leads');?>" value="<?php if (isset($dbformulario->saludo)) {
    echo $dbformulario->saludo;
}
?>" autocomplete="off" maxlength="25">
  </div>
</div>
 <div class="form-group">
    <label for="redes" class="col-md-5 control-label"><?php esc_html_e('Canal', 'wa-leads');?></label>
    <div class="col-md-7">
        <div class="col-md-3">
            <label for="wsp">
            <svg class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#49E670"></circle><path d="M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z" transform="translate(12.9597 12.9597)" fill="#FAFAFA"></path><path d="M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z" transform="translate(7.7758 7.77582)" fill="white" stroke="white" stroke-width="0.2"></path></svg></label>
            <input type="checkbox" class="form-control" name="wsp" value="1" id="wsp" required  autocomplete="off" <?php if ($dbformulario->wsp == 1) {echo "checked='true'";}?>>
        </div>
        <div class="col-md-3">
            <label for="sms">
            <svg class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#FF549C"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M2.60298 0H16.9194C18.351 0 19.5224 1.19321 19.5224 2.65158V14.5838C19.5224 16.0421 18.351 17.2354 16.9194 17.2354H7.4185L3.64418 20.4173C3.51402 20.5499 3.38388 20.5499 3.25372 20.5499H2.99344C2.73314 20.4173 2.60298 20.1521 2.60298 19.887V17.2354C1.17134 17.2354 0 16.0421 0 14.5838V2.65158C0 1.19321 1.17134 0 2.60298 0ZM2.60316 11.2696C2.60316 11.6673 2.86346 11.9325 3.25391 11.9325H4.5554C5.5966 11.9325 6.50764 11.0044 6.50764 9.94376C6.50764 8.88312 5.5966 7.95505 4.5554 7.95505C4.16496 7.95505 3.90465 7.68991 3.90465 7.29218C3.90465 6.89441 4.16496 6.62927 4.5554 6.62927H5.85689C6.24733 6.62927 6.50764 6.36411 6.50764 5.96637C6.50764 5.56863 6.24733 5.30347 5.85689 5.30347H4.5554C3.51421 5.30347 2.60316 6.23154 2.60316 7.29218C2.60316 8.35281 3.51421 9.28085 4.5554 9.28085C4.94585 9.28085 5.20613 9.54602 5.20613 9.94376C5.20613 10.3415 4.94585 10.6067 4.5554 10.6067H3.25391C2.86346 10.6067 2.60316 10.8718 2.60316 11.2696ZM14.9678 11.9325H13.6664C13.2759 11.9325 13.0156 11.6673 13.0156 11.2696C13.0156 10.8718 13.2759 10.6067 13.6664 10.6067H14.9678C15.3583 10.6067 15.6186 10.3415 15.6186 9.94376C15.6186 9.54602 15.3583 9.28085 14.9678 9.28085C13.9267 9.28085 13.0156 8.35281 13.0156 7.29218C13.0156 6.23154 13.9267 5.30347 14.9678 5.30347H16.2693C16.6598 5.30347 16.9201 5.56863 16.9201 5.96637C16.9201 6.36411 16.6598 6.62927 16.2693 6.62927H14.9678C14.5774 6.62927 14.3171 6.89441 14.3171 7.29218C14.3171 7.68991 14.5774 7.95505 14.9678 7.95505C16.009 7.95505 16.9201 8.88312 16.9201 9.94376C16.9201 11.0044 16.009 11.9325 14.9678 11.9325ZM10.4126 11.2697C10.4126 11.6674 10.6729 11.9326 11.0633 11.9326C11.4538 11.9326 11.7141 11.6674 11.8442 11.2697V5.96649C11.8442 5.70135 11.5839 5.43619 11.3236 5.30362C10.9332 5.30362 10.6729 5.43619 10.5427 5.70135L9.76186 7.15973L8.98094 5.70135C8.85081 5.43619 8.46034 5.17102 8.20006 5.30362C7.93977 5.43619 7.67946 5.70135 7.67946 5.96649V11.2697C7.67946 11.6674 7.93977 11.9326 8.33022 11.9326C8.72066 11.9326 8.98094 11.6674 8.98094 11.2697V8.75067L9.1111 8.88327C9.37138 9.28101 10.0221 9.28101 10.2825 8.88327L10.4126 8.75067V11.2697Z" transform="translate(9.67801 10.4601)" fill="white"></path></svg></label>
            <input type="checkbox" class="form-control" name="sms" id="sms" value="1" required  autocomplete="off" <?php if ($dbformulario->sms == 1) {echo "checked='true'";}?>>
        </div>
        <div class="col-md-3">
            <label for="msg">
            <svg width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#1E88E5"></circle>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 9.63934C0 4.29861 4.68939 0 10.4209 0C16.1524 0 20.8418 4.29861 20.8418 9.63934C20.8418 14.98 16.1524 19.2787 10.4209 19.2787C9.37878 19.2787 8.33673 19.1484 7.42487 18.8879L3.90784 20.8418V17.1945C1.56311 15.3708 0 12.6353 0 9.63934ZM8.85779 10.1604L11.463 13.0261L17.1945 6.90384L12.1143 9.76959L9.37885 6.90384L3.64734 13.0261L8.85779 10.1604Z" transform="translate(9.01854 10.3146)" fill="white"></path></svg></label>
                <input type="checkbox" class="form-control" name="msg" id="msg" value="1" required  autocomplete="off" <?php if ($dbformulario->msg == 1) {echo "checked='true'";}?>>
        </div>
        <div class="col-md-3">
            <label for="tlf">
            <svg class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#03E78B"></circle><path d="M19.3929 14.9176C17.752 14.7684 16.2602 14.3209 14.7684 13.7242C14.0226 13.4259 13.1275 13.7242 12.8292 14.4701L11.7849 16.2602C8.65222 14.6193 6.11623 11.9341 4.47529 8.95057L6.41458 7.90634C7.16046 7.60799 7.45881 6.71293 7.16046 5.96705C6.56375 4.47529 6.11623 2.83435 5.96705 1.34259C5.96705 0.596704 5.22117 0 4.47529 0H0.745882C0.298353 0 5.69062e-07 0.298352 5.69062e-07 0.745881C5.69062e-07 3.72941 0.596704 6.71293 1.93929 9.3981C3.87858 13.575 7.30964 16.8569 11.3374 18.7962C14.0226 20.1388 17.0061 20.7355 19.9896 20.7355C20.4371 20.7355 20.7355 20.4371 20.7355 19.9896V16.4094C20.7355 15.5143 20.1388 14.9176 19.3929 14.9176Z" transform="translate(9.07179 9.07178)" fill="white"></path></svg></label>
            <input type="checkbox" class="form-control" name="tlf" id="tlf" value="1" required  autocomplete="off" <?php if ($dbformulario->tlf == 1) {echo "checked='true'";}?>>
        </div>
         <div class="col-md-3">
            <label for="tlg">
                <svg aria-hidden="true" class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#3E99D8"></circle><path d="M3.56917 -2.55497e-07L0 6.42978L7.5349 1.87535L3.56917 -2.55497e-07Z" transform="translate(13.9704 24.6145)" fill="#E0E0E0"></path><path d="M20.8862 0.133954C20.754 0 20.4897 0 20.2253 0L0.396574 8.03723C0.132191 8.17118 0 8.43909 0 8.707C0 8.97491 0.132191 9.24282 0.396574 9.37677L17.5814 17.414C17.7136 17.414 17.7136 17.414 17.8458 17.414C17.978 17.414 18.1102 17.414 18.1102 17.28C18.2424 17.1461 18.3746 17.0121 18.5068 16.7442L21.1506 0.669769C21.1506 0.535815 21.1506 0.267908 20.8862 0.133954Z" transform="translate(7.36069 10.9512)" fill="white"></path><path d="M13.8801 0L0 11.52V19.4233L3.70136 13.2614L13.8801 0Z" transform="translate(13.9704 11.6208)" fill="#F2F2F2"></path></svg>
            </label>
            <input type="checkbox" class="form-control" name="tlg" id="tlg" value="1" required  autocomplete="off" <?php if ($dbformulario->tlg == 1) {echo "checked='true'";}?>>
        </div>
         <div class="col-md-3">
            <label for="skp">
                <svg aria-hidden="true" class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#03A9F4"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M10.5634 0.777588C16.0406 0.777588 20.4747 5.05426 20.4747 10.4973C20.4747 11.1453 20.4747 11.9229 20.0834 12.5709C20.4747 13.2189 20.7355 14.1261 20.7355 15.0332C20.7355 18.1436 18.1273 20.7355 14.9974 20.7355C13.9541 20.7355 13.0412 20.4763 12.2587 20.0875C11.6067 20.2171 11.085 20.2171 10.433 20.2171C4.95566 20.2171 0.521637 15.9404 0.521637 10.4973C0.521637 9.84955 0.652008 9.20175 0.782349 8.55392L0.782471 8.55338C0.260834 7.77582 0 6.73904 0 5.70227C0 2.59195 2.60825 0 5.73813 0C6.91183 0 7.95514 0.388794 8.86801 0.907166C9.38965 0.777588 10.0417 0.777588 10.5634 0.777588ZM13.5627 16.718C14.4756 16.3292 15.1276 15.8108 15.6493 15.1628C16.1709 14.5149 16.3013 13.7373 16.0405 12.9597C16.0405 12.3117 15.9101 11.7933 15.6493 11.2749C15.3884 10.7565 14.9972 10.3677 14.4756 10.1086L14.4752 10.1084C13.9536 9.84924 13.4321 9.59012 12.7802 9.33096C12.5034 9.27597 12.2031 9.1976 11.8893 9.11572C11.4638 9.0047 11.0135 8.88718 10.5632 8.81259C10.1953 8.66635 9.86893 8.60263 9.60748 8.55157C9.40552 8.51215 9.24231 8.48029 9.12866 8.4238C8.86792 8.4238 8.60721 8.29428 8.34647 8.16473L8.34619 8.16461C8.08536 8.035 7.82455 7.90543 7.69412 7.77582C7.43329 7.64621 7.43329 7.51663 7.43329 7.25742C7.43329 6.86862 7.69412 6.60944 8.08536 6.35025C8.47659 6.09106 9.12866 5.96146 9.78073 5.96146C10.5632 5.96146 11.0848 6.09106 11.4761 6.35025C11.8673 6.60944 12.1281 6.86865 12.3889 7.38702C12.6497 7.77563 12.9104 8.03476 13.0408 8.16443L13.041 8.16461C13.3018 8.29419 13.5627 8.4238 13.9539 8.4238C14.3451 8.4238 14.7364 8.29419 14.9972 8.035C15.258 7.77582 15.3884 7.51663 15.3884 7.12784C15.3884 6.73904 15.3884 6.35025 15.1276 5.96146C15.0313 5.67429 14.7927 5.45782 14.5169 5.20764C14.4193 5.11908 14.317 5.02631 14.2147 4.92468C13.6931 4.6655 13.1714 4.40631 12.5194 4.14709C11.8673 4.01752 11.0848 3.88791 10.172 3.88791C9.12866 3.88791 8.08536 4.01752 7.30289 4.2767C6.39001 4.53589 5.73795 5.05429 5.34671 5.57266C4.95547 6.09106 4.69464 6.73904 4.69464 7.51663C4.69464 8.29419 4.95547 8.9422 5.34671 9.46057C5.73795 9.97897 6.39001 10.3677 7.04205 10.627C7.69412 10.8861 8.60703 11.1453 9.6503 11.4045C10.4328 11.5341 11.0848 11.6637 11.4761 11.7933C11.8673 11.9229 12.2585 12.0525 12.5194 12.3117C12.7802 12.5709 12.9106 12.8301 12.9106 13.2189C12.9106 13.6077 12.6498 13.9965 12.1281 14.3853C11.6065 14.774 10.9544 14.9036 10.172 14.9036C9.6503 14.9036 9.12866 14.774 8.73743 14.6444C8.47659 14.5149 8.21576 14.2556 7.95496 13.9965C7.91547 13.918 7.86407 13.8277 7.80792 13.7291C7.67859 13.5019 7.52423 13.2308 7.43329 12.9597C7.40817 12.9098 7.38306 12.855 7.35703 12.7983C7.24783 12.5604 7.12225 12.2867 6.91165 12.1821C6.65085 12.0525 6.39001 11.9229 5.99878 11.9229C5.60754 11.9229 5.21631 12.0525 4.95547 12.3117C4.69464 12.5709 4.56424 12.8301 4.56424 13.2189C4.56424 13.8669 4.82507 14.3853 5.21631 15.0332C5.73795 15.6812 6.25961 16.07 6.91165 16.4588C7.82455 16.9772 8.99823 17.2364 10.4328 17.2364C11.6065 17.2364 12.6498 17.1068 13.5627 16.718Z" transform="translate(9.07178 9.07178)" fill="white"></path></svg>
            </label>
            <input type="checkbox" class="form-control" name="skp" id="skp" value="1" required  autocomplete="off" <?php if ($dbformulario->skp == 1) {echo "checked='true'";}?>>
        </div>
    </div>
</div>
<div class="form-group">
    <label for="alrte" class="col-md-5 control-label"><?php esc_html_e('Alerta?', 'wa-leads');?></label>
    <div class="col-md-7 form-inline" id="ifalerte">
        <?php esc_html_e('Habilitar', 'wa-leads');?>
        <input type="radio" class="form-control" name="ifalert" value="1" required  autocomplete="off" <?php if ($dbformulario->ifalert == 1) {echo "checked='true''";}?>>
        <?php esc_html_e('Deshabilitar', 'wa-leads');?>
        <input type="radio" class="form-control" name="ifalert" value="0" required  autocomplete="off" <?php if ($dbformulario->ifalert == 0) {echo "checked='true''";}?>>
    </div>
</div>
<div id="divalert" <?php if ($dbformulario->ifalert == 0) {echo "style='display:none'";}?>>
<div class="form-group">
  <label for="alerta" class="col-md-5 control-label"><?php esc_html_e('Mensaje Alerta', 'wa-leads');?></label>
  <div class="col-md-7">
   <textarea class="form-control" id="alert" name="alert" placeholder="<?php esc_html_e('Mensaje de alerta', 'wa-leads');?>" autocomplete="off" maxlength="110"><?php if (isset($dbformulario->alert)) {
    echo $dbformulario->alert;
}
?></textarea>
</div>
</div>
</div>
<div class="form-group" id="preform" <?php if ($dbformulario->iflisttext == 2) {echo "style='display:none'";}?>>
 <label for="pregunta" class="col-md-5 control-label"><?php esc_html_e('Pregunta', 'wa-leads');?></label>
 <div class="col-md-7">
  <input type="text" class="form-control" id="pregunta" name="pregunta" placeholder="<?php esc_html_e('Escribir la pregunta', 'wa-leads');?>" value="<?php if (isset($dbformulario->pregunta)) {
    echo $dbformulario->pregunta;
}
?>" required autocomplete="off" maxlength="100">
</div>
</div>

<div class="form-group" id="ifopcion">
 <label for="iflisttext" class="col-md-5 control-label"><?php esc_html_e('Como quiere las respuesta?', 'wa-leads');?></label>
 <div class="col-md-7 form-inline">
  <?php esc_html_e('lista', 'wa-leads');?>
  <input type="radio" class="form-control" id="iflisttext" name="iflisttext" value="0" required autocomplete="off" <?php if ($dbformulario->iflisttext == 0) {echo "checked='true''";}?>>
  <?php esc_html_e('Escribir', 'wa-leads');?>
  <input type="radio" class="form-control" id="iflisttext" name="iflisttext" value="1" required autocomplete="off" <?php if ($dbformulario->iflisttext == 1) {echo "checked='true''";}?>>
  <?php esc_html_e('Ninguna', 'wa-leads');?>
  <input type="radio" class="form-control" id="iflisttext" name="iflisttext" value="2" required autocomplete="off" <?php if ($dbformulario->iflisttext == 2) {echo "checked='true''";}?>>
</div>
</div>
<div id="divopciones" <?php if ($dbformulario->iflisttext > 0) {echo "style='display:none'";}?>>
 <?php
for ($i = 1; $i < 11; $i++) {
    $op = "opcion" . $i;
    echo '<div class="form-group">
  <label for="opcion' . $i . '" class="col-md-5 control-label">' . esc_html__("Respuesta", "wa-leads") . ' ' . $i . '</label>
  <div class="col-md-7">
  <input type="text" class="form-control" id="opcion' . $i . '" name="opcion' . $i . '" placeholder="' . esc_html__("Escribir respuesta", "wa-leads") . '" value="' . $dbformulario->$op . '"';
    if ($i == 1) {echo "required";}
    echo ' autocomplete="off" maxlength="50">
  </div>
  </div>';

}
?>
</div>
<div class="form-group">
 <label for="boton" class="col-md-5 control-label"><?php esc_html_e('Boton', 'wa-leads');?></label>
 <div class="col-md-7">
  <input type="text" class="form-control" id="boton" name="boton" placeholder="<?php esc_html_e('Escribir el boton', 'wa-leads');?>" value="<?php if (isset($dbformulario->boton)) {
    echo $dbformulario->boton;
}
?>" required autocomplete="off" maxlength="30" required>
</div>
</div>
<div class="form-group">
         <label for="ifurl" class="col-md-5 control-label"><?php esc_html_e('Url', 'wa-leads');?></label>
         <div class="col-md-3" id="ifurl">
          <?php esc_html_e('API', 'wa-leads');?>
          <input type="radio" class="form-control" name="ifurl" value="0" required  autocomplete="off" <?php if ($dbformulario->ifurl == 0) {echo "checked='true'";}?>>
          </div>
          <div class="col-md-4" id="ifcookies">
          <?php esc_html_e('Pagina (receptorwaleads [receptor_waleads])', 'wa-leads');?>
          <input type="radio" class="form-control" name="ifurl" value="1" required  autocomplete="off" <?php if ($dbformulario->ifurl == 1) {echo "checked='true'";}?>>
        </div>
      </div>
      <div class="form-group">
         <label for="ifcookies" class="col-md-5 control-label"><?php esc_html_e('Cookies', 'wa-leads');?></label>
         <div class="col-md-7 form-inline" id="ifcookies">
          <?php esc_html_e('Si', 'wa-leads');?>
          <input type="radio" class="form-control" name="ifcookies" value="1" required  autocomplete="off" <?php if ($dbformulario->ifcookies == 1) {echo "checked='true'";}?>>
          <?php esc_html_e('No', 'wa-leads');?>
          <input type="radio" class="form-control" name="ifcookies" value="0" required  autocomplete="off" <?php if ($dbformulario->ifcookies == 0) {echo "checked='true'";}?>>
        </div>
      </div>
<div class="form-group">
 <div class="col-md-offset-3 col-md-9">
  <button id="sqlformulario" class="btn btn-info"><span class="glyphicon glyphicon-save"></span> <?php esc_html_e('Guardar', 'wa-leads');?></button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="cargarformulario" width="100px" height="60px">
</div>
</div>
</div>
<div id="errorsrformulario"></div>
</div>
</form>
</div>
</div>
<div class="modal-footer">
  <button class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>

</div>
</div>

<div id="Modalmailchimp" class="modal fade in" role="dialog">
 <div class="modal-dialog">

  <!-- Modal content-->
  <div class="modal-content">
   <div class="modal-body">
    <div class="panel panel-info">
     <div class="panel-heading">
      <div class="panel-title"><?php esc_html_e('API MailChimp', 'wa-leads');?></div>
    </div>
    <form id="formmailchimp">
      <div class="panel-body">
       <div class="form-horizontal">

        <div class="form-group">
         <label for="api_key" class="col-md-3 control-label"><?php esc_html_e('API KEY:', 'wa-leads');?></label>
         <div class="col-md-9">
          <input type="text" class="form-control" id="api_key" name="api_key" placeholder="<?php esc_html_e('Escribir la API KEY', 'wa-leads');?>" value="<?php if (isset($dbmailchimp->api_key)) {
    echo $dbmailchimp->api_key;
}
?>" required="" autocomplete="off">
       </div>
     </div>


     <div class="form-group">
       <label for="list_id" class="col-md-3 control-label"><?php esc_html_e('LIST ID', 'wa-leads');?></label>
       <div class="col-md-9">
        <input type="email" class="form-control" id="list_id" name="list_id" placeholder="<?php esc_html_e('Escribir el ID LIST', 'wa-leads');?>" value="<?php if (isset($dbmailchimp->list_id)) {
    echo $dbmailchimp->list_id;
}
?>" required="" autocomplete="off">
     </div>
   </div>


   <div class="form-group">
     <div class="col-md-offset-3 col-md-9">
      <button id="sqlmailchimp" class="btn btn-info"><span class="glyphicon glyphicon-save"></span> <?php esc_html_e('Guardar', 'wa-leads');?></button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="cargarmailchimp" width="100px" height="60px">
    </div>
  </div>
</div>
<div id="errorsmailchimp"></div>
</div>
</form>
</div>
</div>
<div class="modal-footer">
  <button class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>

</div>
</div>


<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <form id="formeditar">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php esc_html_e('Editar Agente', 'wa-leads');?> <b><strong id="tipoedim"></strong><b></h4>
            </div>
            <div class="modal-body">
                <div class="form-horizontal">
                    <div class="form-group">
                        <label class="control-label col-md-4" for="nombreed"><?php esc_html_e('Nombre:', 'wa-leads');?></label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" id="nombreed" placeholder="<?php esc_html_e('Escribir el Nombre', 'wa-leads');?>" name="nombre" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4" for="mailed"><?php esc_html_e('Email:', 'wa-leads');?></label>
                        <div class="col-md-8">
                            <input type="email" class="form-control" id="mailed" placeholder="<?php esc_html_e('Escribir el Email', 'wa-leads');?>" name="email" required>
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="numero" class="col-md-4 control-label"><?php esc_html_e('WhatsApp:', 'wa-leads');?></label>
                    <div class="col-md-8">
                        <div class="col-md-4">
                            <select name="code" class="form-control" required="" id="codeeditar">
                                <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
                                </select>
                            </div>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="numeroeditar" name="numero" onkeyUp="return ValNumero(this);" placeholder="<?php esc_html_e('Numero de Whatsapp', 'wa-leads');?>" required autocomplete="off">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                       <label for="msged" class="col-md-4 control-label"><?php esc_html_e('Link Messenger', 'wa-leads');?></label>
                       <div class="col-md-8">
                            <input type="text" class="form-control" id="msged" name="msged" placeholder="<?php esc_html_e('Messenger', 'wa-leads');?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                       <label for="tlfed" class="col-md-4 control-label"><?php esc_html_e('Numero de llamada', 'wa-leads');?></label>
                       <div class="col-md-8" style="display: flex;">
        <div style="width:150px;">
         <select name="codellamadaed" class="form-control" required="" id="codellamadaed">
          <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
        </select>
      </div>
                            <input type="text" class="form-control" id="tlfed" name="tlfed" placeholder="<?php esc_html_e('Llamadas', 'wa-leads');?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                       <label for="smsed" class="col-md-4 control-label"><?php esc_html_e('Numero SMS', 'wa-leads');?></label>
                       <div class="col-md-8" style="display: flex;">
        <div style="width:150px;">
         <select name="codesmsed" class="form-control" required="" id="codesmsed">
          <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1">US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
        </select>
      </div>
                            <input type="text" class="form-control" id="smsed" name="smsed" placeholder="<?php esc_html_e('Mensajes', 'wa-leads');?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                       <label for="tlged" class="col-md-4 control-label"><?php esc_html_e('Usuario de Telegram', 'wa-leads');?></label>
                       <div class="col-md-8">
                            <input type="text" class="form-control" id="tlged" name="tlged" placeholder="<?php esc_html_e('Telegram', 'wa-leads');?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                       <label for="skped" class="col-md-4 control-label"><?php esc_html_e('Usuario de Skype', 'wa-leads');?></label>
                       <div class="col-md-8">
                            <input type="text" class="form-control" id="skped" name="skped" placeholder="<?php esc_html_e('Skype', 'wa-leads');?>" autocomplete="off">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="tipo" class="col-md-4 control-label"><?php esc_html_e('Roles', 'wa-leads');?></label>
                        <div class="col-md-8 form-inline">
                            <?php esc_html_e('Admin', 'wa-leads');?>
                            <input type="radio" class="form-control" id="tipo" name="tipo" required value="1">
                            <?php esc_html_e('Vendedor', 'wa-leads');?>
                            <input type="radio" class="form-control" id="tipo" name="tipo" required value="0">
                        </div>
                    </div>
                    <h3><?php esc_html_e('Horario de Servicio', 'wa-leads');?></h3>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="entrada"><?php esc_html_e('Inicio:', 'wa-leads');?></label>
                        <div class="col-md-8">
                            <input type="number" class="form-control" id="entradaed" max="24" min="0" onkeyUp="return ValNumero(this);" name="entrada" required> 24 Hora
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="salida"><?php esc_html_e('Final:', 'wa-leads');?></label>
                        <div class="col-md-8">
                            <input type="number" class="form-control" id="salidaed" max="24" min="0" onkeyUp="return ValNumero(this);" name="salida" required> 24 Hora
                        </div>
                    </div>
                </div>
                <br>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="ideditar" name="id">
                <button type="submit" class="btn btn-primary" id="editar"><?php esc_html_e('Editar', 'wa-leads');?></button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="Modalver" role="dialog">
  <div class="modal-dialog">
   <!-- Modal content-->
   <div class="modal-content">
    <div class="modal-header">
     <h4 class="modal-title"><?php esc_html_e('Datos del Agente', 'wa-leads');?> <strong id="tipoverm"></strong></h4>
     <button type="button" class="close" data-dismiss="modal">&times;</button>
   </div>
   <div class="modal-body">
     <form class="form-vertical">
      <div class="row">
       <label class="control-label col-sm-2"><?php esc_html_e('Nombre:', 'wa-leads');?></label>
       <div class="col-sm-4">
        <strong><p id="nombrev"></p></strong>
      </div>


      <label class="control-label col-sm-2"><?php esc_html_e('Email:', 'wa-leads');?></label>
      <div class="col-sm-4" >
        <strong><p id="emailv" style="overflow:hidden; text-overflow:ellipsis;" title=""></p></strong>
      </div>
    </div>
    <div class="row">
     <label class="control-label col-sm-2"><?php esc_html_e('WhatsApp:', 'wa-leads');?></label>
     <div class="col-sm-4">
      <strong><p id="numerov"></p></strong>
    </div>

    <label class="control-label col-sm-2"><?php esc_html_e('Estado:', 'wa-leads');?></label>
    <div class="col-sm-4">
      <strong><p id="turnov"></p></strong>
    </div>
  </div>
  <div class="row">
     <label class="control-label col-md-3"><?php esc_html_e('Link Messenger:', 'wa-leads');?></label>
     <div class="col-md-9">
      <strong><p id="msgv"></p></strong>
    </div>
  </div>
  <div class="row">
     <label class="control-label col-md-4"><?php esc_html_e('Numero de Llamada:', 'wa-leads');?></label>
     <div class="col-md-8">
      <strong><p id="tlfv"></p></strong>
    </div>
  </div>
  <div class="row">
     <label class="control-label col-md-4"><?php esc_html_e('Numero SMS:', 'wa-leads');?></label>
     <div class="col-md-8">
      <strong><p id="smsv"></p></strong>
    </div>
  </div>
  <div class="row">
     <label class="control-label col-md-4"><?php esc_html_e('Usuario de Telegram:', 'wa-leads');?></label>
     <div class="col-md-8">
      <strong><p id="tlgv"></p></strong>
    </div>
  </div>
  <div class="row">
     <label class="control-label col-md-4"><?php esc_html_e('Usuario de Skype:', 'wa-leads');?></label>
     <div class="col-md-8">
      <strong><p id="skpv"></p></strong>
    </div>
  </div>
  <h3>Servicio:</h3>
  <br>
  <div class="row">
   <label class="control-label col-sm-3"><?php esc_html_e('Inicio:', 'wa-leads');?></label>
   <div class="col-sm-3">
    <strong><p id="entradav"></p></strong>
  </div>
  <label class="control-label col-sm-3"><?php esc_html_e('Fecha Incio:', 'wa-leads');?></label>
  <div class="col-sm-3">
    <strong><p id="fechainiciov"></p></strong>
  </div>
</div>
<div class="row">
 <label class="control-label col-sm-3"><?php esc_html_e('Final:', 'wa-leads');?></label>
 <div class="col-sm-3">
  <strong><p id="salidav"></p></strong>
</div>
</div>
<div class="row">
 <div class="col-sm-8">
  <div class="table-responsive">
   <table id="datatableagente" class="table table-striped table-bordered"  style="width:100%">
    <thead>
     <tr>
      <th scope="col">#</th>
      <th>Fecha</th>
      <th>Contactos</th>
      <th>Reporte</th>
    </tr>
  </thead>
  <tbody id="listavr">

  </tbody>
</table>
</div>
</div>
<div class="col-sm-4">
  <label for="totalc"><?php esc_html_e('Total Recibidos:', 'wa-leads');?></label>
  <span id="totalc" class="d-inline"></span><br>
  Reporte de contactos <span id="re"></span>
</div>

</div>
</form>
</div>
<div class="modal-footer">
 <button type="button" class="btn btn-default" data-dismiss="modal"><?php esc_html_e('Cerrar', 'wa-leads');?></button>
</div>
</div>
</div>
</div>

<div class="modal fade" id="Modaldelet" role="dialog">
  <div class="modal-dialog modal-md">
   <div class="modal-content">
    <div class="modal-header">

     <h4 class="modal-title" id="titlemsjdelet"></h4>
   </div>
   <div class="modal-body text-center" id="imp1">
     <p id="mensajedelet"></p>
   </div>
   <div class="modal-footer">
     <button type="button" class="close mr-5" data-dismiss="modal"><?php esc_html_e('Cerrar', 'wa-leads');?></button>
     <div id="btnmodaldelet"></div>
   </div>
 </div>
</div>
</div>

<script type="text/javascript">
  function previewImage(entrada, salida) {
        var reader = new FileReader();
        reader.readAsDataURL(document.getElementById(entrada).files[0]);
        reader.onload = function(e) {
            document.getElementById(salida).src = e.target.result;
        };
    }
    function Solo_Numerico(variable) {
        Numer = parseInt(variable);
        if (isNaN(Numer)) {
            return "";
        }
        return Numer;
    }

    function ValNumero(Control) {
        Control.value = Solo_Numerico(Control.value);
    }

    function reportefecha(fecha, id) {
        console.log(admincontrol.admincontrolajaxurl);

        window.open(admincontrol.admincontrolajaxurl+"?id="+id+"&fecha="+fecha+"&acti=reporte&action=admincontrol", "_blank");
    }

    function suspender(id) {
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: 'post',
            data: {
                id: id,
                acti: 'suspender',
                action: 'admincontrol',
            },
            success: function(dato) {
                var d = JSON.parse(dato);
                if (parseInt(d['turno']) == 2) {
                    document.getElementById('turno' + d['id']).innerHTML = '<div class="btn-warning"><?php esc_html_e('Suspendido', 'wa-leads');?></div>';
                } else {
                    document.getElementById('turno' + d['id']).innerHTML = '<div class="btn-danger">Inactivo</div>';
                }
            }
        });
    }
function editar(id){
  nombre = document.getElementById("nombreed");
  email = document.getElementById("mailed");
  numero = document.getElementById("numeroeditar");
  entrada = document.getElementById("entradaed");
  salida = document.getElementById("salidaed");
  linkmsg = document.getElementById("msged");
  tlf = document.getElementById("tlfed");
  sms = document.getElementById("smsed");
  tlg = document.getElementById("tlged");
  skp = document.getElementById("skped");
  jQuery.ajax({
   url: admincontrol.admincontrolajaxurl,
   type: 'post',
   data: {
    agente: id,
    acti: 'verEdiAgent',
    action: 'admincontrol'
  },
  success: function(dato) {
    var data = JSON.parse(dato);

  jQuery("#codeeditar option").each(function() {
        if(this.value == data['code']){
            this.setAttribute("selected", "true");
        }
    });
  jQuery("#codellamadaed option").each(function() {
        if(this.value == data['codetlf']){
            this.setAttribute("selected", "true");
        }
    });
    jQuery("#codesmsed option").each(function() {
        if(this.value == data['codesms']){
            this.setAttribute("selected", "true");
        }
    });

  id = data['id'];
  document.getElementById("ideditar").value = id;
  jQuery("#tipoedim").text(data['tipo']);
  nombre.value = data['nombre'];
  email.value = data['email'];
  numero.value = data['numero'];
  entrada.value = data['entrada'];
  salida.value = data['salida'];
  linkmsg.value = data['msg'];
  tlf.value = data['numtlf'];
  sms.value = data['numsms'];
  tlg.value = data['usertlg'];
  skp.value = data['userskp'];

  jQuery('#myModal').modal("show");

}
});
}

    function ver(id) {
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: 'post',
            data: {
                agente: id,
                acti: 'verAgente',
                action: 'admincontrol'
            },
            beforeSend: function() {
                jQuery('#listavr').html('');
            },
            success: function(dato) {
                var datos = JSON.parse(dato);
                var t = '';
                jQuery('#tipoverm').text(datos['agente']['tipo']);
                jQuery('#nombrev').html(datos['agente']['nombre']);
                jQuery('#emailv').html(datos['agente']['email']);
                jQuery('#msgv').html(datos['agente']['linkmsg']);
                jQuery('#tlfv').html('+' + datos['agente']['codetlf'] + datos['agente']['numtlf']);
                jQuery('#smsv').html('+' + datos['agente']['codesms'] + datos['agente']['numsms']);
                jQuery('#tlgv').html(datos['agente']['usertlg']);
                jQuery('#skpv').html(datos['agente']['userskp']);
                jQuery('#emailv').attr("title", datos['agente']['email']);
                jQuery('#numerov').html('+' + datos['agente']['code'] + datos['agente']['numero']);
                if (datos['agente']['turno'] == 0) {
                    t = '<div class="btn-danger text-center">Inactivo</div>';
                } else if (datos['agente']['turno'] == 1) {
                    t = '<div class="btn-success text-center"><?php esc_html_e('Activo', 'wa-leads');?></div>';
                } else {
                    t = '<div class="btn-warning"><?php esc_html_e('Suspendido', 'wa-leads');?></div>';
                }
                jQuery('#turnov').html(t);
                jQuery('#entradav').html(datos['agente']['entrada'] + ' Horas');
                jQuery('#salidav').html(datos['agente']['salida'] + ' Horas');
                jQuery('#fechainiciov').html(datos['agente']['fechainicio']);
                jQuery('#re').html('<span class="glyphicon glyphicon-print btn text-success" onclick="reportefecha(11,' + datos['agente']['id'] + ')"></span>');
                var total = 0;
                jQuery.each(datos['servicio'], function(k, dats) {
                    tablever(dats, datos['agente']['id']);
                    total = total + parseInt(dats['cantidad']);
                });
                jQuery('#totalc').html(total);
                jQuery('#Modalver').modal("show");

            }
        });
    }
    for (var i = 0; i <= document.querySelectorAll('#list').length - 1; i++) {
        document.querySelectorAll(".delet")[i].addEventListener("click", msjdelet);
    }

    function msjdelet(e) {
        var nombre = e.target.getAttribute('data-name');
        var id = e.target.getAttribute('data-id');
        document.getElementById('titlemsjdelet').innerHTML = '<strong>' + <?php esc_html_e('nombre', 'wa-leads');?> + '</strong>';
        document.getElementById('mensajedelet').innerHTML = '<?php esc_html_e('Desea eliminar Contacto', 'wa-leads');?> <strong>' + <?php esc_html_e('nombre', 'wa-leads');?> + '</strong>?';
        document.getElementById('btnmodaldelet').innerHTML = '<button class="btn btn-default rounded" style="position: absolute; left:30px; bottom: 10px;" id="btndelet" data-dismiss="modal" data-id="' + id + '"><?php esc_html_e('Eliminar', 'wa-leads');?><span class="text-danger glyphicon glyphicon-trash"></span></button>';
        document.getElementById('btndelet').addEventListener("click", delet);
    }

    function delet() {
        var id = document.getElementById('btndelet').getAttribute('data-id');
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: 'post',
            data: {
                id: id,
                acti: 'deletAgente',
                action: 'admincontrol'
            },
            success: function(dato) {
                document.getElementById('delet' + id).parentElement.parentElement.remove();
            }
        });
    }

    function tablever(dtos, id) {
        var tb = ``;
        tb += `<tr>
  <th scope="row">` + dtos['nu'] + `</th>
  <td>` + dtos['fechaver'] + `</td>
  <td>` + dtos['cantidad'] + `</td>
  <td><span class="glyphicon glyphicon-print btn text-success" onclick="reportefecha('` + dtos['fecha'] + `',` + id + `)"></span></td>
  </tr>`;
        jQuery('#listavr').append(tb);
    }
</script>
<!-- datatables JS -->
<script type="text/javascript" src="<?php echo ARCHIVOturno; ?>js/datatables.min.js"></script>
<script type="text/javascript" src="<?php echo ARCHIVOturno; ?>js/maindatatable.js"></script>
