<?php

$name = sanitize_text_field($_POST['name']);
$code = sanitize_text_field($_POST['coun_code']);
$phonet = sanitize_text_field($_POST['phonet']);
$msg = sanitize_text_field($_POST['msg']);
$codereceptor = sanitize_text_field($_POST['codereceptor']);
$numreceptor = sanitize_text_field($_POST['numreceptor']);
$namereceptor = sanitize_text_field($_POST['namereceptor']);
$correorecep = sanitize_text_field($_POST['correoreceptor']);
$correoemail = sanitize_text_field($_POST['correo']);
$pais = sanitize_text_field($_POST['pais']);
$url = sanitize_text_field($_POST['url']);
$redsocial = isset($_POST['redsocial']) ? sanitize_text_field($_POST['redsocial']) : '';

$codemailchimp = 200;

$sw_items = [];

for ($i = 1; $i <= 5; $i++) {
    if (isset($_POST["switem{$i}"]) && isset($_POST["switem{$i}title{$i}"]) && !empty($_POST["switem{$i}"]) && !empty($_POST["switem{$i}title{$i}"])) {
        $sw_items[$i] = [
            'switem' => sanitize_text_field($_POST["switem{$i}"]),
            'title' => sanitize_text_field($_POST["switem{$i}title{$i}"]),
        ];
    }
}

switch ($redsocial) {
    case 'wsp':
        $canal = esc_html__('Whatsapp', 'wa-leads');
        break;
    case 'msg':
        $canal = esc_html__('Messenger', 'wa-leads');
        break;
    case 'sms':
        $canal = esc_html__('SMS', 'wa-leads');
        break;
    case 'tlf':
        $canal = esc_html__('Telefono', 'wa-leads');
        break;
    case 'tlg':
        $canal = esc_html__('Telegram', 'wa-leads');
        break;
    case 'skp':
        $canal = esc_html__('Skype', 'wa-leads');
        break;
    default:
        $canal = esc_html__('Formulario de Contacto', 'wa-leads');
        break;
}

global $wpdb;

$formulario = $wpdb->get_row("SELECT asunto,mensaje,logo,imagen FROM " . $wpdb->prefix . "sw_formulario where id_formulario=1");
$mailchimp  = $wpdb->get_row("SELECT list_id,api_key FROM " . $wpdb->prefix . "sw_mailchimp where id_mailchimp=1");
$phpmailer  = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_phpmailer where id=1");

require DOCUMENTOturno . 'admin/correo-html.php';

if (empty($name) or empty($phonet)) {
    $dato = array('receptor' => $codereceptor . $numreceptor, 'msg' => $msg, 'respuesta' => 0, 'msgresp' => esc_html__('Todos los campos tienen que estar llenos', 'wa-leads'));
    exit(json_encode($dato));
} else {
    if ($correoemail === "") {

        $correoemail = "Sin correo";

    } else {
        if (!filter_var($correoemail, FILTER_VALIDATE_EMAIL)) {
            $dato = array('receptor' => $codereceptor . $numreceptor, 'msg' => $msg, 'respuesta' => 2, 'msgresp' => esc_html__('El correo no es valido', 'wa-leads'));
            exit(json_encode($dato));
        }
        add_filter('wp_mail_from_name', 'waleads_wp_mail_from_name');
        function waleads_wp_mail_from_name($name) {
            global $wpdb;
            $phpmailer = $wpdb->get_row("SELECT titlesetfrom FROM " . $wpdb->prefix . "sw_phpmailer WHERE id=1");
            return $phpmailer->titlesetfrom;
        }
        // El resto del código sigue siendo igual
        $destinatario = $correoemail;
        $asunto       = $formulario->asunto;
        $cuerpo       = $bienvenida;  
        $cabeceras[]  = "Content-Type: text/html; charset=UTF-8";

        wp_mail($destinatario, $asunto, $cuerpo, $cabeceras);

        $datamailchimp = [
            'email'     => $correoemail,
            'status'    => 'subscribed',
            'firstname' => $name,
            'city'      => $pais,
            'cel'       => $code . $phonet,
            'listId'    => $mailchimp->list_id,
            'apiKey'    => $mailchimp->api_key,
        ];

        function syncMailchimp($data)
        {
            $apiKey = $data['apiKey'];
            $listId = $data['listId'];

            $memberId   = md5(strtolower($data['email']));
            $dataCenter = substr($apiKey, strpos($apiKey, '-') + 1);
            $url        = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listId . '/members/' . $memberId;

            $json = json_encode([
                'email_address' => $data['email'],
                'status'        => $data['status'], // "subscribed","unsubscribed","cleaned","pending"
                'merge_fields'  => [
                    'FNAME'   => $data['firstname'],
                    "CITY2"   => $data['city'],
                    "CEL"     => $data['cel'],
                    "MMERGE4" => 'Acepto compartir mis datos personales',
                ],
            ]);

            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_USERPWD, 'anystring:' . $apiKey);
            $headers   = array();
            $headers[] = "Content-Type: application/x-www-form-urlencoded";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            $result   = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            return $httpCode;
        }
        syncMailchimp($datamailchimp);
    }

    try {
        add_filter('wp_mail_from_name', 'waleads_email_name_sender');

        function waleads_email_name_sender($email_from)
        {
            return "Notificacion de Nuevo Contacto";
        }
        
        

        if (empty($numreceptor)) {
            $destinatario1 = $username;
            $destinatario2 = $phpmailer->addreplyto;
            $codereceptor  = $phpmailer->codemailer;
            $numreceptor   = $phpmailer->numeromailer;
            $nombre        = "Admin";
            $disponibles   = 0;
            $contactos     = 0;
        } else{
            $correo        = $wpdb->get_row("SELECT email,nombre,id_agente FROM " . $wpdb->prefix . "sw_agente where code=" . $codereceptor . " AND numero=" . $numreceptor);
            $destinatario1 = $correo->email;
            $destinatario2 = $phpmailer->addreplyto;
            $codelimpio = str_replace(' ', '', $code);
            $f          = date("m/d/Y");
            $hora       = date("h:i:s A");
            $wpdb->insert($wpdb->prefix . 'sw_contactos_whatsapp',
                array(
                    'id_agente' => $correo->id_agente,
                    'nombre'    => $name,
                    'numero'    => $codelimpio . $phonet,
                    'correo'    => $correoemail,
                    'msg'       => $msg,
                    'url'       => $url,
                    'canal'     => $canal,
                    'pais'      => $pais,
                    'fecha'     => $f,
                    'hora'      => $hora,
                )
            );

            $nombre = $correo->nombre;
        }

        $asunto      = "Notificacion de Nuevo Contacto";
        $cuerpo      = $notificacion;
        $cabeceras[] = "Content-Type: text/html; charset=UTF-8";
        wp_mail($destinatario1, $asunto, $cuerpo, $cabeceras);
        wp_mail($destinatario2, $asunto, $cuerpo, $cabeceras);

        $respuesta = esc_html__('Email exitoso', 'wa-leads');
        $msgresp   = esc_html__('Correos Enviados a sus destinos', 'wa-leads');
    } catch (Exception $e) {
        $respuesta = 2;
        $msgresp   = esc_html__('El correo no es valido', 'wa-leads');
    }

    $dato = array('receptor' => $codereceptor . $numreceptor, 'msg' => $correoemail, 'respuesta' => $respuesta, 'msgresp' => $msgresp, 'subscri' => $codemailchimp, 'subscrierror' => esc_html__('EROOR:', 'wa-leads'), 'subscrimsg' => esc_html__('Problema al subscribir', 'wa-leads'), 'name' => $name, 'cd' => $code, 'tlf' => $phonet, 'msg' => $msg, 'coreemail' => $correoemail);

    exit(json_encode($dato));
}