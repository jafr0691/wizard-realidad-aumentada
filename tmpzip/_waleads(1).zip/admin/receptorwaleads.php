<?php 

if (isset($_GET["msg"]) and isset($_GET["numero"])) {
echo '<script type="text/javascript">
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var numero = getParameterByName("numero");
var msg = getParameterByName("msg");

function urlwl(numero,msg){
window.open("https://api.whatsapp.com/send?phone="+numero+"&text="+msg, "_self");
}
setTimeout(urlwl(numero,msg), 30000);
</script>';

}