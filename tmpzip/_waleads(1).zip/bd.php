<?php
/****************** Crear tabla con la clase wpdb *****************/
global $wpdb;

// Con esto creamos el nombre de la tabla y nos aseguramos que se cree con el mismo prefijo que ya tienen las otras tablas creadas (wp_form).
$table_conteo     = $wpdb->prefix . 'sw_conteo';
$table_agente     = $wpdb->prefix . 'sw_agente';
$table_jornada    = $wpdb->prefix . 'sw_jornada';
$table_contactos  = $wpdb->prefix . 'sw_contactos_whatsapp';
$table_phpmailer  = $wpdb->prefix . 'sw_phpmailer';
$table_formulario = $wpdb->prefix . 'sw_formulario';
$table_mailchimp  = $wpdb->prefix . 'sw_mailchimp';

// Declaramos la tabla que se creará de la forma común.
$sql = "CREATE TABLE $table_conteo (
`id` int(11) NOT NULL AUTO_INCREMENT,
`turno` int(11) NOT NULL,
UNIQUE KEY id (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE $table_agente (
`id_agente` int(11) NOT NULL AUTO_INCREMENT,
`nombre` varchar(100) NOT NULL,
`email` varchar(100) NOT NULL,
`code` int(11) NOT NULL,
`numero` varchar(20) NOT NULL,
`linkmsg` varchar(80) NOT NULL,
`codetlf` int(11) NOT NULL,
`numtlf` varchar(80) NOT NULL,
`codesms` int(11) NOT NULL,
`numsms` varchar(80) NOT NULL,
`userskp` varchar(80) NOT NULL,
`usertlg` varchar(80) NOT NULL,
`turno` int(11) DEFAULT NULL,
`password` varchar(130) NOT NULL,
`tipo` tinyint(1) NOT NULL,
`last_session` datetime DEFAULT NULL,
`activacion` int(11) NOT NULL DEFAULT '0',
`token` varchar(40) NOT NULL,
`token_password` varchar(100) DEFAULT NULL,
`password_request` int(11) DEFAULT '0',
UNIQUE KEY id_agente (id_agente),
UNIQUE KEY email (email),
UNIQUE KEY numero (numero)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE $table_jornada (
`id_jornada` int(11) NOT NULL AUTO_INCREMENT,
`id_agente` int(11) NOT NULL,
`entrada` int(11) NOT NULL,
`salida` int(11) NOT NULL,
`fechainicio` varchar(100) NOT NULL,
UNIQUE KEY id_jornada (id_jornada)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE $table_contactos (
`id_contactos` int(11) NOT NULL AUTO_INCREMENT,
`id_agente` int(11) NOT NULL,
`nombre` varchar(100) NOT NULL,
`numero` varchar(20) NOT NULL,
`correo` varchar(200) NOT NULL,
`msg` text NOT NULL,
`url` varchar(200) NOT NULL,
`canal` varchar(150) NOT NULL,
`pais` varchar(300) NOT NULL,
`fecha` varchar(20) NOT NULL,
`hora` varchar(11) NOT NULL,
UNIQUE KEY id_contactos (id_contactos)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE $table_phpmailer (
`id` int(11) NOT NULL,
`setfrom` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
`titlesetfrom` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
`codemailer` int(10) NOT NULL,
`numeromailer` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
`addreplyto` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
`titlereplyto` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
UNIQUE KEY id (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE $table_formulario (
`id_formulario` int(11) NOT NULL,
`ifalert` tinyint(1) NOT NULL,
`ifformulario` tinyint(1) NOT NULL,
`ifcookies` tinyint(1) NOT NULL,
`ifurl` tinyint(1) NOT NULL,
`logo` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
`imagen` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
`asunto` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`mensaje` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
`ifcorreo` tinyint(1) NOT NULL,
`alert` varchar(110) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
`saludo` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
`pregunta` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
`opcion1` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion2` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion3` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion4` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion5` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion6` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion7` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion8` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion9` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`opcion10` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
`wsp` tinyint(1) NOT NULL,
`msg` tinyint(1) NOT NULL,
`tlf` tinyint(1) NOT NULL,
`sms` tinyint(1) NOT NULL,
`tlg` tinyint(1) NOT NULL,
`skp` tinyint(1) NOT NULL,
`iflisttext` tinyint(1) NOT NULL,
`boton` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
UNIQUE KEY id_formulario (id_formulario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE $table_mailchimp (
`id_mailchimp` int(11) NOT NULL,
`api_key` varchar(100) NOT NULL,
`list_id` varchar(100) NOT NULL,
UNIQUE KEY id_mailchimp (id_mailchimp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT IGNORE INTO $table_formulario (`id_formulario`, `ifalert`, `ifformulario`, `ifcookies`, `ifurl`, `logo`, `imagen`, `asunto`, `mensaje`, `ifcorreo`, `alert`, `saludo`, `pregunta`, `opcion1`, `opcion2`, `opcion3`, `opcion4`, `opcion5`, `opcion6`, `opcion7`, `opcion8`, `opcion9`, `opcion10`, `iflisttext`, `boton`, `wsp`, `msg`, `tlf`, `sms`, `tlg`, `skp`) VALUES (1, 0, 0, 0, 0, '', '', 'Saludo de bienvenida', 'Hola, hemos recibido tus datos y en unos momentos estaremos contactándote por WhatsApp para orientar mejor una solución a tu requerimiento.<br><br>Cordial saludo<br><br>', 0, 'Hablemos ahora mismo', 'Podríamos resolver tus preguntas fácilmente si nos contactas por WhatsApp.<br> Hablemos ahora mismo!', '¿Cómo podemos ayudarte?', '', '', '', '', '', '', '', '', '', '', 0, 'Hablemos por WhatsApp', 0, 0, 0, 0, 0, 0);



INSERT INTO $table_mailchimp (`id_mailchimp`,`api_key`, `list_id`) VALUES
(1, 'API KEY', 'LISTA ID');

INSERT INTO $table_conteo (`id`, `turno`) VALUES
(1, 1);
INSERT INTO $table_phpmailer (`id`, `setfrom`, `titlesetfrom`, `codemailer`, `numeromailer`, `addreplyto`, `titlereplyto`) VALUES
(1,'email', 'Contacto Recibido', 57, '1231234567', 'correo duplica', 'Contactos enviados');
";
// upgrade contiene la función dbDelta la cuál revisará si existe la tabla.
require_once ABSPATH . 'wp-admin/includes/upgrade.php';
// Creamos la tabla
dbDelta($sql);
