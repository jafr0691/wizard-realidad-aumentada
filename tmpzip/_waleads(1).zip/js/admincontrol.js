(function($) {
    var touchEvent = 'ontouchstart' in window ? 'touchstart' : 'click';

    jQuery.ajax({
        url: admincontrol.admincontrolajaxurl,
        type: "post",
        data: {
            acti: 'ip',
            action: 'admincontrol'
        },
        success: function(date) {
            var servHost = JSON.parse(date);
            wlIp = servHost['ip'];
            wlCode = servHost['code'];
            wlPais = servHost['pais'];
            wlRegion = servHost['region'];
             var ttmailer = jQuery("#codemailer").text();
             var resmailer = ttmailer.split(",");
             resmailer.forEach(codecmailer);

             function codecmailer(item, index) {
              if(item.substr(0,2)==wlCode){
               document.getElementById("codemailer")[index].setAttribute("selected", "true");
             }
            }
            $("#code option").each(function() {
                if(this.text.substr(0,2) == wlCode){
                    this.setAttribute("selected", "true");
                }
            });
            $("#codellamada option").each(function() {;
                if(this.text.substr(0,2) == wlCode){
                    this.setAttribute("selected", "true");
                }
            });
            $("#codesms option").each(function() {
                if(this.text.substr(0,2) == wlCode){
                    this.setAttribute("selected", "true");
                }
            });
        }
    });


    jQuery("#ifformulario").on(touchEvent, function() {
        var ifformulario = jQuery('input[name="ifformulario"]:checked').val();
        if (ifformulario == undefined) {
            ifformulario = 0;
        }
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: "post",
            data: {
                ifformulario: ifformulario,
                acti: 'sqlformulario',
                action: 'admincontrol'
            },
            success: function(date) {
                if (date == 1) {
                    jQuery("#btn-formulario").attr("disabled", false);
                    jQuery("#btn-mailchimp").attr("disabled", false);
                } else {
                    jQuery("#btn-formulario").attr("disabled", "disabled");
                    jQuery("#btn-mailchimp").attr("disabled", "disabled");
                }
            }
        });
    });
    jQuery("#formprede").on(touchEvent, function(e) {
        jQuery("#asunto").val("Saludo de bienvenida");
        jQuery("#mensajecorreo").val("Hemos recibido tus datos y en unos momentos estaremos contactándote por WhatsApp para orientar mejor una solución a tu requerimiento.<br><br>Cordial saludo<br><br>");
        jQuery("#saludo").val("Hablemos ahora mismo");
        jQuery("#alert").val("Podríamos resolver tus preguntas fácilmente si nos contactas por WhatsApp.<br> Hablemos ahora mismo!");
        jQuery("#pregunta").val("¿Cómo podemos ayudarte?");
        jQuery("#boton").val("Hablemos por WhatsApp");
    });
    jQuery("#sqlformulario").on(touchEvent, function(e) {
        var data = new FormData(jQuery("#formformulario")[0]);
        data.append("action", 'admincontrol');
        data.append("acti", 'sqlformulario');
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: "post",
            data: data,
            // dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            beforeSend: function() {
                jQuery('#cargarformulario').css('display', 'inline-block');
            },
            success: function(dato) {
                console.log(dato);
                if (dato) {
                    alert("Se guardaron los cambios.");
                    location.reload();
                } else {
                    alert("Error: no se logro guardar los cambios");
                }
                jQuery('#cargarformulario').css('display', 'none');
            }
        });
        e.preventDefault();
    });
    jQuery("#logout").on(touchEvent, function() {
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            success: function() {
                jQuery("#login").css("display", "block");
                jQuery("#inicio").empty();
            }
        });
    });
    jQuery("#mailerusername").change(function() {
        var res = jQuery("#mailerusername").val().split("@");
        jQuery("#titlesetfrom").val(res[1]);
        jQuery("#setfrom").val(jQuery("#mailerusername").val());
        jQuery("#addaddress").val(jQuery("#mailerusername").val());
        jQuery("#addreplyto").val("replica@" + res[1]);
    });
    jQuery("#sqlphpmailer").on(touchEvent, function(e) {
        var data = jQuery("#formphpmailer").serialize();
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: "post",
            data: data + '&acti=sqlphpmailer&action=admincontrol',
            beforeSend: function() {
                jQuery('#cargarmailer').css('display', 'inline-block');
            },
            success: function(dato) {
                console.log(dato);
                if (dato) {
                    alert("Se guardaron los cambios.");
                    location.reload();
                } else {
                    alert("Error: no se logro guardar los cambios");
                }
                jQuery('#cargarmailer').css('display', 'none');
            }
        });
        e.preventDefault();
    });
    jQuery("#sqlmailchimp").on(touchEvent, function(e) {
        var data = jQuery("#formmailchimp").serialize();
        console.log(data);
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: "post",
            data: data + '&acti=sqlmailchimp&action=admincontrol',
            beforeSend: function() {
                jQuery('#cargarmailchimp').css('display', 'inline-block');
            },
            success: function(dato) {
                console.log(dato);
                if (dato) {
                    alert("Se guardaron los cambios de MAILCHIMP.");
                    location.reload();
                } else {
                    alert("Error: no se logro guardar los cambios de MAILCHIMP");
                }
                jQuery('#cargarmailchimp').css('display', 'none');
            }
        });
        e.preventDefault();
    });
    jQuery('#ifalerte').on(touchEvent, function() {
        if (jQuery('input[name="ifalert"]:checked').val() == 1) {
            jQuery('#divalert').css('display', 'block');
            jQuery('#alert').attr('required', 'true');
        } else {
            jQuery('#divalert').css('display', 'none');
            jQuery('#alert').attr('required', false);
        }
    });
    jQuery('#ifopcion').on(touchEvent, function() {
        if (jQuery('input[name="iflisttext"]:checked').val() == 1) {
            jQuery('#divopciones').css('display', 'none');
            jQuery('#preform').css('display', 'block');
            jQuery('#preform').attr('required', 'true');
            jQuery('#opcion1').attr('required', false);
        } else if (jQuery('input[name="iflisttext"]:checked').val() == 2) {
            jQuery('#preform').css('display', 'none');
            jQuery('#divopciones').css('display', 'none');
            jQuery('#opcion1').attr('required', false);
        } else {
            jQuery('#divopciones').css('display', 'block');
            jQuery('#preform').css('display', 'block');
            jQuery('#preform').attr('required', 'true');
            jQuery('#opcion1').attr('required', 'true');
        }
    });
    jQuery("#btn-signupr").on(touchEvent, function(e) {
        var data = jQuery("#formregistre").serialize();
        jQuery.ajax({
            url: admincontrol.admincontrolajaxurl,
            type: 'post',
            data: data + '&acti=btn-signupr&action=admincontrol',
            beforeSend: function(dato) {
                jQuery('#cargar').css('display', 'inline-block');
            },
            success: function(dato) {
                if (dato == true) {
                    jQuery('#Modalemailr').text(jQuery("#emailr").val());
                    jQuery('#Modalr').modal("hide");
                    jQuery('#Modalregistro').modal("show");
                } else {
                    jQuery("#errorregist").html(dato);
                    setTimeout(function() {
                        jQuery("#errorregist").empty();
                    }, 10000);
                }
                jQuery('#cargar').css('display', 'none');
            }
        });
        jQuery('#con_passr').val("");
        jQuery('#passr').val("");
        e.preventDefault();
    });
    jQuery('#aceptarregistre').on(touchEvent, function() {
        location.reload();
    });
    jQuery('#editar').on(touchEvent, function(e) {
        var data = jQuery("#formeditar").serialize();
        var dat = jQuery("#formeditar").serializeArray();
        var camvac = 0;
        var regex = /[\w-\.]{2,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;
        jQuery.each(dat, function(i, val) {
            if (val.value == "") {
                alert("Ningun campo puede estar vacio");
                camvac = 1;
            } else if (!regex.test(val.value.trim()) && val.name == "email") {
                alert('Dirección de correo inválida');
                camvac = 1;
            }
        });
        if (camvac == 0) {
            jQuery.ajax({
                url: admincontrol.admincontrolajaxurl,
                type: 'post',
                data: data + '&acti=savEditAgente&action=admincontrol',
                success: function(dato) {
                    let d = JSON.parse(dato);
                    if (d.isif) {
                        alert(d.msj);
                        document.getElementById("formeditar").reset();
                        location.reload();
                    } else {
                        alert(d.msj);
                    }
                }
            });
        }
        e.preventDefault();
    });
    
    
    jQuery("#logo").click(function() {
        var button = $(this),
        aw_uploader = wp.media({
            title: 'Logo',
            library: {
                uploadedTo: wp.media.view.settings.post.id,
                type: 'image'
            },
            button: {
                text: 'Selecionar logo'
            },
            multiple: false
        }).on('select', function() {
            var attachment = aw_uploader.state().get('selection').first().toJSON();
            document.getElementById('logoinput').value = attachment.url;
            document.getElementById('logoprev').src = attachment.url;
            jQuery("#Modalformulario").css('overflow-y','scroll');
        })
        .open();
    });
    jQuery("#imagen").click(function() {
        var button = $(this),
        aw_uploader = wp.media({
            title: 'Imagen',
            library: {
                uploadedTo: wp.media.view.settings.post.id,
                type: 'image'
            },
            button: {
                text: 'Selecionar Imagen'
            },
            multiple: false
        }).on('select', function() {
            var attachment = aw_uploader.state().get('selection').first().toJSON();
            document.getElementById('imageninput').value = attachment.url;
            document.getElementById('imagenprev').src = attachment.url;
            jQuery("#Modalformulario").css('overflow-y','scroll');
        })
        .open();
    });
})(jQuery);