//Código para Datables

//$('#example').DataTable(); //Para inicializar datatables de la manera más simple
jQuery( document ).ready( function( $ ) {
    if($('#datatablecontrol')){
        $('#datatablecontrol').DataTable({
    //para cambiar el lenguaje a español
    // dom: 'Bfrtip',
    lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ],
        
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing":"Procesando...",
        },
            // searching: false,

        });
    }
    if($('#datatableagente')){
        $('#datatableagente').DataTable({
            lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "language": {
                "lengthMenu": "Mostrar _MENU_ Contactos",
                "zeroRecords": "No se encontraron resultados",
                "info": "Contactos de _START_ al _END_ de un total de _TOTAL_ recibidos",
                "infoEmpty": "Contactos de 0 al 0 de un total de 0 recibidos",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Fecha:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast":"Último",
                    "sNext":"Siguiente",
                    "sPrevious": "Anterior"
                },
                "sProcessing":"Procesando...",
            },
            // searching: false,

        }); 
    }
    
    if($('#datatableusuario')){
        $('#datatableusuario').DataTable({
    //para cambiar el lenguaje a español
    dom: 'Bfrtip',
    lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ],
        
        "language": {
            "lengthMenu": "Mostrar _MENU_ Contactos",
            "zeroRecords": "No se encontraron resultados",
            "info": "Contactos de _START_ al _END_ de un total de _TOTAL_ recibidos",
            "infoEmpty": "Contactos de 0 al 0 de un total de 0 recibidos",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Fecha:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing":"Procesando...",
        },
            // searching: false,

        }); 
    }
});