	document.location.target = "_blank";
        document.location.href=="https://api.whatsapp.com/send?phone=584168802310&text=hola este mesj";

	// (function($) {
	//     function editar(id) {
	//         $('#myModal').modal("show");
	//         $.ajax({
	//             url: registro.ajaxurl,
	//             type: 'post',
	//             data: {
	//                 action: 'registro_agent',
	//                 agente: id
	//             },
	//             success: function(dato) {
	//                 var dato = JSON.parse(dato);
	//                 alert(dato['nombre']);
	//             }
	//         });
	//     }
	//     document.getElementById("nuevo").addEventListener("click", function() {
	//         document.getElementById("formnuevo").style.display = "block";
	//         document.getElementById("listaagente").style.display = "none";
	//         document.getElementById("nuevo").setAttribute("class", "nav-tab nav-tab-active");
	//         document.getElementById("agentes").setAttribute("class", "nav-tab");
	//     });
	//     document.getElementById("agentes").addEventListener("click", function() {
	//         document.getElementById("formnuevo").style.display = "none";
	//         document.getElementById("listaagente").style.display = "block";
	//         document.getElementById("agentes").setAttribute("class", "nav-tab nav-tab-active");
	//         document.getElementById("nuevo").setAttribute("class", "nav-tab");
	//     });

	//     function Solo_Numerico(variable) {
	//         Numer = parseInt(variable);
	//         if (isNaN(Numer)) {
	//             return "";
	//         }
	//         return Numer;
	//     }

	//     function ValNumero(Control) {
	//         Control.value = Solo_Numerico(Control.value);
	//     }
	//     document.getElementById("guardar").addEventListener("click", function() {
	//         var nombre = document.getElementById("nombre");
	//         var email = document.getElementById("mail");
	//         var numero = document.getElementById("num");
	//         var cant = document.getElementById("cont");
	//         var entrada = document.getElementById("entrada");
	//         var salida = document.getElementById("salida");
	//         if (nombre.value == "") {
	//             alert("Campo Nombre no puede estar vacio!");
	//             nombre.focus({
	//                 preventScroll: false
	//             });
	//         } else if (email.value == "") {
	//             alert("Campo Email no puede estar vacio!");
	//             nombre.focus({
	//                 preventScroll: false
	//             });
	//         } else if (numero.value == "") {
	//             alert("Campo Numero no puede estar vacio!");
	//             numero.focus({
	//                 preventScroll: false
	//             });
	//         } else if (cant.value == undefined) {
	//             alert("Campo de catidad de contactos no puede estar vacio!");
	//             cant.focus({
	//                 preventScroll: false
	//             });
	//         } else if (salida.value == "") {
	//             alert("Campo de Horario de Inicio no puede estar vacio!");
	//             salida.focus({
	//                 preventScroll: false
	//             });
	//         } else if (salida.value < entrada.value) {
	//             alert("Campo de Horario Final no puede ser menor que la Entrada!");
	//         } else {
	//             var ruta = '<?php echo ARCHIVOturno; ?>';
	//             var xhttp = new XMLHttpRequest();
	//             xhttp.onreadystatechange = function() {
	//                 if (this.readyState == 4 && this.status == 200) {
	//                     alert("El agente se guardo con exito");
	//                     location.reload();
	//                 }
	//             };
	//             xhttp.open("GET", ruta + "admin/guardar.php?nombre=" + nombre.value + "&email=" + email.value + "&numero=" + numero.value + "&cant=" + cant.value + "&entrada=" + entrada.value + "&salida=" + salida.value, true);
	//             xhttp.send();
	//         }
	//     });
	// })(jQuery);