(function($) {
    let touchEvent = 'ontouchstart' in window ? 'touchstart' : 'click';

    var code = document.getElementById("codereceptor").value;
    var num = document.getElementById("numreceptor").value;
    contador(0, num);
    setInterval(function() {
        contador(0, 0);
    }, 5000);

    
    function btnwspfunc() {
        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
        $(".tooltiptextt").css("display", "none");
        $("#chatwhatsapp").css("display", "block");
        $(".container-btn-ws").css("display", "none");
        $(".sw-icon").html('<svg class="ico_d " width="45" height="45" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#49E670"></circle><path d="M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z" transform="translate(12.9597 12.9597)" fill="#FAFAFA"></path><path d="M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z" transform="translate(7.7758 7.77582)" fill="white" stroke="white" stroke-width="0.2"></path></svg> <div style="display: table-cell;vertical-align: middle;padding-left:inherit;">  Whatsapp</div>');
        $("#chatsms").css("display", "none");
        $("#chatmsg").css("display", "none");
        $("#chattlf").css("display", "none");
        $("#chattlg").css("display", "none");
        $("#chatskp").css("display", "none");
        $("#chatwhatsapp").css('opacity', '0.2');
        $("#redsocial").val('wsp');
    }
    function btnmsgfunc() {
        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
        $(".tooltiptextt").css("display", "none");
        $("#chatmsg").css("display", "block");
        $(".container-btn-ws").css("display", "none");
        $(".sw-icon").html('<svg width="39" height="39" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#1E88E5"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M0 9.63934C0 4.29861 4.68939 0 10.4209 0C16.1524 0 20.8418 4.29861 20.8418 9.63934C20.8418 14.98 16.1524 19.2787 10.4209 19.2787C9.37878 19.2787 8.33673 19.1484 7.42487 18.8879L3.90784 20.8418V17.1945C1.56311 15.3708 0 12.6353 0 9.63934ZM8.85779 10.1604L11.463 13.0261L17.1945 6.90384L12.1143 9.76959L9.37885 6.90384L3.64734 13.0261L8.85779 10.1604Z" transform="translate(9.01854 10.3146)" fill="white"></path></svg> <div style="display: table-cell;vertical-align: middle;padding-left:inherit;"> Messenger<div>');
        $("#chatsms").css("display", "none");
        $("#chatwhatsapp").css("display", "none");
        $("#chattlf").css("display", "none");
        $("#chattlg").css("display", "none");
        $("#chatskp").css("display", "none");
        $("#chatmsg").css('opacity', '0.2');
        $("#redsocial").val('msg');
    }
    function btnsmsfunc() {
        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
        $(".tooltiptextt").css("display", "none");
        $("#chatsms").css("display", "block");
        $(".container-btn-ws").css("display", "none");
        $(".sw-icon").html('<svg class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#FF549C"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M2.60298 0H16.9194C18.351 0 19.5224 1.19321 19.5224 2.65158V14.5838C19.5224 16.0421 18.351 17.2354 16.9194 17.2354H7.4185L3.64418 20.4173C3.51402 20.5499 3.38388 20.5499 3.25372 20.5499H2.99344C2.73314 20.4173 2.60298 20.1521 2.60298 19.887V17.2354C1.17134 17.2354 0 16.0421 0 14.5838V2.65158C0 1.19321 1.17134 0 2.60298 0ZM2.60316 11.2696C2.60316 11.6673 2.86346 11.9325 3.25391 11.9325H4.5554C5.5966 11.9325 6.50764 11.0044 6.50764 9.94376C6.50764 8.88312 5.5966 7.95505 4.5554 7.95505C4.16496 7.95505 3.90465 7.68991 3.90465 7.29218C3.90465 6.89441 4.16496 6.62927 4.5554 6.62927H5.85689C6.24733 6.62927 6.50764 6.36411 6.50764 5.96637C6.50764 5.56863 6.24733 5.30347 5.85689 5.30347H4.5554C3.51421 5.30347 2.60316 6.23154 2.60316 7.29218C2.60316 8.35281 3.51421 9.28085 4.5554 9.28085C4.94585 9.28085 5.20613 9.54602 5.20613 9.94376C5.20613 10.3415 4.94585 10.6067 4.5554 10.6067H3.25391C2.86346 10.6067 2.60316 10.8718 2.60316 11.2696ZM14.9678 11.9325H13.6664C13.2759 11.9325 13.0156 11.6673 13.0156 11.2696C13.0156 10.8718 13.2759 10.6067 13.6664 10.6067H14.9678C15.3583 10.6067 15.6186 10.3415 15.6186 9.94376C15.6186 9.54602 15.3583 9.28085 14.9678 9.28085C13.9267 9.28085 13.0156 8.35281 13.0156 7.29218C13.0156 6.23154 13.9267 5.30347 14.9678 5.30347H16.2693C16.6598 5.30347 16.9201 5.56863 16.9201 5.96637C16.9201 6.36411 16.6598 6.62927 16.2693 6.62927H14.9678C14.5774 6.62927 14.3171 6.89441 14.3171 7.29218C14.3171 7.68991 14.5774 7.95505 14.9678 7.95505C16.009 7.95505 16.9201 8.88312 16.9201 9.94376C16.9201 11.0044 16.009 11.9325 14.9678 11.9325ZM10.4126 11.2697C10.4126 11.6674 10.6729 11.9326 11.0633 11.9326C11.4538 11.9326 11.7141 11.6674 11.8442 11.2697V5.96649C11.8442 5.70135 11.5839 5.43619 11.3236 5.30362C10.9332 5.30362 10.6729 5.43619 10.5427 5.70135L9.76186 7.15973L8.98094 5.70135C8.85081 5.43619 8.46034 5.17102 8.20006 5.30362C7.93977 5.43619 7.67946 5.70135 7.67946 5.96649V11.2697C7.67946 11.6674 7.93977 11.9326 8.33022 11.9326C8.72066 11.9326 8.98094 11.6674 8.98094 11.2697V8.75067L9.1111 8.88327C9.37138 9.28101 10.0221 9.28101 10.2825 8.88327L10.4126 8.75067V11.2697Z" transform="translate(9.67801 10.4601)" fill="white"></path></svg> <div style="display: table-cell;vertical-align:middle;padding-lef:inherit;"> Mensaje<div>');
        $("#chattlf").css("display", "none");
        $("#chatmsg").css("display", "none");
        $("#chattlg").css("display", "none");
        $("#chatskp").css("display", "none");
        $("#chatwhatsapp").css("display", "none");
        $("#chatsms").css('opacity', '0.2');
        $("#redsocial").val('sms');
    }
    function btntlffunc() {
        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
        $(".tooltiptextt").css("display", "none");
        $("#chattlf").css("display", "block");
        $(".container-btn-ws").css("display", "none");
        $(".sw-icon").html('<svg class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#03E78B"></circle><path d="M19.3929 14.9176C17.752 14.7684 16.2602 14.3209 14.7684 13.7242C14.0226 13.4259 13.1275 13.7242 12.8292 14.4701L11.7849 16.2602C8.65222 14.6193 6.11623 11.9341 4.47529 8.95057L6.41458 7.90634C7.16046 7.60799 7.45881 6.71293 7.16046 5.96705C6.56375 4.47529 6.11623 2.83435 5.96705 1.34259C5.96705 0.596704 5.22117 0 4.47529 0H0.745882C0.298353 0 5.69062e-07 0.298352 5.69062e-07 0.745881C5.69062e-07 3.72941 0.596704 6.71293 1.93929 9.3981C3.87858 13.575 7.30964 16.8569 11.3374 18.7962C14.0226 20.1388 17.0061 20.7355 19.9896 20.7355C20.4371 20.7355 20.7355 20.4371 20.7355 19.9896V16.4094C20.7355 15.5143 20.1388 14.9176 19.3929 14.9176Z" transform="translate(9.07179 9.07178)" fill="white"></path></svg> <div style="display: table-cell;vertical-align: middle;padding-left:inherit;"> Llamada<div>');
        $("#chatsms").css("display", "none");
        $("#chatmsg").css("display", "none");
        $("#chattlg").css("display", "none");
        $("#chatskp").css("display", "none");
        $("#chatwhatsapp").css("display", "none");
        $("#chattlf").css('opacity', '0.2');
        $("#redsocial").val('tlf');
    }
    
    function btntlgfunc() {
        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
        $(".tooltiptextt").css("display", "none");
        $("#chattlg").css("display", "block");
        $(".container-btn-ws").css("display", "none");
        $(".sw-icon").html('<svg aria-hidden="true" class="ico_d " width="40" height="40" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#3E99D8"></circle><path d="M3.56917 -2.55497e-07L0 6.42978L7.5349 1.87535L3.56917 -2.55497e-07Z" transform="translate(13.9704 24.6145)" fill="#E0E0E0"></path><path d="M20.8862 0.133954C20.754 0 20.4897 0 20.2253 0L0.396574 8.03723C0.132191 8.17118 0 8.43909 0 8.707C0 8.97491 0.132191 9.24282 0.396574 9.37677L17.5814 17.414C17.7136 17.414 17.7136 17.414 17.8458 17.414C17.978 17.414 18.1102 17.414 18.1102 17.28C18.2424 17.1461 18.3746 17.0121 18.5068 16.7442L21.1506 0.669769C21.1506 0.535815 21.1506 0.267908 20.8862 0.133954Z" transform="translate(7.36069 10.9512)" fill="white"></path><path d="M13.8801 0L0 11.52V19.4233L3.70136 13.2614L13.8801 0Z" transform="translate(13.9704 11.6208)" fill="#F2F2F2"></path></svg><div style="display: table-cell;vertical-align: middle;padding-left:inherit;"> Telegram<div>');
        $("#chatsms").css("display", "none");
        $("#chatmsg").css("display", "none");
        $("#chatskp").css("display", "none");
        $("#chatwhatsapp").css("display", "none");
        $("#chattlg").css('opacity', '0.2');
        $("#redsocial").val('tlg');
    }
    
    function btnskpfunc() {
        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
        $(".tooltiptextt").css("display", "none");
        $("#chatskp").css("display", "block");
        $(".container-btn-ws").css("display", "none");
        $(".sw-icon").html('<svg aria-hidden="true" class="ico_d " width="39" height="39" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#03A9F4"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M10.5634 0.777588C16.0406 0.777588 20.4747 5.05426 20.4747 10.4973C20.4747 11.1453 20.4747 11.9229 20.0834 12.5709C20.4747 13.2189 20.7355 14.1261 20.7355 15.0332C20.7355 18.1436 18.1273 20.7355 14.9974 20.7355C13.9541 20.7355 13.0412 20.4763 12.2587 20.0875C11.6067 20.2171 11.085 20.2171 10.433 20.2171C4.95566 20.2171 0.521637 15.9404 0.521637 10.4973C0.521637 9.84955 0.652008 9.20175 0.782349 8.55392L0.782471 8.55338C0.260834 7.77582 0 6.73904 0 5.70227C0 2.59195 2.60825 0 5.73813 0C6.91183 0 7.95514 0.388794 8.86801 0.907166C9.38965 0.777588 10.0417 0.777588 10.5634 0.777588ZM13.5627 16.718C14.4756 16.3292 15.1276 15.8108 15.6493 15.1628C16.1709 14.5149 16.3013 13.7373 16.0405 12.9597C16.0405 12.3117 15.9101 11.7933 15.6493 11.2749C15.3884 10.7565 14.9972 10.3677 14.4756 10.1086L14.4752 10.1084C13.9536 9.84924 13.4321 9.59012 12.7802 9.33096C12.5034 9.27597 12.2031 9.1976 11.8893 9.11572C11.4638 9.0047 11.0135 8.88718 10.5632 8.81259C10.1953 8.66635 9.86893 8.60263 9.60748 8.55157C9.40552 8.51215 9.24231 8.48029 9.12866 8.4238C8.86792 8.4238 8.60721 8.29428 8.34647 8.16473L8.34619 8.16461C8.08536 8.035 7.82455 7.90543 7.69412 7.77582C7.43329 7.64621 7.43329 7.51663 7.43329 7.25742C7.43329 6.86862 7.69412 6.60944 8.08536 6.35025C8.47659 6.09106 9.12866 5.96146 9.78073 5.96146C10.5632 5.96146 11.0848 6.09106 11.4761 6.35025C11.8673 6.60944 12.1281 6.86865 12.3889 7.38702C12.6497 7.77563 12.9104 8.03476 13.0408 8.16443L13.041 8.16461C13.3018 8.29419 13.5627 8.4238 13.9539 8.4238C14.3451 8.4238 14.7364 8.29419 14.9972 8.035C15.258 7.77582 15.3884 7.51663 15.3884 7.12784C15.3884 6.73904 15.3884 6.35025 15.1276 5.96146C15.0313 5.67429 14.7927 5.45782 14.5169 5.20764C14.4193 5.11908 14.317 5.02631 14.2147 4.92468C13.6931 4.6655 13.1714 4.40631 12.5194 4.14709C11.8673 4.01752 11.0848 3.88791 10.172 3.88791C9.12866 3.88791 8.08536 4.01752 7.30289 4.2767C6.39001 4.53589 5.73795 5.05429 5.34671 5.57266C4.95547 6.09106 4.69464 6.73904 4.69464 7.51663C4.69464 8.29419 4.95547 8.9422 5.34671 9.46057C5.73795 9.97897 6.39001 10.3677 7.04205 10.627C7.69412 10.8861 8.60703 11.1453 9.6503 11.4045C10.4328 11.5341 11.0848 11.6637 11.4761 11.7933C11.8673 11.9229 12.2585 12.0525 12.5194 12.3117C12.7802 12.5709 12.9106 12.8301 12.9106 13.2189C12.9106 13.6077 12.6498 13.9965 12.1281 14.3853C11.6065 14.774 10.9544 14.9036 10.172 14.9036C9.6503 14.9036 9.12866 14.774 8.73743 14.6444C8.47659 14.5149 8.21576 14.2556 7.95496 13.9965C7.91547 13.918 7.86407 13.8277 7.80792 13.7291C7.67859 13.5019 7.52423 13.2308 7.43329 12.9597C7.40817 12.9098 7.38306 12.855 7.35703 12.7983C7.24783 12.5604 7.12225 12.2867 6.91165 12.1821C6.65085 12.0525 6.39001 11.9229 5.99878 11.9229C5.60754 11.9229 5.21631 12.0525 4.95547 12.3117C4.69464 12.5709 4.56424 12.8301 4.56424 13.2189C4.56424 13.8669 4.82507 14.3853 5.21631 15.0332C5.73795 15.6812 6.25961 16.07 6.91165 16.4588C7.82455 16.9772 8.99823 17.2364 10.4328 17.2364C11.6065 17.2364 12.6498 17.1068 13.5627 16.718Z" transform="translate(9.07178 9.07178)" fill="white"></path></svg> <div style="display: table-cell;vertical-align: middle;padding-left:inherit;"> Skype<div>');
        $("#chatsms").css("display", "none");
        $("#chatmsg").css("display", "none");
        $("#chattlg").css("display", "none");
        $("#chatwhatsapp").css("display", "none");
        $("#chatskp").css('opacity', '0.2');
        $("#redsocial").val('skp');
    }

    function contador(c, num) {
        $.ajax({
            url: turnos.ajaxurl,
            type: 'post',
            data: {
                action: 'turnos',
                conteo: c,
                num: num
            },
            success: function(dato) {
                var num = JSON.parse(dato);
                var code = num['code'].replace(/ /g, "");
                var numero = num['numero'].replace(/ /g, "");
                var nombre = num['nombre'];
                if (num['nombre'] === null) {
                    document.getElementById("conectado").innerHTML = "";
                } else {
                    document.getElementById("conectado").innerHTML = nombre.substr(0, 12);
                }
                var url = location.href;
                document.getElementById("ifurl").value = num['ifurl'];
                document.getElementById("correoreceptor").value = num['correoreceptor'];
                document.getElementById("ifcookies").value = num['ifcookies'];
                document.getElementById("codereceptor").value = code;
                document.getElementById("numreceptor").value = numero;
                document.getElementById("namereceptor").value = nombre;
                document.getElementById("url").value = url;
                $("#inputmsg").val(num['linkmsg']);
                $("#inputSkp").val(num['userskp']);
                $("#inputTlg").val(num['usertlg']);
                $("#inputTlf").val(num['numtlf']);
                $("#inputSms").val(num['numsms']);
                if (numero === "") {
                    // document.getElementById("a").style.display="none";
                    // document.getElementById("c").setAttribute("class","sw-container sw-bottom sw-left");
                    document.getElementById("codereceptor").value = "";
                    document.getElementById("numreceptor").value = "";
                    document.getElementById("namereceptor").value = "";
                    document.getElementById("url").value = "";
                    document.getElementById("correoreceptor").value = "";
                    $("#inputmsg").val("");
                    $("#inputSkp").val("");
                    $("#inputTlg").val("");
                    $("#inputTlf").val("");
                    $("#inputSms").val("");
                }
                if (num['ifalert'] == 1) {
                    setTimeout(function() {
                        $(".tooltiptextt").css("visibility", "visible");
                        $(".tooltiptextt").css("opacity", "1");
                    }, 8000);
                }
                if (num['ifformulario'] == 0) {
                    $('#c').addClass('desactivar');
                    // if (num['ifurl'] == 0){
                    //     $("#btn-inicial").attr("href", "https://api.whatsapp.com/send?phone=" + code + numero + "&text=Hola, me gustaría más información.");
                    // }else{
                    //     $("#btn-inicial").attr("href", window.location + "receptorwaleads?numero=" + code + numero + "&msg=Hola, me gustaría más información.");
                    // }

                    // $("#btn-inicial").attr("target", "_blank");
                    // document.getElementById("btn-inicial").addEventListener(touchEvent, function() {
                    //     contador(1, numero);
                    // });
                } else {
                    // $("#btn-inicial").removeAttr("href");
                    // $("#btn-inicial").removeAttr("target");
                    // $(".textinvit").on(touchEvent, function() {
                    //     document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left is-expanded");
                    //     $(".tooltiptextt").css("display", "none");
                    //     $(".container-btn-ws").css("display", "none");
                    // });

                    if(num['wsp'] == 0){
                        $("#btn-inicial-wts").css('display', 'none');
                    }else{
                        $("#btn-inicial-wts").css('display', 'block');
                    }

                    if(num['msg']==0){
                        $("#btn-inicial-msg").css('display', 'none');
                    }else{
                        $("#btn-inicial-msg").css('display', 'block');
                    }

                    if(num['tlf']==0){
                        $("#btn-inicial-tlf").css('display', 'none');
                    }else{
                        $("#btn-inicial-tlf").css('display', 'block');
                    }

                    if(num['sms']==0){
                        $("#btn-inicial-sms").css('display', 'none');
                    }else{
                        $("#btn-inicial-sms").css('display', 'block');
                    }
                    if(num['tlg']==0){
                        $("#btn-inicial-tlg").css('display', 'none');
                    }else{
                        $("#btn-inicial-tlg").css('display', 'block');
                    }
                    if(num['skp']==0){
                        $("#btn-inicial-skp").css('display', 'none');
                    }else{
                        $("#btn-inicial-skp").css('display', 'block');
                    }

                    document.getElementById("btn-inicial-wts").addEventListener(touchEvent, function() {
                        btnwspfunc();
                    });
                    document.getElementById("btn-inicial-sms").addEventListener(touchEvent, function() {
                        btnsmsfunc();
                    });
                    document.getElementById("btn-inicial-msg").addEventListener(touchEvent, function() {
                        btnmsgfunc();
                    });

                    document.getElementById("btn-inicial-tlf").addEventListener(touchEvent, function() {
                        btntlffunc();
                    });
                    document.getElementById("btn-inicial-tlg").addEventListener(touchEvent, function() {
                        btntlgfunc();
                    });
                    document.getElementById("btn-inicial-skp").addEventListener(touchEvent, function() {
                        btnskpfunc();
                    });
                    document.getElementById("b").addEventListener(touchEvent, function() {
                        document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left");
                        $(".container-btn-ws").css("display", "block");
                        $(".sw-icon").html('');
                    });

                    $('#btn-chat').on(touchEvent,()=>{$(".tooltiptextt").css("display", "none");});
                    $('.tooltiptextt').on(touchEvent,()=>{$(".tooltiptextt").css("display", "none");});

                }
            }
        });
    }
    var codeip = $("#code").val();
    var tt = $("#sw-country-code").text();
    var res = tt.split(",");
    res.forEach(codect);

    function codect(item, index) {
        if (item.substr(0, 2) == codeip) {
            document.getElementById("sw-country-code")[index].setAttribute("selected", "true");
        }
    }
    setTimeout(function() {
        $("#btn-chat").css("visibility", "visible");
    }, 4000);
    $("#closev").on(touchEvent, function() {
        $(".tooltiptextt").css("display", "none");
    });



    if (document.getElementById("btnwsp")) {
        for (var i = 0; i < document.querySelectorAll("#btnwsp").length; i++) {
            document.querySelectorAll("#btnwsp")[i].addEventListener(touchEvent, btnwspfunc);
        }
    }
    if (document.getElementById("btnmsg")) {
        for (var i = 0; i < document.querySelectorAll("#btnmsg").length; i++) {
            document.querySelectorAll("#btnmsg")[i].addEventListener(touchEvent, btnmsgfunc);
        }
    }
    if (document.getElementById("btnsms")) {
        for (var i = 0; i < document.querySelectorAll("#btnsms").length; i++) {
            document.querySelectorAll("#btnsms")[i].addEventListener(touchEvent, btnsmsfunc);
        }
    }
    if (document.getElementById("btntlf")) {
        for (var i = 0; i < document.querySelectorAll("#btntlf").length; i++) {
            document.querySelectorAll("#btntlf")[i].addEventListener(touchEvent, btntlffunc);
        }
    }
    if (document.getElementById("btntlg")) {
        for (var i = 0; i < document.querySelectorAll("#btntlg").length; i++) {
            document.querySelectorAll("#btntlg")[i].addEventListener(touchEvent, btntlffunc);
        }
    }
    if (document.getElementById("btnskp")) {
        for (var i = 0; i < document.querySelectorAll("#btnskp").length; i++) {
            document.querySelectorAll("#btnskp")[i].addEventListener(touchEvent, btntlffunc);
        }
    }

    function validarformulario() {
        var ifurl = $("#ifurl").val();
        var name = $("#sw-name").val();
        var phonet = $("#sw-phone").val();
        var msg = $("#trabajo").val();

        msg = msg == "" ? "Hola, soy " + name + " y me gustaría más información." : "Hola, soy " + name + " y me gustaría consultar por: " + msg;
        var codereceptor = $("#codereceptor").val();
        var numreceptor = $("#numreceptor").val();
        if (document.getElementById('sw-correo')) {
            var cor = $("#sw-correo").val();
            var caract = new RegExp(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/);
            if (caract.test(cor) === false) {
                cor = false;
            }
        } else {
            cor = true;
        }
        if (name !== "" && cor) {
            $("#chatwhatsapp").css('opacity', '');
            $("#chatsms").css('opacity', '');
            $("#chatmsg").css('opacity', '');
            $("#chattlf").css('opacity', '');
            $("#chattlg").css('opacity', '');
            $("#chatskp").css('opacity', '');
            if (ifurl==0) {
                $("#chatwhatsapp").attr("href", "https://api.whatsapp.com/send?phone=" + codereceptor + numreceptor + "&text=" + msg);
            }else{
                $("#chatwhatsapp").attr("href", window.location + "receptorwaleads?numero=" + codereceptor + numreceptor + "&msg=" + msg);
            }
            let linkmsg = $("#inputmsg").val();
            let numsms = $("#inputSms").val();
            let userTelegram = $("#inputTlg").val();
            let numTlf = $("#inputTlf").val();
            let userSkype = $("#inputSkp").val();
            $("#chatmsg").attr("href", linkmsg);
            $("#chatsms").attr("href", "sms:+" + numsms + "&body="+msg);
            $("#chattlf").attr("href", "tel:+" + numTlf);
            $("#chattlg").attr("href", "https://telegram.me/" + userTelegram);
            $("#chatskp").attr("href", "skype:" + userSkype+"?chat");

        } else {

            $("#chatwhatsapp").css('opacity', '0.2');
            $("#chatsms").css('opacity', '0.2');
            $("#chatmsg").css('opacity', '0.2');
            $("#chattlf").css('opacity', '0.2');
            $("#chattlg").css('opacity', '0.2');
            $("#chatskp").css('opacity', '0.2');

            $("#chatwhatsapp").attr("href", "");
            $("#chatsms").attr("href", "");
            $("#chatmsg").attr("href", "");
            $("#chattlf").attr("href", "");
            $("#chattlg").attr("href", "");
            $("#chatskp").attr("href", "");
        }
    }
    $("#sw-name").keyup(function() {
        validarformulario();
    });
    if (document.getElementById('trabajo')) {
        $("#trabajo").change(function() {
            validarformulario();
        });
    }
    $("#sw-phone").keyup(function() {
        validarformulario();
    });
    if (document.getElementById('sw-correo')) {
        $("#sw-correo").keyup(function() {
            validarformulario();
        });
    }

    if (document.getElementById("swbtnconsulta")) {
        for (var i = 0; i < document.querySelectorAll("#swbtnconsulta").length; i++) {
            document.querySelectorAll("#swbtnconsulta")[i].addEventListener(touchEvent, FomularioExterno);
        }
    }

    async function FomularioExterno(e) {

        e.preventDefault();
        var swname = '',swtlf = '',swemail = '',switem1 = '',switem1title1 = '',switem2 = '',switem2title2 = '',switem3 = '',switem3title3 = '',switem4 = '',switem4title4 = '',switem5 = '',switem5title5 = '',swmsg = '';


        var form = this.form;
        jQuery(this.form).find(':input').each(function() {
            var elemento = this;
            var input = elemento.id;
            if (input.includes('swname')) {
                swname = elemento.value;
            }
            if (input.includes('swtlf')) {
                swtlf = elemento.value;
            }
            if (input.includes('swemail')) {
                swemail = elemento.value;
            }
            if (input.includes('switem1')) {
                switem1 = elemento.value;
                let switem1array = input.split('separar')
                let switem1title = switem1array[1].replace(/_/gi, function (x) {
                    return " ";
                });
                switem1title1 = switem1title;
            }
            if (input.includes('switem2')) {
                switem2 = elemento.value;
                let switem2array = input.split('separar')
                let switem2title = switem2array[1].replace(/_/gi, function (x) {
                    return " ";
                });
                switem2title2 = switem2title;
            }
            if (input.includes('switem3')) {
                switem3 = elemento.value;
                let switem3array = input.split('separar')
                let switem3title = switem3array[1].replace(/_/gi, function (x) {
                    return " ";
                });
                switem3title3 = switem3title;
            }
            if (input.includes('switem4')) {
                switem4 = elemento.value;
                let switem4array = input.split('separar')
                let switem4title = switem4array[1].replace(/_/gi, function (x) {
                    return " ";
                });
                switem4title4 = switem4title;
            }
            if (input.includes('switem5')) {
                switem5 = elemento.value;
                let switem5array = input.split('separar')
                let switem5title = switem5array[1].replace(/_/gi, function (x) {
                    return " ";
                });
                switem5title5 = switem5title;
            }
            if (input.includes('swmsg')) {
                swmsg = elemento.value;
            }
        });

        function enviarform() {
            jQuery('form[name ="swconsulta"]').submit();
            jQuery('#swbtnconsulta').show();
        }
        var coun_cod = $("#sw-country-code").val();
        var pais = $("#pais").val();
        var coderecepto = $("#codereceptor").val();
        var numrecepto = $("#numreceptor").val();
        var namerecepto = $("#namereceptor").val();
        var url = $("#url").val();
        var correoreceptor = $("#correoreceptor").val();
        jQuery('#swbtnconsulta').hide();
                  
        try {
            let options = {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                action: 'enviar',
                name: swname,
                coun_code: coun_cod,
                pais: pais,
                phonet: swtlf,
                correo: swemail,
                namereceptor: namerecepto,
                msg: swmsg,
                codereceptor: coderecepto,
                url: url,
                numreceptor: numrecepto,
                redsocial:"Formulario Externo",
                correoreceptor:correoreceptor,
                switem1,
                switem1title1,
                switem2,
                switem2title2,
                switem3,
                switem3title3,
                switem4,
                switem4title4,
                switem5,
                switem5title5
            })
            },
              res = await fetch(enviar.ajaxurl, options),
              json = await res.json();

            if (!res.ok) throw { status: res.status, statusText: res.statusText };

            setTimeout( enviarform(), 20000);
          } catch (err) {
            let message = err.statusText || "Ocurrió un error";
            console.log(`Error ${err.status}: ${message}`);
          }
    };
    
    function chatenviarmsg(e) {

        var name = $("#sw-name").val();
        var coun_code = $("#sw-country-code").val();
        var phonet = $("#sw-phone").val();
        var correo = "";
        if (document.getElementById('sw-correo')) {
            correo = $("#sw-correo").val();
        }
        if (document.getElementById('sw-correo')) {
            var cor = $("#sw-correo").val();
            var caract = new RegExp(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/);
            if (caract.test(cor) === false) {
                cor = true;
            } else {
                cor = false;
            }
        } else {
            cor = false;
        }
        var ifcookies = $("#ifcookies").val();
        var pais = $("#pais").val();
        var url = $("#url").val();
        var msg = $("#trabajo").val();
        var codereceptor = $("#codereceptor").val();
        var numreceptor = $("#numreceptor").val();
        var namereceptor = $("#namereceptor").val();
        var redsocial = $("#redsocial").val();
        var correoreceptor = $("#correoreceptor").val();
        if (name === "" || cor) {
            e.preventDefault();
        }

        function setCookie(cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        }

        function getCookie(cname) {
            var name = cname + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }
        if (ifcookies==1) {
            if (getCookie("whatsappactive") !== "horas") {
                enviarwl = true;
            }else{
                enviarwl = false;
            }
        }else{
            enviarwl = true;
        }
        if (enviarwl) {
        if (name !== "" && phonet !== "" && !cor) {
            fetch(enviar.ajaxurl, {
                            method: 'POST',
                            headers: {
                              'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: new URLSearchParams({
                    action: 'enviar',
                    name: name,
                    coun_code: coun_code,
                    pais: pais,
                    phonet: phonet,
                    correo: correo,
                    namereceptor: namereceptor,
                    msg: msg,
                    codereceptor: codereceptor,
                    url: url,
                    numreceptor: numreceptor,
                    redsocial:redsocial,
                    correoreceptor:correoreceptor
                }),
                        })
                          .then(res => (res.ok? res.json():Promise.reject(res)))
                          .then(data => {
                            let d = data;
                            if (d[`respuesta`] == 0 || d[`respuesta`] == 1 || d[`respuesta`] == 2 ) {
                                alert(d[`msgresp`]);
                            }else if (d[`subscri`] != 200) {
                                alert(d['subscrierror']+" " + d[`subscri`] + ", "+d[`subscrimsg`]);
                            } else {
                                document.getElementById("c").setAttribute("class", "sw-container sw-bottom sw-left");
                                $(".container-btn-ws").css("display", "block");
                                $(".sw-icon").html('');
                                var numero = d[`receptor`].replace(/ /g, "");
                                // var open = window.open("https://api.whatsapp.com/send?phone="+numero+"&text="+d[`msg`], "_blank");
                                // if (open === null || typeof(open)=='undefined'){
                                //     alert("Te escribiremos al WhatsApp de inmediato. Espera el mensaje");
                                //     window.open("https://api.whatsapp.com/send?phone="+numero+"&text="+d[`msg`]);
                                // }
                                contador(1, numero);
                                setCookie("whatsappactive", "horas", 2);
                            }
                        })
                        .catch(error => {
                            let message = err.statusText || "Ocurrió un error";
                            console.log(`Error ${err.status}: ${message}`);
                        });
        } else {
            alert("Tiene que llenar todos los campos");
        }
        } else {
            alert("Hemos recibido tus datos y estaremos contactándote al WhatsApp en un momento");
        }
    }
    
    document.getElementById("chatwhatsapp").addEventListener(touchEvent, chatenviarmsg);
    document.getElementById("chatsms").addEventListener(touchEvent, chatenviarmsg);
    document.getElementById("chatmsg").addEventListener(touchEvent, chatenviarmsg);
    document.getElementById("chattlf").addEventListener(touchEvent, chatenviarmsg);
    
})(jQuery);