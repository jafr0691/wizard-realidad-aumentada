<?php
	
	require 'funcs/conexion.php';
	require 'funcs/funcs.php';
	
	if(isset($_GET["id"]) AND isset($_GET['val']))
	{
		
		$idUsuario = $_GET['id'];
		$token = $_GET['val'];
		
		$mensaje = validaIdToken($idUsuario, $token);	
	}
?>

<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Registro</title>
		<link rel="stylesheet" href="<?php echo ARCHIVOturno; ?>css/bootstrap.min.css" >
		<link rel="stylesheet" href="<?php echo ARCHIVOturno; ?>css/bootstrap-theme.min.css" >
		
	</head>
	
	<body>
		<div class="container">
			<div class="jumbotron">
				
				<h1><?php echo $mensaje; ?></h1>
				
				<br />
				<p><button class="btn btn-primary btn-lg" onClick="Finalizar();" role="button">Aceptar</button></p>
			</div>
		</div>
		<script>
		    function Finalizar() {        
    window.location=location.origin;
}
		</script>
	</body>
</html>														