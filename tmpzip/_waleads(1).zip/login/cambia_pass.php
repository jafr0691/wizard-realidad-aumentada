<?php
	require 'funcs/conexion.php';
	include 'funcs/funcs.php';
	session_start();
	
	if(empty($_GET['user_id'])){
		header('Location: index.php');
	}
	
	if(empty($_GET['token'])){
		header('Location: index.php');
	}
	
	$user_id = $mysqli->real_escape_string($_GET['user_id']);
	$token = $mysqli->real_escape_string($_GET['token']);
	?>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Cambiar Password</title>
		
		<link rel="stylesheet" href="<?php echo ARCHIVOturno; ?>css/bootstrap.min.css" >
		<link rel="stylesheet" href="<?php echo ARCHIVOturno; ?>css/bootstrap-theme.min.css" >
		<!-- <script src="js/bootstrap.min.js" ></script> -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
	</head>
	<div class="modal fade" id="Modalverificar" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">

					<h4 class="modal-title" id="titlemsj"></h4>
				</div>
				<div class="modal-body text-center" id="imp1">
					<strong><p id="mensaje">No se pudo verificar los Datos:</p></strong>
				</div>
				<div class="modal-footer">
					<button class="btn btn-success mr-5" id="rechazado">Aceptar</button>
					<div id="btnmodal"></div>
				</div>
			</div>
		</div>
	</div>
	
<?php
	
	if(!verificaTokenPass($user_id, $token))
	{
		echo "<script>$('#Modalverificar').modal('show');</script>";
		exit;
	} 
?>

	<body>
		
		<div class="container">    
			<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
				<div class="panel panel-info" >
					<div class="panel-heading">
						<div class="panel-title">Cambiar Password</div>
						<div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="index.php">Iniciar Sesi&oacute;n</a></div>
					</div>     
					
					<div style="padding-top:30px" class="panel-body" >
						
						<div id="loginform" class="form-horizontal">
							
							<input type="hidden" id="user_id" name="user_id" value ="<?php echo $user_id; ?>" />
							
							<input type="hidden" id="token" name="token" value ="<?php echo $token; ?>" />
							
							<div class="form-group">
								<label for="password" class="col-md-3 control-label">Nuevo Password</label>
								<div class="col-md-9">
									<input type="password" class="form-control" name="password" id="password" placeholder="Password" required autocomplete="off">
								</div>
							</div>
							
							<div class="form-group">
								<label for="con_password" class="col-md-3 control-label">Confirmar Password</label>
								<div class="col-md-9">
									<input type="password" class="form-control" name="con_password" id="con_password" placeholder="Confirmar Password" required autocomplete="off">
								</div>
							</div>
							
							<div style="margin-top:10px" class="form-group">
								<div class="col-sm-12 controls">
									<button id="btn-login" class="btn btn-success">Modificar</button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="carga" width="100px" height="60px">
								</div>
							</div>   
						</div>
						<div id="errors"></div>
					</div>                     
				</div>  
			</div>
		</div>
		<div class="modal fade" id="Modalmodificar" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">

					<h4 class="modal-title" id="titlemsj"></h4>
				</div>
				<div class="modal-body text-center" id="imp1">
					<strong><p id="mensaje">Contrase&ntilde;a Modificada:</p></strong>
				</div>
				<div class="modal-footer">
					<button class="btn btn-success mr-5" id="aceptar">Aceptar</button>
					<div id="btnmodal"></div>
				</div>
			</div>
		</div>
	</div>
		<script type="text/javascript">
		$("#aceptar").click(function(){
		    window.close();
		});
		$("#rechazado").click(function(){
		    window.close();
		});
		
		
		$("#btn-login").click(function(){
			var  user_id = $('#user_id').val();
			var  token = $('#token').val();
			var  pass = $('#password').val();
			var  con_pass = $('#con_password').val();
			
			if(user_id!="" && pass!="" && con_pass!="" && token!=""){
				$.ajax({
					url: "guarda_pass.php",
					type: 'post',
					data: {user_id:user_id,password:pass,con_password:con_pass,token:token},
					beforeSend: function(){
						$('#carga').css('display','inline-block');
					},
					success: function(dato) {
						if(dato==true){
							$('#Modalmodificar').modal("show");
						}else{
							$("#errors").html(dato);
						}
						$('#carga').css('display','none');
					}
				});
			}else{
				alert("No deje ningun campo vacio");
			}
		});
	</script>
	</body>
</html>