<?php


include $_SERVER['DOCUMENT_ROOT'] .'/wp-content/plugins/serviciowhatsapp/admin/control.php';


?>