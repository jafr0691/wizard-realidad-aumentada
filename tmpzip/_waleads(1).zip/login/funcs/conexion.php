<?php
if(file_exists("../../../../wp-config.php")){
    require_once('../../../../wp-config.php');
}else{
    require_once($_SERVER['DOCUMENT_ROOT'] .'/wp-config.php');
}

$dbname   = DB_NAME;
$user     = DB_USER;
$password = DB_PASSWORD;
global $wpdb;

$conteo   = $wpdb->prefix . 'sw_conteo';
$agente   = $wpdb->prefix . 'sw_agente';
$jornada  = $wpdb->prefix . 'sw_jornada';
$contactos   = $wpdb->prefix . 'sw_contactos_whatsapp';
$phpmailer  = $wpdb->prefix . 'sw_phpmailer';
	
	$mysqli=new mysqli("localhost",$user,"$password",$dbname); 
	
	if(mysqli_connect_errno()){
		echo 'Conexion Fallida : ', mysqli_connect_error();
		exit();
	}