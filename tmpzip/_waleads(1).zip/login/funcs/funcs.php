<?php
require DOCUMENTOturno.'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
$mail = new PHPMailer(true);
function isNull($nombre, $pass, $pass_con, $email, $numero)
{
    if (strlen(trim($nombre)) < 1 || strlen(trim($pass)) < 1 || strlen(trim($pass_con)) < 1 || strlen(trim($email)) < 1 || strlen(trim($numero)) < 1) {
        return true;
    } else {
        return false;
    }
}

function isEmail($email)
{
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;
    } else {
        return false;
    }
}

function validaPassword($var1, $var2)
{
    if (strcmp($var1, $var2) !== 0) {
        return false;
    } else {
        return true;
    }
}

function minMax($min, $max, $valor)
{
    if (strlen(trim($valor)) < $min) {
        return true;
    } else if (strlen(trim($valor)) > $max) {
        return true;
    } else {
        return false;
    }
}

function emailExiste($email)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT id_agente FROM $agente WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $num = $stmt->num_rows;
    $stmt->close();

    if ($num > 0) {
        return true;
    } else {
        return false;
    }
}

function numeroExiste($numero)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT id_agente FROM $agente WHERE numero = ? LIMIT 1");
    $stmt->bind_param("s", $numero);
    $stmt->execute();
    $stmt->store_result();
    $num = $stmt->num_rows;
    $stmt->close();

    if ($num > 0) {
        return true;
    } else {
        return false;
    }
}

function generateToken()
{
    $gen = md5(uniqid(mt_rand(), false));
    return $gen;
}

function hashPassword($password)
{
    $hash = password_hash($password, PASSWORD_DEFAULT);
    return $hash;
}

function resultBlock($errors)
{
    if (count($errors) > 0) {
        echo "<div id='error' class='alert alert-danger' role='alert'>
			<ul>";
        foreach ($errors as $error) {
            echo "<li>" . $error . "</li>";
        }
        echo "</ul>";
        echo "</div>";
    }
}

function registraUsuario($pass_hash, $nombre, $email, $code, $numero, $activo, $token, $tipo)
{

    global $mysqli, $agente, $jornada;
    $turno = 3;
    $stmt  = $mysqli->prepare("INSERT INTO $agente (password,tipo, nombre, email,code, numero, turno, activacion, token) VALUES(?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param('sissisiis', $pass_hash, $tipo, $nombre, $email, $code, $numero, $turno, $activo, $token);

    if ($stmt->execute()) {
        $fechainicio = date("m/d/Y");
        $cero        = 0;
        $idjor       = $mysqli->insert_id;
        $stmtt       = $mysqli->prepare("INSERT INTO $jornada (id_agente,entrada,salida, fechainicio) VALUES(?,?,?,?)");
        $stmtt->bind_param('iiis', $idjor, $cero, $cero, $fechainicio);
        $stmtt->execute();
        return $idjor;
    } else {
        return 0;
    }
    exit;
}

function enviarEmail($email, $nombre, $asunto, $cuerpo)
{
    $id = 1;
    global $mysqli, $phpmailer, $mail;
    $stmt = $mysqli->prepare("SELECT host,mailerusername,password,setfrom,titlesetfrom FROM $phpmailer WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($host, $mailerusername, $password, $setfrom, $titlesetfrom);
    $stmt->fetch();
    $stmt->close();

    $mail->CharSet = "UTF-8";
    $mail->isSMTP()
    ;
    $mail->Host     = $host; //Modificar
    $mail->SMTPAuth = true;
    $mail->Port     = 587; //Modificar

    $mail->Username = $mailerusername; //Modificar
    $mail->Password = $password; //Modificar

    $mail->setFrom($setfrom, $titlesetfrom); //Modificar
    $mail->addAddress($email, $nombre);

    $mail->Subject = $asunto;
    $mail->Body    = $cuerpo;
    $mail->IsHTML(true);
    if ($mail->send()) {
        return true;
    } else {
        return false;
    }

}

function validaIdToken($id, $token)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT activacion FROM $agente WHERE id_agente = ? AND token = ? LIMIT 1");
    $stmt->bind_param("is", $id, $token);
    $stmt->execute();
    $stmt->store_result();
    $rows = $stmt->num_rows;

    if ($rows > 0) {
        $stmt->bind_result($activacion);
        $stmt->fetch();

        if ($activacion == 1) {
            $msg = "La cuenta ya se activo anteriormente.";
        } else {
            if (activarUsuario($id)) {
                $msg = 'Cuenta activada.';
            } else {
                $msg = 'Error al Activar Cuenta';
            }
        }
    } else {
        $msg = 'No existe el registro para activar.';
    }
    return $msg;
}

function activarUsuario($id)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("UPDATE $agente SET activacion=1 WHERE id_agente = ?");
    $stmt->bind_param('s', $id);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

function isNullLogin($correo, $password)
{
    if (strlen(trim($correo)) < 1 || strlen(trim($password)) < 1) {
        return true;
    } else {
        return false;
    }
}

function login($correo, $password)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT id_agente, password,tipo FROM $agente WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $stmt->store_result();
    $rows = $stmt->num_rows;

    if ($rows > 0) {

        if (isActivo($correo)) {

            $stmt->bind_result($id, $passwd, $tipo);
            $stmt->fetch();

            $validaPassw = password_verify($password, $passwd);

            if ($validaPassw) {

                lastSession($id);
                $_SESSION['id_usuario'] = $id;
                $_SESSION['tipo']       = $tipo;
                if ($tipo == 1) {
                    header("location: ../admin/control.php");
                } else {
                    header("location: welcome.php");
                }

            } else {

                $errors = "El usuario o contrase&ntilde;a electr&oacute;nico no existe";
            }
        } else {
            $errors = 'El usuario no esta activo';
        }
    } else {
        $errors = "El usuario o contrase&ntilde;a electr&oacute;nico no existe";
    }
    return $errors;
}

function lastSession($id)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("UPDATE $agente SET last_session=NOW(), token_password='', password_request=0 WHERE id_agente = ?");
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $stmt->close();
}

function isActivo($correo)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT activacion FROM $agente WHERE email = ? LIMIT 1");
    $stmt->bind_param('s', $correo);
    $stmt->execute();
    $stmt->bind_result($activacion);
    $stmt->fetch();

    if ($activacion == 1) {
        return true;
    } else {
        return false;
    }
}

function generaTokenPass($user_id)
{
    global $mysqli, $agente;

    $token = generateToken();

    $stmt = $mysqli->prepare("UPDATE $agente SET token_password=?, password_request=1 WHERE id_agente = ?");
    $stmt->bind_param('ss', $token, $user_id);
    $stmt->execute();
    $stmt->close();

    return $token;
}

function getValor($campo, $campoWhere, $valor)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT $campo FROM $agente WHERE $campoWhere = ? LIMIT 1");
    $stmt->bind_param('s', $valor);
    $stmt->execute();
    $stmt->store_result();
    $num = $stmt->num_rows;

    if ($num > 0) {
        $stmt->bind_result($_campo);
        $stmt->fetch();
        return $_campo;
    } else {
        return null;
    }
}

function getPasswordRequest($id)
{
    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT password_request FROM $agente WHERE id_agente = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->bind_result($_id);
    $stmt->fetch();

    if ($_id == 1) {
        return true;
    } else {
        return null;
    }
}

function verificaTokenPass($user_id, $token)
{

    global $mysqli, $agente;

    $stmt = $mysqli->prepare("SELECT activacion FROM $agente WHERE id_agente = ? AND token_password = ? AND password_request = 1 LIMIT 1");
    $stmt->bind_param('is', $user_id, $token);
    $stmt->execute();
    $stmt->store_result();
    $num = $stmt->num_rows;

    if ($num > 0) {
        $stmt->bind_result($activacion);
        $stmt->fetch();
        if ($activacion == 1) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function cambiaPassword($password, $user_id, $token)
{

    global $mysqli, $agente;

    $stmt = $mysqli->prepare("UPDATE $agente SET password = ?, token_password='', password_request=0 WHERE id_agente = ? AND token_password = ?");
    $stmt->bind_param('sis', $password, $user_id, $token);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

function code()
{

    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }

    $visitor  = $ip;
    $datocode = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=" . $visitor));
    $code     = $datocode["geoplugin_countryCode"];
    return $code;
}
