<?php
	require 'funcs/conexion.php';
	include 'funcs/funcs.php';
	
	session_start(); //Iniciar una nueva sesión o reanudar la existente

	?>
		<div class="container" id="login">    
			<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
				<div class="panel panel-info" >
					<div class="panel-heading">
						<div class="panel-title" style="display: inline;">Iniciar Sesi&oacute;n</div>
						<div style="float:right; font-size: 80%; position: relative; top:-10px; display: inline;"><strong  data-toggle="modal" data-target="#Modalrecuperar" class="btn">¿Se te olvid&oacute; tu contraseña?</strong> </div>
					</div>     
					
					<div style="padding-top:30px" class="panel-body" >
						
						<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
						
						<div class="form-horizontal">
							
							<div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><strong>@</strong></span>
								<input type="email" class="form-control" name="correo" id="emaillogin" value="" placeholder="email" required autocomplete="off">                                        
							</div>
							
							<div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
								<input id="password" type="password" class="form-control" name="password" placeholder="password" required autocomplete="off">
							</div>
							
							<div style="margin-top:10px" class="form-group">
								<div class="col-sm-12 controls">
									<button id="btn-login" class="btn btn-success">Iniciar Sesi&oacute;n</button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="cargalogin" width="100px" height="60px">
								</div>
							</div>
							
							<div class="form-group">
							    <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
								<div class="col-md-9">
									
								</div>
								<div class="col-md-3">
									<a href="https://api.whatsapp.com/send?phone=573127966077&text=necesito información" title="Si eres profesional de las artes esotéricas y necesitas información de nuestro servicio, contáctanos" target="_blank"><img alt="WhatsApp" width="32" height="32" src="https://res.cloudinary.com/hbrrdozyj/image/upload/v1558627723/whatsapp-logo_tyn8iu.svg"></a>
								</div></div>
							</div>    
						</div>
						<div id="errorslogin"></div>
					</div>                     
				</div>  
			</div>
		</div>
		<div id="inicio"></div>
		<div class="modal fade" id="Modalrecuperar" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-body">                      
				<div class="panel panel-info" >
					<div class="panel-heading">
						<div class="panel-title">Recuperar Password</div>
					</div>     
					
					<div style="padding-top:30px" class="panel-body" >
						
						<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
						
						<div id="loginform" class="form-horizontal" role="form">
							
							<div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
								<input id="email" type="email" class="form-control" name="email" placeholder="email" autocomplete="off" required>                                        
							</div>
							
							<div style="margin-top:10px" class="form-group">
								<div class="col-sm-12 controls">
									<button id="btn-loginrecupe" class="btn btn-success" style="display: inline;">Enviar</button><img style="display: none;" src="<?php echo ARCHIVOturno; ?>img/carga.gif" id="carga" width="100px" height="60px">
								</div>
							</div>
						</div>
						<!-- <div class="text-left"> -->
					<div id="errors"></div>
				</div>
					<!-- </div>                      -->
				</div>  

		</div>
		</div>
		
	</div>

		<div class="modal fade" id="Modalenviado" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">

					<h4 class="modal-title" id="titlemsj"></h4>
				</div>
				<div class="modal-body text-center" id="imp1">
					<p id="mensaje">Hemos enviado un correo electronico a las direcion <strong id="Modalemail"></strong> para restablecer tu password</p>
				</div>
				<div class="modal-footer">
					<a href='index.php' class="btn btn-success mr-5">Iniciar Sesion</a>
					<div id="btnmodal"></div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
	jQuery( document ).ready( function( $ ) {
	var touchEvent = 'ontouchstart' in window ? 'touchstart' : 'click';
		ruta = "<?php echo ARCHIVOturno; ?>";

			<?php
	if(isset($_SESSION["id_usuario"])){ 
		
	?>
	$.ajax({
					url: ruta+"login/login.php",

					success: function(data) {
						if(data.length>1295){
				            $('#login').css('display','none');
							$("#inicio").html(data);
							$("#logout").css("display","inline-block");
						}
					}
				});
	
	<?php
	}
	?>

		$("#btn-loginrecupe").on(touchEvent,function(){
			var email = $("#email").val();
			if (email!="") {
				$.ajax({
					url: ruta+"login/recuperarscript.php",
					type: 'post',
					data: {email:email},
					beforeSend: function(){
						$('#carga').css('display','inline-block');
					},
					success: function(dato) {
						if(dato == 1){

				         $('#Modalemail').text(email);
				     	 $('#Modalenviado').modal("show");

						  //alert("Fue enviado un correo al email "+email+" para recuperar la contraseña");
						  //location.reload();
						    
						}else{
							$("#errors").html(dato);
							setTimeout(function(){$("#errors").empty();},10000);
						}
						$('#carga').css('display','none');
					}
				});
			}
		});
		$("#btn-login").on(touchEvent,function(){
			var email = $("#emaillogin").val();
			var pass = $("#password").val();
			if (email!="" || pass!="") {
				$.ajax({
					url: ruta+"login/login.php",
					type: 'post',
					data: {correo:email,password:pass},
					beforeSend: function(){
						$('#cargalogin').css('display','inline-block');
					},
					success: function(data) {
						if(data.length>1295){
				            $('#login').css('display','none');
							$("#inicio").html(data);
							$("#logout").css("display","inline-block");
						}else{
							$("#errorslogin").html(data);
							setTimeout(function(){$("#errorslogin").empty();},10000);
						}
						$('#cargalogin').css('display','none');
					}
				});
			}
			$("#password").val("");
		});
	} );
	</script>
