<?php
	require 'funcs/conexion.php';
	include 'funcs/funcs.php';
	
	session_start(); //Iniciar una nueva sesión o reanudar la existente
	
	if(isset($_SESSION["id_usuario"])){ //En caso de existir la sesión redireccionamos
    	if($_SESSION["tipo"]==1){
    		header("Location: ../admin/control.php");
    	}else{
    	    header("Location: welcome.php");
    	}
	}
	
	$errors = array();
	
	if(!empty($_POST))
	{
		$correo = $mysqli->real_escape_string($_POST['correo']);
		$password = $mysqli->real_escape_string($_POST['password']);
		
		if(isNullLogin($correo, $password))
		{
			$errors[] = "Debe llenar todos los campos";
		}
		
		$errors[] = login($correo, $password);	
		exit(resultBlock($errors));
	}
?>