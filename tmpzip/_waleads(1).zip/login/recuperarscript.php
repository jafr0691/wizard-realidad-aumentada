<?php
	require 'funcs/conexion.php';
	include 'funcs/funcs.php';
	
	$errors = array();
	
	if(!empty($_POST))
	{
		$email = $mysqli->real_escape_string($_POST['email']);
		
		if(!isEmail($email))
		{
			$errors[] = "Debe ingresar un correo electronico valido";
		}
		
		if(emailExiste($email))
		{			
			$user_id = getValor('id_agente', 'email', $email);
			$nombre = getValor('nombre', 'email', $email);
			
			$token = generaTokenPass($user_id);
			
			$url = 'http://'.$_SERVER["SERVER_NAME"].'/wp-content/plugins/serviciowhatsapp/login/cambia_pass.php?user_id='.$user_id.'&token='.$token;
			
			$asunto = 'Recuperar Password - Sistema de Usuarios';
			$cuerpo = '<body><div style="margin:0;padding:0">
    <div style="border:0px solid;border-color:#cecece;max-width:650px;margin:auto">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tbody>
                <tr>
                    <td style="padding:15px 15px 15px 15px" bgcolor="#ffffff" align="center">
                        <table width="500" cellspacing="0" cellpadding="0" border="0">
                            <tbody>
                                <tr>
                                    <td>
                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                            <tbody>
                                                <tr>
                                                    <td style="padding:20px 0 0 0;font-size:16px;line-height:25px;font-family:Helvetica,Arial,sans-serif;color:#666666" align="left">
                                                        Hola, Estimado <strong style="color:#26a9e0">'.$nombre.':</strong><br>
                                                        <br> Se ha solicitado un reinicio de contrase&ntilde;a. <br/><br/>Para restaurar la contrase&ntilde;a, visita la siguiente direcci&oacute;n dando click al botón:
                                                        <br><br>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="center">
                                                        <br><br>
                                                        <a href="'.$url.'" style="font-size:12px;font-family:Helvetica,Arial,sans-serif;font-weight:normal;color:#ffffff;text-decoration:none;background-color:#128c7e;border-top:7px solid #128c7e;border-bottom:7px solid #128c7e;border-left:20px solid #128c7e;border-right:20px solid #128c7e;border-radius:35px;display:inline-block" target="_blank">
                                                            <span style="vertical-align:-webkit-baseline-middle">Cambiar Contraseña</span>
                                                        </a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div></body>';
			
			if(enviarEmail($email, $nombre, $asunto, $cuerpo)){
				exit(true);
			}
			} else {
			$errors[] = "La direccion de correo electronico no existe";
		}
	}
	exit(resultBlock($errors));
?>