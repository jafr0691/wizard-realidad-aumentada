<?php
	require 'funcs/conexion.php';
	include 'funcs/funcs.php';

	$errors = array();
	
	if(!empty($_POST))
	{
		$nombre = $mysqli->real_escape_string($_POST['nombre']);
		$password = $mysqli->real_escape_string($_POST['password']);
		$con_password = $mysqli->real_escape_string($_POST['con_password']);
		$email = $mysqli->real_escape_string($_POST['email']);
		$code = $mysqli->real_escape_string($_POST['code']);
		$numero = $mysqli->real_escape_string($_POST['numero']);
		$tipo = $mysqli->real_escape_string($_POST['tipo']);
		$activo = 1;
		
		if(isNull($nombre, $password, $con_password, $email,$numero))
		{
			$errors[] = "Debe llenar todos los campos";
		}
		
		if(!isEmail($email))
		{
			$errors[] = "Dirección de correo inválida";
		}
		
		if(numeroExiste($numero))
		{
			$errors[] = "Numero ya exite";
		}
		
		if(!validaPassword($password, $con_password))
		{
			$errors[] = "Las contraseñas no coinciden";
		}		
		
		
		if(emailExiste($email))
		{
			$errors[] = "El correo electronico $email ya existe";
		}
		
		if(count($errors) == 0)
		{
			
				
				$pass_hash = hashPassword($password);
				$token = generateToken();
				
				$registro = registraUsuario($pass_hash, $nombre, $email, $code, $numero, $activo, $token,$tipo);			
				if($registro > 0)
				{				
						$data = true;
						exit($data);
					
					} else {
					$errors[] = "Error al Registrar";
				}

		}
	}

	exit(resultBlock($errors));
?>