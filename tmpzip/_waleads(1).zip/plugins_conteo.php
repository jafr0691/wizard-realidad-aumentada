<?php
/*
Plugin Name: waleads
Plugin URI:  https://www.waleads.com
Description: Seguimiento de los contactos que se conectan por ID btnwsp, btnsms, btnmsg, btntlg, btnskp y btntlf [usuarios_contactos], formulario name ( swconsulta ) ID campos: ( swname, swtlf, swemail, swhabit, swtoilets, swtam, swserv, swmsg ) ID Boton ( swbtnconsulta ).
Version:     1.1.4
Author:      Federico Avila
Author URI:  https://digitalmarketing.net.co
Domain Path: /languages/
Text Domain: wa-leads
 */
defined('ABSPATH') or die('No script please!');

global $wpdb;
define('DOCUMENTOturno', plugin_dir_path(__FILE__));
define('ARCHIVOturno', plugin_dir_url(__FILE__));


function waleads_update_cheker() {
    require_once DOCUMENTOturno . 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';

    $myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
        'https://waleads.com/repository/plugins/waleads/details.json',
        __FILE__, 'waleads'
    );
}
add_action( 'plugins_loaded', 'waleads_update_cheker' );

function traducciones_plugin_waleads()
{
    $dir = basename(dirname(__FILE__));
    load_plugin_textdomain('wa-leads', false, $dir . '/languages');
}
add_action('init', 'traducciones_plugin_waleads');
function getIp()
{
    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }

    return $ip;
}
// $code   = "CO";
// $pais   = "COLOMBIA";
// $region = "Bogota D.C.";
// date_default_timezone_set("America/Bogota");

function db_turnos()
{
    require_once DOCUMENTOturno . 'bd.php';
}
function turnos_js()
{
    wp_register_script('script_turnos', plugin_dir_url(__FILE__) . 'js/turnos.js', array('jquery'), '2', true);
    wp_enqueue_script('script_turnos');
    wp_localize_script('script_turnos', 'turnos', ['ajaxurl' => admin_url('admin-ajax.php')]);
    wp_localize_script('script_turnos', 'enviar', ['ajaxurl' => admin_url('admin-ajax.php')]);
}
add_action('wp_enqueue_scripts', 'turnos_js');
add_action('wp_ajax_turnos', 'turnos');
add_action('wp_ajax_nopriv_turnos', 'turnos');

function admincontrol()
{
    require_once DOCUMENTOturno . 'vendor/autoload.php';
    include DOCUMENTOturno . 'admin/function.php';
    require_once DOCUMENTOturno . 'admin/action.php';
}
function sw_control_jquery($hook_suffix)
{
    if (! did_action( 'wp_enqueue_media')) {
        wp_enqueue_media();
    }
    wp_enqueue_script('bootstrap.3.4.1.min_file', 'https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js');
    wp_register_script('script_admincontrol', plugin_dir_url(__FILE__) . 'js/admincontrol.js', array('jquery'),  '1', true);
    wp_enqueue_script('script_admincontrol');
    wp_localize_script('script_admincontrol', 'admincontrol', ['admincontrolajaxurl' => admin_url('admin-ajax.php')]);
}
add_action('admin_enqueue_scripts', 'sw_control_jquery');
add_action('wp_ajax_admincontrol', 'admincontrol');
add_action('wp_ajax_nopriv_admincontrol', 'admincontrol');

function usuario_jquery()
{
    wp_enqueue_style('MyPluginStyles', plugins_url('/css/button.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'usuario_jquery');

function add_text_to_content($content)
{
    global $wpdb;
    $formulario = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "sw_formulario where id_formulario=1");
    $opciones   = array($formulario->opcion1, $formulario->opcion2, $formulario->opcion3, $formulario->opcion4, $formulario->opcion5, $formulario->opcion6, $formulario->opcion7, $formulario->opcion8, $formulario->opcion9, $formulario->opcion10);
    $visitor    = getIp();
    $datocode   = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=" . $visitor));
    $code       = $datocode["geoplugin_countryCode"];
    $pais       = $datocode["geoplugin_countryName"];
    $region     = $datocode["geoplugin_city"];
    $content .= '<div class="sw-container sw-bottom sw-left" id="c" style="opacity:0; font-size:200px;">
    <span class="tooltiptextt"><p> <span class="online"></span> <strong id="conectado"> </strong><strong> ' . esc_html__('en Línea', 'wa-leads') . '</strong> <strong id="closev" style="position: absolute; right: 5%; top: 5%;"> X</strong></p><p class="textinvit">' . $formulario->alert . '</p></span>
    <div class="wsp-card">
    <!-- WIDGET -->


            <div class="container-btn-ws">
        <input type="checkbox" id="btn-mas-ws">
        <div class="redes-ws">
            <div id="btn-inicial-wts" class="tooltip-right" data-tooltip="' . esc_html__('Hablemos por WhatsApp', 'wa-leads') . '">
                <svg class="ico_d " width="54" height="54" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#49E670"></circle><path d="M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z" transform="translate(12.9597 12.9597)" fill="#FAFAFA"></path><path d="M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z" transform="translate(7.7758 7.77582)" fill="white" stroke="white" stroke-width="0.2"></path></svg>
            </div>
            <div id="btn-inicial-sms" class="tooltip-right" data-tooltip="' . esc_html__('Escríbenos un SMS', 'wa-leads') . '">
                <svg class="ico_d " width="54" height="54" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#FF549C"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M2.60298 0H16.9194C18.351 0 19.5224 1.19321 19.5224 2.65158V14.5838C19.5224 16.0421 18.351 17.2354 16.9194 17.2354H7.4185L3.64418 20.4173C3.51402 20.5499 3.38388 20.5499 3.25372 20.5499H2.99344C2.73314 20.4173 2.60298 20.1521 2.60298 19.887V17.2354C1.17134 17.2354 0 16.0421 0 14.5838V2.65158C0 1.19321 1.17134 0 2.60298 0ZM2.60316 11.2696C2.60316 11.6673 2.86346 11.9325 3.25391 11.9325H4.5554C5.5966 11.9325 6.50764 11.0044 6.50764 9.94376C6.50764 8.88312 5.5966 7.95505 4.5554 7.95505C4.16496 7.95505 3.90465 7.68991 3.90465 7.29218C3.90465 6.89441 4.16496 6.62927 4.5554 6.62927H5.85689C6.24733 6.62927 6.50764 6.36411 6.50764 5.96637C6.50764 5.56863 6.24733 5.30347 5.85689 5.30347H4.5554C3.51421 5.30347 2.60316 6.23154 2.60316 7.29218C2.60316 8.35281 3.51421 9.28085 4.5554 9.28085C4.94585 9.28085 5.20613 9.54602 5.20613 9.94376C5.20613 10.3415 4.94585 10.6067 4.5554 10.6067H3.25391C2.86346 10.6067 2.60316 10.8718 2.60316 11.2696ZM14.9678 11.9325H13.6664C13.2759 11.9325 13.0156 11.6673 13.0156 11.2696C13.0156 10.8718 13.2759 10.6067 13.6664 10.6067H14.9678C15.3583 10.6067 15.6186 10.3415 15.6186 9.94376C15.6186 9.54602 15.3583 9.28085 14.9678 9.28085C13.9267 9.28085 13.0156 8.35281 13.0156 7.29218C13.0156 6.23154 13.9267 5.30347 14.9678 5.30347H16.2693C16.6598 5.30347 16.9201 5.56863 16.9201 5.96637C16.9201 6.36411 16.6598 6.62927 16.2693 6.62927H14.9678C14.5774 6.62927 14.3171 6.89441 14.3171 7.29218C14.3171 7.68991 14.5774 7.95505 14.9678 7.95505C16.009 7.95505 16.9201 8.88312 16.9201 9.94376C16.9201 11.0044 16.009 11.9325 14.9678 11.9325ZM10.4126 11.2697C10.4126 11.6674 10.6729 11.9326 11.0633 11.9326C11.4538 11.9326 11.7141 11.6674 11.8442 11.2697V5.96649C11.8442 5.70135 11.5839 5.43619 11.3236 5.30362C10.9332 5.30362 10.6729 5.43619 10.5427 5.70135L9.76186 7.15973L8.98094 5.70135C8.85081 5.43619 8.46034 5.17102 8.20006 5.30362C7.93977 5.43619 7.67946 5.70135 7.67946 5.96649V11.2697C7.67946 11.6674 7.93977 11.9326 8.33022 11.9326C8.72066 11.9326 8.98094 11.6674 8.98094 11.2697V8.75067L9.1111 8.88327C9.37138 9.28101 10.0221 9.28101 10.2825 8.88327L10.4126 8.75067V11.2697Z" transform="translate(9.67801 10.4601)" fill="white"></path></svg>
            </div>
            <div id="btn-inicial-tlg" class="tooltip-right" data-tooltip="' . esc_html__('Hablemos por Telegram', 'wa-leads') . '">
                <svg aria-hidden="true" class="ico_d " width="54" height="54" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#3E99D8"></circle><path d="M3.56917 -2.55497e-07L0 6.42978L7.5349 1.87535L3.56917 -2.55497e-07Z" transform="translate(13.9704 24.6145)" fill="#E0E0E0"></path><path d="M20.8862 0.133954C20.754 0 20.4897 0 20.2253 0L0.396574 8.03723C0.132191 8.17118 0 8.43909 0 8.707C0 8.97491 0.132191 9.24282 0.396574 9.37677L17.5814 17.414C17.7136 17.414 17.7136 17.414 17.8458 17.414C17.978 17.414 18.1102 17.414 18.1102 17.28C18.2424 17.1461 18.3746 17.0121 18.5068 16.7442L21.1506 0.669769C21.1506 0.535815 21.1506 0.267908 20.8862 0.133954Z" transform="translate(7.36069 10.9512)" fill="white"></path><path d="M13.8801 0L0 11.52V19.4233L3.70136 13.2614L13.8801 0Z" transform="translate(13.9704 11.6208)" fill="#F2F2F2"></path></svg>
            </div>
            <div id="btn-inicial-skp" class="tooltip-right" data-tooltip="' . esc_html__('Hablemos por Skype', 'wa-leads') . '">
                <svg aria-hidden="true" class="ico_d " width="54" height="54" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#03A9F4"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="M10.5634 0.777588C16.0406 0.777588 20.4747 5.05426 20.4747 10.4973C20.4747 11.1453 20.4747 11.9229 20.0834 12.5709C20.4747 13.2189 20.7355 14.1261 20.7355 15.0332C20.7355 18.1436 18.1273 20.7355 14.9974 20.7355C13.9541 20.7355 13.0412 20.4763 12.2587 20.0875C11.6067 20.2171 11.085 20.2171 10.433 20.2171C4.95566 20.2171 0.521637 15.9404 0.521637 10.4973C0.521637 9.84955 0.652008 9.20175 0.782349 8.55392L0.782471 8.55338C0.260834 7.77582 0 6.73904 0 5.70227C0 2.59195 2.60825 0 5.73813 0C6.91183 0 7.95514 0.388794 8.86801 0.907166C9.38965 0.777588 10.0417 0.777588 10.5634 0.777588ZM13.5627 16.718C14.4756 16.3292 15.1276 15.8108 15.6493 15.1628C16.1709 14.5149 16.3013 13.7373 16.0405 12.9597C16.0405 12.3117 15.9101 11.7933 15.6493 11.2749C15.3884 10.7565 14.9972 10.3677 14.4756 10.1086L14.4752 10.1084C13.9536 9.84924 13.4321 9.59012 12.7802 9.33096C12.5034 9.27597 12.2031 9.1976 11.8893 9.11572C11.4638 9.0047 11.0135 8.88718 10.5632 8.81259C10.1953 8.66635 9.86893 8.60263 9.60748 8.55157C9.40552 8.51215 9.24231 8.48029 9.12866 8.4238C8.86792 8.4238 8.60721 8.29428 8.34647 8.16473L8.34619 8.16461C8.08536 8.035 7.82455 7.90543 7.69412 7.77582C7.43329 7.64621 7.43329 7.51663 7.43329 7.25742C7.43329 6.86862 7.69412 6.60944 8.08536 6.35025C8.47659 6.09106 9.12866 5.96146 9.78073 5.96146C10.5632 5.96146 11.0848 6.09106 11.4761 6.35025C11.8673 6.60944 12.1281 6.86865 12.3889 7.38702C12.6497 7.77563 12.9104 8.03476 13.0408 8.16443L13.041 8.16461C13.3018 8.29419 13.5627 8.4238 13.9539 8.4238C14.3451 8.4238 14.7364 8.29419 14.9972 8.035C15.258 7.77582 15.3884 7.51663 15.3884 7.12784C15.3884 6.73904 15.3884 6.35025 15.1276 5.96146C15.0313 5.67429 14.7927 5.45782 14.5169 5.20764C14.4193 5.11908 14.317 5.02631 14.2147 4.92468C13.6931 4.6655 13.1714 4.40631 12.5194 4.14709C11.8673 4.01752 11.0848 3.88791 10.172 3.88791C9.12866 3.88791 8.08536 4.01752 7.30289 4.2767C6.39001 4.53589 5.73795 5.05429 5.34671 5.57266C4.95547 6.09106 4.69464 6.73904 4.69464 7.51663C4.69464 8.29419 4.95547 8.9422 5.34671 9.46057C5.73795 9.97897 6.39001 10.3677 7.04205 10.627C7.69412 10.8861 8.60703 11.1453 9.6503 11.4045C10.4328 11.5341 11.0848 11.6637 11.4761 11.7933C11.8673 11.9229 12.2585 12.0525 12.5194 12.3117C12.7802 12.5709 12.9106 12.8301 12.9106 13.2189C12.9106 13.6077 12.6498 13.9965 12.1281 14.3853C11.6065 14.774 10.9544 14.9036 10.172 14.9036C9.6503 14.9036 9.12866 14.774 8.73743 14.6444C8.47659 14.5149 8.21576 14.2556 7.95496 13.9965C7.91547 13.918 7.86407 13.8277 7.80792 13.7291C7.67859 13.5019 7.52423 13.2308 7.43329 12.9597C7.40817 12.9098 7.38306 12.855 7.35703 12.7983C7.24783 12.5604 7.12225 12.2867 6.91165 12.1821C6.65085 12.0525 6.39001 11.9229 5.99878 11.9229C5.60754 11.9229 5.21631 12.0525 4.95547 12.3117C4.69464 12.5709 4.56424 12.8301 4.56424 13.2189C4.56424 13.8669 4.82507 14.3853 5.21631 15.0332C5.73795 15.6812 6.25961 16.07 6.91165 16.4588C7.82455 16.9772 8.99823 17.2364 10.4328 17.2364C11.6065 17.2364 12.6498 17.1068 13.5627 16.718Z" transform="translate(9.07178 9.07178)" fill="white"></path></svg>
            </div>
            <div id="btn-inicial-msg" class="tooltip-right" data-tooltip="' . esc_html__('Hablemos por Messenger', 'wa-leads') . '">
                <svg width="54" height="54" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#1E88E5"></circle>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 9.63934C0 4.29861 4.68939 0 10.4209 0C16.1524 0 20.8418 4.29861 20.8418 9.63934C20.8418 14.98 16.1524 19.2787 10.4209 19.2787C9.37878 19.2787 8.33673 19.1484 7.42487 18.8879L3.90784 20.8418V17.1945C1.56311 15.3708 0 12.6353 0 9.63934ZM8.85779 10.1604L11.463 13.0261L17.1945 6.90384L12.1143 9.76959L9.37885 6.90384L3.64734 13.0261L8.85779 10.1604Z" transform="translate(9.01854 10.3146)" fill="white"></path></svg>
            </div>
            <div id="btn-inicial-tlf" class="tooltip-right" data-tooltip="' . esc_html__('Hablemos por Teléfono', 'wa-leads') . '">
                <svg class="ico_d " width="54" height="54" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(0deg);"><circle class="color-element" cx="19.4395" cy="19.4395" r="19.4395" fill="#03E78B"></circle><path d="M19.3929 14.9176C17.752 14.7684 16.2602 14.3209 14.7684 13.7242C14.0226 13.4259 13.1275 13.7242 12.8292 14.4701L11.7849 16.2602C8.65222 14.6193 6.11623 11.9341 4.47529 8.95057L6.41458 7.90634C7.16046 7.60799 7.45881 6.71293 7.16046 5.96705C6.56375 4.47529 6.11623 2.83435 5.96705 1.34259C5.96705 0.596704 5.22117 0 4.47529 0H0.745882C0.298353 0 5.69062e-07 0.298352 5.69062e-07 0.745881C5.69062e-07 3.72941 0.596704 6.71293 1.93929 9.3981C3.87858 13.575 7.30964 16.8569 11.3374 18.7962C14.0226 20.1388 17.0061 20.7355 19.9896 20.7355C20.4371 20.7355 20.7355 20.4371 20.7355 19.9896V16.4094C20.7355 15.5143 20.1388 14.9176 19.3929 14.9176Z" transform="translate(9.07179 9.07178)" fill="white"></path></svg>
            </div>
        </div>
        <div class="btn-mas-ws" id="btn-ws-op">
            <label for="btn-mas-ws" id="btn-chat" style="background-color: #0391fd;visibility:hidden;">
                <div style="background-color: #0391fd;border-radius:30px;">
                    <span style="width:24px;height:24px;font-size:16px;display: inline-flex;align-items: center;justify-content: center">
                    <img alt="WhatsApp" src="' . ARCHIVOturno . 'img/icono-blanco.png">
                    </span>
                    <span class="sw-label" style="justify-content: flex-start;text-overflow: ellipsis;white-space: nowrap;overflow: hidden;color:#fff;font-size:16px;">' . $formulario->boton . '</span>
                </div>
            </label>

            <label for="btn-mas-ws" id="btn-close">
                <svg viewBox="0 0 54 54" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="26" cy="26" rx="26" ry="26" fill="#000"></ellipse><rect width="27.1433" height="3.89857" rx="1.94928" transform="translate(18.35 15.6599) scale(0.998038 1.00196) rotate(45)" fill="white"></rect><rect width="27.1433" height="3.89857" rx="1.94928" transform="translate(37.5056 18.422) scale(0.998038 1.00196) rotate(135)" fill="white"></rect></svg>
            </label>
        </div>
    </div>

    <div class="sw-title-top" id="b" style="background-color: #0391fd;">
    <div class="sw-icon" style="color:#fff;font-size:24px;display:table;">

    </div>
    <i class="material-icons">close</i>
    </div>
    <!-- SUBMIT FORM -->
    <form class="sw-form" id="sw-form">
    <div class="sw-title">' . stripslashes($formulario->saludo) . '</div>
    <div class="sw-notice"';if ($formulario->iflisttext == 2) {$content .= ' style="display:none"';}
    $content .= '>
    ' . $formulario->pregunta . '
    </div>
    <div class="sw-input sw-input-container mdc-text-field mdc-text-field--outlined mdc-text-field--with-leading-icon">
    <div ';if ($formulario->iflisttext == 2) {$content .= ' style="display:none"';}
    $content .= '>';
    if ($formulario->iflisttext == 0) {
        $content .= '<select id="trabajo">';
        foreach ($opciones as $opcion) {
            if ($opcion != "") {
                $content .= '<option value="' . $opcion . '">' . $opcion . '</option>';
            }

        }
        $content .= '</select>';

    } else if ($formulario->iflisttext == 1) {
        $content .= '<textarea id="trabajo" autocomplete="off" maxlength="100"></textarea>';
    } else {
        $content .= '<input type="hidden" id="trabajo">';
    }

    $content .= '</div><label for="sw-name">' . esc_html__('¿Cuál es tu Nombre y Apellido?', 'wa-leads') . '</label>
    <input type="text" id="sw-name" name="name" required="" class="mdc-text-field__input" autocomplete="off">
    <div class="mdc-notched-outline__idle"></div></div>
    <div class="sw-input sw-input-container mdc-text-field mdc-text-field--outlined mdc-text-field--with-leading-icon" id="sw-phone-container">
    <label for="sw-phone">' . esc_html__('Teléfono Móvil', 'wa-leads') . '</label>
    <div style="display: flex">
    <select name="sw-country-code" required="" id="sw-country-code">
    <option value="376">AD (+376)</option>,<option value="971">AE (+971)</option>,<option value="93">AF (+93)</option>,<option value="1268">AG (+1268)</option>,<option value="1 264">AI (+1 264)</option>,<option value="355">AL (+355)</option>,<option value="374">AM (+374)</option>,<option value="599">AN (+599)</option>,<option value="244">AO (+244)</option>,<option value="54">AR (+54)</option>,<option value="1 684">AS (+1 684)</option>,<option value="43">AT (+43)</option>,<option value="61">AU (+61)</option>,<option value="297">AW (+297)</option>,<option value="994">AZ (+994)</option>,<option value="387">BA (+387)</option>,<option value="1 246">BB (+1 246)</option>,<option value="880">BD (+880)</option>,<option value="32">BE (+32)</option>,<option value="226">BF (+226)</option>,<option value="359">BG (+359)</option>,<option value="973">BH (+973)</option>,<option value="257">BI (+257)</option>,<option value="229">BJ (+229)</option>,<option value="590">BL (+590)</option>,<option value="1 441">BM (+1 441)</option>,<option value="673">BN (+673)</option>,<option value="591">BO (+591)</option>,<option value="55">BR (+55)</option>,<option value="1 242">BS (+1 242)</option>,<option value="975">BT (+975)</option>,<option value="267">BW (+267)</option>,<option value="375">BY (+375)</option>,<option value="501">BZ (+501)</option>,<option value="1">CA (+1)</option>,<option value="61">CC (+61)</option>,<option value="243">CD (+243)</option>,<option value="236">CF (+236)</option>,<option value="242">CG (+242)</option>,<option value="41">CH (+41)</option>,<option value="225">CI (+225)</option>,<option value="682">CK (+682)</option>,<option value="56">CL (+56)</option>,<option value="237">CM (+237)</option>,<option value="86">CN (+86)</option>,<option value="57">CO (+57)</option>,<option value="506">CR (+506)</option>,<option value="53">CU (+53)</option>,<option value="238">CV (+238)</option>,<option value="61">CX (+61)</option>,<option value="537">CY (+537)</option>,<option value="420">CZ (+420)</option>,<option value="49">DE (+49)</option>,<option value="253">DJ (+253)</option>,<option value="45">DK (+45)</option>,<option value="1 767">DM (+1 767)</option>,<option value="1 849">DO (+1 849)</option>,<option value="213">DZ (+213)</option>,<option value="593">EC (+593)</option>,<option value="372">EE (+372)</option>,<option value="20">EG (+20)</option>,<option value="291">ER (+291)</option>,<option value="34">ES (+34)</option>,<option value="251">ET (+251)</option>,<option value="358">FI (+358)</option>,<option value="679">FJ (+679)</option>,<option value="500">FK (+500)</option>,<option value="691">FM (+691)</option>,<option value="298">FO (+298)</option>,<option value="33">FR (+33)</option>,<option value="241">GA (+241)</option>,<option value="44">GB (+44)</option>,<option value="1 473">GD (+1 473)</option>,<option value="995">GE (+995)</option>,<option value="594">GF (+594)</option>,<option value="44">GG (+44)</option>,<option value="233">GH (+233)</option>,<option value="350">GI (+350)</option>,<option value="299">GL (+299)</option>,<option value="220">GM (+220)</option>,<option value="224">GN (+224)</option>,<option value="590">GP (+590)</option>,<option value="240">GQ (+240)</option>,<option value="30">GR (+30)</option>,<option value="500">GS (+500)</option>,<option value="502">GT (+502)</option>,<option value="1 671">GU (+1 671)</option>,<option value="245">GW (+245)</option>,<option value="592">GY (+592)</option>,<option value="852">HK (+852)</option>,<option value="504">HN (+504)</option>,<option value="385">HR (+385)</option>,<option value="509">HT (+509)</option>,<option value="36">HU (+36)</option>,<option value="62">ID (+62)</option>,<option value="353">IE (+353)</option>,<option value="972">IL (+972)</option>,<option value="972">IL (+972)</option>,<option value="44">IM (+44)</option>,<option value="91">IN (+91)</option>,<option value="246">IO (+246)</option>,<option value="964">IQ (+964)</option>,<option value="98">IR (+98)</option>,<option value="354">IS (+354)</option>,<option value="39">IT (+39)</option>,<option value="44">JE (+44)</option>,<option value="1 876">JM (+1 876)</option>,<option value="962">JO (+962)</option>,<option value="81">JP (+81)</option>,<option value="254">KE (+254)</option>,<option value="996">KG (+996)</option>,<option value="855">KH (+855)</option>,<option value="686">KI (+686)</option>,<option value="269">KM (+269)</option>,<option value="1 869">KN (+1 869)</option>,<option value="850">KP (+850)</option>,<option value="82">KR (+82)</option>,<option value="965">KW (+965)</option>,<option value=" 345">KY (+ 345)</option>,<option value="7 7">KZ (+7 7)</option>,<option value="856">LA (+856)</option>,<option value="961">LB (+961)</option>,<option value="1 758">LC (+1 758)</option>,<option value="423">LI (+423)</option>,<option value="94">LK (+94)</option>,<option value="231">LR (+231)</option>,<option value="266">LS (+266)</option>,<option value="370">LT (+370)</option>,<option value="352">LU (+352)</option>,<option value="371">LV (+371)</option>,<option value="218">LY (+218)</option>,<option value="212">MA (+212)</option>,<option value="377">MC (+377)</option>,<option value="373">MD (+373)</option>,<option value="382">ME (+382)</option>,<option value="590">MF (+590)</option>,<option value="261">MG (+261)</option>,<option value="692">MH (+692)</option>,<option value="389">MK (+389)</option>,<option value="223">ML (+223)</option>,<option value="95">MM (+95)</option>,<option value="976">MN (+976)</option>,<option value="853">MO (+853)</option>,<option value="1 670">MP (+1 670)</option>,<option value="596">MQ (+596)</option>,<option value="222">MR (+222)</option>,<option value="1664">MS (+1664)</option>,<option value="356">MT (+356)</option>,<option value="230">MU (+230)</option>,<option value="960">MV (+960)</option>,<option value="265">MW (+265)</option>,<option value="52">MX (+52)</option>,<option value="60">MY (+60)</option>,<option value="258">MZ (+258)</option>,<option value="264">NA (+264)</option>,<option value="687">NC (+687)</option>,<option value="227">NE (+227)</option>,<option value="672">NF (+672)</option>,<option value="234">NG (+234)</option>,<option value="505">NI (+505)</option>,<option value="31">NL (+31)</option>,<option value="47">NO (+47)</option>,<option value="977">NP (+977)</option>,<option value="674">NR (+674)</option>,<option value="683">NU (+683)</option>,<option value="64">NZ (+64)</option>,<option value="968">OM (+968)</option>,<option value="507">PA (+507)</option>,<option value="51">PE (+51)</option>,<option value="689">PF (+689)</option>,<option value="675">PG (+675)</option>,<option value="63">PH (+63)</option>,<option value="92">PK (+92)</option>,<option value="48">PL (+48)</option>,<option value="508">PM (+508)</option>,<option value="872">PN (+872)</option>,<option value="1 939">PR (+1 939)</option>,<option value="970">PS (+970)</option>,<option value="351">PT (+351)</option>,<option value="680">PW (+680)</option>,<option value="595">PY (+595)</option>,<option value="974">QA (+974)</option>,<option value="262">RE (+262)</option>,<option value="40">RO (+40)</option>,<option value="381">RS (+381)</option>,<option value="7">RU (+7)</option>,<option value="250">RW (+250)</option>,<option value="966">SA (+966)</option>,<option value="677">SB (+677)</option>,<option value="248">SC (+248)</option>,<option value="249">SD (+249)</option>,<option value="46">SE (+46)</option>,<option value="65">SG (+65)</option>,<option value="290">SH (+290)</option>,<option value="386">SI (+386)</option>,<option value="47">SJ (+47)</option>,<option value="421">SK (+421)</option>,<option value="232">SL (+232)</option>,<option value="378">SM (+378)</option>,<option value="221">SN (+221)</option>,<option value="252">SO (+252)</option>,<option value="597">SR (+597)</option>,<option value="239">ST (+239)</option>,<option value="503">SV (+503)</option>,<option value="963">SY (+963)</option>,<option value="268">SZ (+268)</option>,<option value="1 649">TC (+1 649)</option>,<option value="235">TD (+235)</option>,<option value="228">TG (+228)</option>,<option value="66">TH (+66)</option>,<option value="992">TJ (+992)</option>,<option value="690">TK (+690)</option>,<option value="670">TL (+670)</option>,<option value="993">TM (+993)</option>,<option value="216">TN (+216)</option>,<option value="676">TO (+676)</option>,<option value="90">TR (+90)</option>,<option value="1 868">TT (+1 868)</option>,<option value="688">TV (+688)</option>,<option value="886">TW (+886)</option>,<option value="255">TZ (+255)</option>,<option value="380">UA (+380)</option>,<option value="256">UG (+256)</option>,<option value="1" selected>US (+1)</option>,<option value="598">UY (+598)</option>,<option value="998">UZ (+998)</option>,<option value="379">VA (+379)</option>,<option value="1 784">VC (+1 784)</option>,<option value="58">VE (+58)</option>,<option value="1 284">VG (+1 284)</option>,<option value="1 340">VI (+1 340)</option>,<option value="84">VN (+84)</option>,<option value="678">VU (+678)</option>,<option value="681">WF (+681)</option>,<option value="685">WS (+685)</option>,<option value="967">YE (+967)</option>,<option value="262">YT (+262)</option>,<option value="27">ZA (+27)</option>,<option value="260">ZM (+260)</option>,<option value="263">ZW (+263)</option>
    </select>
    <input type="tel" id="sw-phone" name="phone" required="" minlength="6" maxlength="14" onkeyUp="return ValNumero(this);" class="mdc-text-field__input" autocomplete="off">
    </div>';
    if ($formulario->ifcorreo == 1) {
        $content .= '<label for="sw-correo">' . esc_html__('¿Cuál es tu correo?', 'wa-leads') . '</label>
        <input type="email" id="sw-correo" name="correo" required="" class="mdc-text-field__input" autocomplete="off">';
    }

    $content .= '
    </div>
    <div class="sw-input sw-input-container mdc-text-field mdc-text-field--outlined mdc-text-field--with-leading-icon">

    <div class="mdc-notched-outline__idle"></div></div>
    <input type="hidden" name="ifurl" id="ifurl">
    <input type="hidden" name="ifcookies" id="ifcookies">
    <input type="hidden" name="codereceptor" id="codereceptor">
    <input type="hidden" name="numreceptor" id="numreceptor">
    <input type="hidden" name="correoreceptor" id="correoreceptor">
    <input type="hidden" name="code" id="code" value="' . $code . '">
    <input type="hidden" name="namereceptor" id="namereceptor">
    <input type="hidden" name="redsocial" id="redsocial">
    <input type="hidden" name="pais" id="pais" value="' . $pais . ', ' . $region . '">
    <input type="hidden" name="url" id="url">
    <input type="hidden" name="linkmsg" id="inputmsg">
    <input type="hidden" name="usertlg" id="inputTlg">
    <input type="hidden" name="userskp" id="inputSkp">
    <input type="hidden" name="numsms" id="inputSms">
    <input type="hidden" name="numtlf" id="inputTlf">
    <div class="sw-form-submit">
        <a type="submit" href="" id="chatwhatsapp" style="display:none !important" target="_blank">' . esc_html__('Iniciar Chat', 'wa-leads') . '</a>
        <a type="submit" href="" id="chatsms" style="display:none !important" target="_blank">' . esc_html__('Iniciar Mensaje', 'wa-leads') . '</a>
        <a type="submit" href="" id="chatmsg" style="display:none !important" target="_blank">' . esc_html__('Iniciar Chat', 'wa-leads') . '</a>
        <a type="submit" href="" id="chattlf" style="display:none !important" target="_blank">' . esc_html__('Llamar Ahora', 'wa-leads') . '</a>
        <a type="submit" href="" id="chattlg" style="display:none !important" target="_blank">' . esc_html__('Iniciar Chat', 'wa-leads') . '</a>
        <a type="submit" href="" id="chatskp" style="display:none !important" target="_blank">' . esc_html__('Iniciar Chat', 'wa-leads') . '</a>
    </div>
    </form>
    </div>
    </div>
    <script>
    function Solo_Numerico(variable){
        Numer=parseInt(variable);
        if (isNaN(Numer)){
            return "";
        }
        return Numer;
    }
    function ValNumero(Control){
        Control.value=Solo_Numerico(Control.value);
    }
    jQuery("#code option").each(function() {
        if(this.text.substr(0,2) == "'.$code.'"){
            this.setAttribute("selected", "true");
        }
    });
    </script>
    ';
        
    return $content;
}
add_filter('the_content', 'add_text_to_content');
function turnos()
{
    require_once DOCUMENTOturno . 'admin/conteo_turnos.php';

}
add_action('wp_ajax_enviar', 'enviar');
add_action('wp_ajax_nopriv_enviar', 'enviar');
function enviar()
{

    require_once DOCUMENTOturno . 'admin/enviaRecibe.php';

}
register_activation_hook(__FILE__, 'db_turnos');
function receptor_waleads()
{
    require_once DOCUMENTOturno . 'admin/receptorwaleads.php';
}
add_shortcode('receptor_waleads', 'receptor_waleads');

function panel_turnos()
{
    add_menu_page('Configurar los turnos', 'WaLeads', 'manage_options', DOCUMENTOturno . 'admin/control.php');
}

function usuarios_contactos()
{
    require_once DOCUMENTOturno . 'login/index.php';
}
add_shortcode('usuarios_contactos', 'usuarios_contactos');
add_action('admin_menu', 'panel_turnos');