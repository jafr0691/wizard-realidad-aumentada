<?php
// If uninstall is not called from WordPress, exit
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit();
} 
 
// Drop a custom db table
global $wpdb;
$conteo   = $wpdb->prefix . 'sw_conteo';
$agente   = $wpdb->prefix . 'sw_agente';
$jornada  = $wpdb->prefix . 'sw_jornada';
$formulario  = $wpdb->prefix . 'sw_formulario';
$contactos   = $wpdb->prefix . 'sw_contactos_whatsapp';
$phpmailer  = $wpdb->prefix . 'sw_phpmailer';
$mailchimp = $wpdb->prefix . 'sw_mailchimp';

$wpdb->query( "DROP TABLE IF EXISTS {$conteo}" );
$wpdb->query( "DROP TABLE IF EXISTS {$agente}" );
$wpdb->query( "DROP TABLE IF EXISTS {$jornada}" );
$wpdb->query( "DROP TABLE IF EXISTS {$formulario}" );
$wpdb->query( "DROP TABLE IF EXISTS {$contactos}" );
$wpdb->query( "DROP TABLE IF EXISTS {$phpmailer}" );
$wpdb->query( "DROP TABLE IF EXISTS {$mailchimp}" );

 