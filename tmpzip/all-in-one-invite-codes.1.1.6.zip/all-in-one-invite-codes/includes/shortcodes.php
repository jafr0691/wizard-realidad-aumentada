<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }


add_shortcode( 'all_in_one_invite_codes_list_codes_by_user', 'all_in_one_invite_codes_list_codes' );
/**
 * Create the list of codes for the user with a option to sent invites to new users.
 *
 * @param $attr
 *
 * @return string
 */
function all_in_one_invite_codes_list_codes( $attr ) {

	AllinOneInviteCodes::setNeedAssets( true, 'all-in-one-invite-codes' );
	ob_start();

	// If the user is not logged in display a login form
	if ( ! is_user_logged_in() ) {
		echo '<p>' . esc_html__( 'Please login to manage your invite codes.', 'all-in-one-invite-codes' ) . '</p>';
		wp_login_form();

		return '';
	}

	// Add the js in the shortcode so we can use this more easy as Block in a later process. ?>
	<script>
		<?php echo 'var ajaxurl = "' . esc_js( admin_url( 'admin-ajax.php' ) ) . '";'; ?>

	</script>

	<?php

	// Get the user invite codes
	$args = array(
		'author'         => get_current_user_id(),
		'posts_per_page' => - 1,
		'post_type'      => 'tk_invite_codes', // you can use also 'any'
	);

	$the_query = new WP_Query( $args );

	if ( $the_query->have_posts() ) {
		echo '<ul>';
		while ( $the_query->have_posts() ) :
			$the_query->the_post();
			$all_in_one_invite_codes_options = get_post_meta( get_the_ID(), 'all_in_one_invite_codes_options', true );
			$email                           = empty( $all_in_one_invite_codes_options['email'] ) ? '' : $all_in_one_invite_codes_options['email'];
			$code_amount                     = isset( $all_in_one_invite_codes_options['generate_codes'] ) ? $all_in_one_invite_codes_options['generate_codes'] : 1;
			$is_multiple_use                 = isset( $all_in_one_invite_codes_options['multiple_use'] ) ? '(' . $code_amount . ')' : '';

			// If invite code is Multiple Use then run the multiple invite codes  logic and valdiations
			if ( isset( $all_in_one_invite_codes_options['multiple_use'] ) ) {
				echo '<li>';
				echo '<div class="aioic-top">';
				echo '<div class="aioic-info">';
				echo '<div><p>Code: ';
				echo esc_html( get_post_meta( get_the_ID(), 'tk_all_in_one_invite_code', true ) ) . ' ' . esc_html( $is_multiple_use );
				echo '</p></div>';
				echo '<div><p>Status: ';
				$status = all_in_one_invite_codes_get_status( get_the_ID() );
				echo esc_html( $status );
				echo '</p></div>';
				echo '</div>';
				echo '<div class="aioic-right">';
				if ( $code_amount > 0 ) {
					echo esc_html__( 'Give this Invite Code to friends, they can use it to register on the site', 'all_in_one_invite_codes' );
				} else {
					echo esc_html__( 'Invite Code limit reached', 'all_in_one_invite_codes' );
				}
				echo '</div>';
				echo '</div>';

				if ( $code_amount > 0 ) {
					echo '<div class="aioic-form" id="tk_all_in_one_invite_code_open_invite_form_id_' . get_the_ID() . '"></div>';
				}

				echo '</li>';

			} else {
				echo '<li>';
				echo '<div class="aioic-top">';
				echo '<div class="aioic-info">';
					echo '<div><p>Code: ';
					echo esc_html( get_post_meta( get_the_ID(), 'tk_all_in_one_invite_code', true ) );
					echo '</p></div>';
					echo '<div><p>Status: ';
					$status = all_in_one_invite_codes_get_status( get_the_ID() );
					echo esc_html( $status );
					echo '</p></div>';
				echo '</div>';

				echo '<div class="aioic-right">';
				if ( empty( $email ) && $status == 'Active' ) {
					echo '<p><a class="button" data-code_id="' . get_the_ID() . '" id="tk_all_in_one_invite_code_open_invite_form" href="#">Invite a Friend Now</a></p>';
				} else {
					echo esc_html__( 'Invite was sent to: ', 'all_in_one_invite_codes' ) . esc_html( $email );
				}
				echo '</div>';
				echo '</div>';

				if ( empty( $email ) && $status == 'Active' ) {
					echo '<div class="aioic-form" id="tk_all_in_one_invite_code_open_invite_form_id_' . get_the_ID() . '"></div>';
				}

				echo '</li>';
			}

		endwhile;
		echo '</ul>';

		$all_in_one_invite_codes_mail_templates = get_option( 'all_in_one_invite_codes_mail_templates' )

		?>

		<div style="display: none" id="tk_all_in_one_invite_code_send_invite_form">
			<p><span>To: </span><input type="email" id="tk_all_in_one_invite_code_send_invite_to" value=""><span id="tk_all_in_one_invite_code_send_invite_to_error"></span></p>
			<p><span>Subject: </span><input type="text" id="tk_all_in_one_invite_code_send_invite_subject" value="<?php echo empty( $all_in_one_invite_codes_mail_templates['subject'] ) ? '' : esc_html( $all_in_one_invite_codes_mail_templates['subject'] ); ?>"></p>
			<p><span>Message Text:</span><textarea cols="70" rows="5" id="tk_all_in_one_invite_code_send_invite_message_text"><?php echo empty( $all_in_one_invite_codes_mail_templates['message_text'] ) ? '' : esc_html( $all_in_one_invite_codes_mail_templates['message_text'] ); ?></textarea></p>
			<a href="#" data-send_code_id="0" id="tk_all_in_one_invite_code_send_invite_submit" class="button">Send invitation</a>
		</div>

		<?php
	}

	wp_reset_postdata();

	$tmp = ob_get_clean();

	return $tmp;
}

add_shortcode( 'all_in_one_invite_codes_invited_by_user_filter', 'all_in_one_invite_codes_invited_by_user' );
/**
 * Create a list of invites by user
 *
 * @param $attr
 *
 * @return string
 */
function all_in_one_invite_codes_invited_by_user( $attr ) {

	ob_start();
	$filter_id = isset( $attr['userid'] ) ? $attr['userid'] : get_current_user_id();

	$user = get_user_by( 'ID', $filter_id );
	if ( $user->ID ) {
		$email     = $user->user_email;
		$args      = array(

			'posts_per_page' => - 1,
			'post_type'      => 'tk_invite_codes', // you can use also 'any'
			'orderby'        => 'post_author',
			'order'          => 'ASC',
		);
		$the_query = new WP_Query( $args );

		if ( $the_query->have_posts() ) {

			while ( $the_query->have_posts() ) :
				$the_query->the_post();
				$all_in_one_invite_codes_options = get_post_meta( get_the_ID(), 'all_in_one_invite_codes_options', true );
				$email_needle                    = empty( $all_in_one_invite_codes_options['email'] ) ? '' : $all_in_one_invite_codes_options['email'];

				if ( $email == $email_needle ) {
					$author_id  = (int) $the_query->post->post_author;
					$inviter    = get_user_by( 'ID', $author_id );
					$invited_by = $inviter->display_name;
					$post_date  = $the_query->post->post_date;

					$formattedDate = date( DATE_COOKIE, strtotime( $post_date ) );
					echo sprintf( esc_html__( 'The user : %1$s was invited by %2$s on  ', 'all_in_one_invite_codes' ), esc_html( $user->display_name ), esc_html( $invited_by ) ) . esc_html( $formattedDate );
					wp_reset_postdata();

					$tmp = ob_get_clean();

					return $tmp;

				}

			endwhile;
		}
		echo sprintf( esc_html__( 'The user : %s was not invited by anyone', 'all_in_one_invite_codes' ), esc_html( $user->display_name ) );
		wp_reset_postdata();

		$tmp = ob_get_clean();

		return $tmp;
	}
	echo esc_html__( 'No user was found with the ID : ', 'all_in_one_invite_codes' ) . esc_html( $filter_id );
	wp_reset_postdata();

	$tmp = ob_get_clean();

	return $tmp;

}

add_shortcode( 'all_in_one_invite_codes_list_codes_not_assigend', 'all_in_one_invite_codes_list_codes_not_assigend' );
/**
 * Create a list of codes not assigned to any user
 *
 * @param $attr
 *
 * @return string
 */
function all_in_one_invite_codes_list_codes_not_assigend( $attr ) {
	global $wpdb;
	AllinOneInviteCodes::setNeedAssets( true, 'all-in-one-invite-codes' );
	ob_start();
	// Add the js in the shortcode so we can use this more easy as Block in a later process.
	?>
	<script>
		<?php echo 'var ajaxurl = "' . esc_js( admin_url( 'admin-ajax.php' ) ) . '";'; ?>
	</script>
	<?php
	$generated_codes = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type = %s AND post_status = %s", 'tk_invite_codes', 'publish' ) );
	if ( ! empty( $generated_codes ) ) {
		$no_codes_unassigned_found = true;
		foreach ( $generated_codes as $unassigned_codes ) {
			$single_invite_code = get_post_meta( (int) $unassigned_codes, 'all_in_one_invite_codes_options', true );
			if ( empty( $single_invite_code['email'] ) ) {
				$no_codes_unassigned_found = false;
				echo '<ul>
						<li>
							<div class="aioic-top">
									<div class="aioic-info">
										<div><strong>Code:</strong> ' . esc_html( get_post_meta( (int) $unassigned_codes, 'tk_all_in_one_invite_code', true ) );
				echo '					</div>
									</div>
							</div>
							<div class="aioic-right"></div>
						</li>
					</ul>';
			}
		}
		if ( $no_codes_unassigned_found ) {
			echo 'Sorry, no unassigned invite codes were found.';
		}
	}
	$wpdb->flush();
	$tmp = ob_get_clean();
	return $tmp;
}