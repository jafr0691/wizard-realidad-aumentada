<div class="container">
    <section class="blog-index">
        <div class="row">
            <div class="col s12 m6">
                <div class="carousel-container">
                    <h2>Blog</h2>
                    <div class="carousel-fade index-blog-carousel">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                            <a href="https://placeholder.com">
                                <div class="item-text">
                                    <span class="item-date">14nov</span>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </a>
                        </div>
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                            <a href="https://placeholder.com">
                                <div class="item-text">
                                    <span class="item-date">14nov</span>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </a>
                        </div>
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                            <a href="https://placeholder.com">
                                <div class="item-text">
                                    <span class="item-date">14nov</span>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </a>
                        </div>
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                            <a href="https://placeholder.com">
                                <div class="item-text">
                                    <span class="item-date">14nov</span>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </a>
                        </div>
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                            <a href="https://placeholder.com">
                                <div class="item-text">
                                    <span class="item-date">14nov</span>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </a>
                        </div>
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                            <a href="https://placeholder.com">
                                <div class="item-text">
                                    <span class="item-date">14nov</span>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col s12 m6">
                <div class="more-watch-container">
                    <div class="publicity">
                    </div>
                    <div class="more-watch">
                        <div class="title-section">
                            <h2 class="left">lo más visto</h2>
                <span class="right">
                  <a href="#" class="link">
                      Ver los 100 autobuses más vistos
                      <i class="f-circle-right"></i>
                  </a>
                </span>
                        </div>
                        <div class="bus-section">
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6">
                                <div class="bus-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                    <div class="hover">
                                        <a href="#">
                                            <i class="material-icons">&#xE000;</i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="mural">
        <div class="row">
            <div class="col s12 m2 mural-title">
                <div class="title-section" style="background-image: url('assets/img/mural-bg.jpg')">
                    <div class="hover">
                        <h2>Mural</h2>
                    </div>
                </div>
            </div>
            <div class="col s12 m10">
                <span><a href="#" class="link">Ver muro completo <i class="f-circle-right"></i></a></span>
                <div class="multiple-items mural-carousel">
                    <a href="https://placeholder.com">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                        </div>
                    </a>
                    <a href="https://placeholder.com">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                        </div>
                    </a>
                    <a href="https://placeholder.com">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                        </div>
                    </a>
                    <a href="https://placeholder.com">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                        </div>
                    </a>
                    <a href="https://placeholder.com">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                        </div>
                    </a>
                    <a href="https://placeholder.com">
                        <div class="item" style="background-image: url('http://via.placeholder.com/350x150')">
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <div class="publicity-large publicity"></div>
</div>

<section class="pictures-comments" style="background-image: url('assets/img/new-events-bg.jpg')">
    <div class="background-color">
        <div class="container">
            <div class="row">
                <div class="col s12 m7">
                    <div class="event-pictures">
                        <div class="title-section">
                            <h2>Fotos en enventos</h2>
                        </div>
                        <div class="col s12 m6">
                            <div class="img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                <div class="hashtag">
                                    <span>#lorem</span>
                                </div>
                            </div>
                        </div>
                        <div class="col s12 m6">
                            <div class="sub-section">
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col s12 m6">
                                    <div class="sub-img-container" style="background-image: url('http://via.placeholder.com/350x150')">
                                        <div class="hashtag">
                                            <span>#lorem</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col s12 m5">
                    <div class="comments-section">
                        <div class="title-section">
                            <h2>Ultímos Comentários</h2>
                        </div>
                        <div class="comments">
                            <div class="row comment">
                                <div class="col s12 m2 no-padding">
                                    <div class="comment-img">
                                        <img src="http://via.placeholder.com/350x150" alt="http://via.placeholder.com/350x150">
                                    </div>
                                </div>
                                <div class="col s12 m10">
                                    <div class="comment-info">
                                        <div class="row">
                                            <span class="left username">Jhoel Ferreira</span>
                                            <span class="right date">01/01/2017 - 13:08:45</span>
                                        </div>
                                        <div class="row">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row comment">
                                <div class="col s12 m2 no-padding">
                                    <div class="comment-img">
                                        <img src="http://via.placeholder.com/350x150" alt="http://via.placeholder.com/350x150">
                                    </div>
                                </div>
                                <div class="col s12 m10">
                                    <div class="comment-info">
                                        <div class="row">
                                            <span class="left username">Jhoel Ferreira</span>
                                            <span class="right date">01/01/2017 - 13:08:45</span>
                                        </div>
                                        <div class="row">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row comment">
                                <div class="col s12 m2 no-padding">
                                    <div class="comment-img">
                                        <img src="http://via.placeholder.com/350x150" alt="http://via.placeholder.com/350x150">
                                    </div>
                                </div>
                                <div class="col s12 m10">
                                    <div class="comment-info">
                                        <div class="row">
                                            <span class="left username">Jhoel Ferreira</span>
                                            <span class="right date">01/01/2017 - 13:08:45</span>
                                        </div>
                                        <div class="row">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row comment">
                                <div class="col s12 m2 no-padding">
                                    <div class="comment-img">
                                        <img src="http://via.placeholder.com/350x150" alt="http://via.placeholder.com/350x150">
                                    </div>
                                </div>
                                <div class="col s12 m10">
                                    <div class="comment-info">
                                        <div class="row">
                                            <span class="left username">Jhoel Ferreira</span>
                                            <span class="right date">01/01/2017 - 13:08:45</span>
                                        </div>
                                        <div class="row">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="row">
        <div class="col s12 m4">
            <div class="publicity publicity-big"></div>
        </div>
        <div class="col s12 m4">
            <div class="publicity publicity-big"></div>
        </div>
        <div class="col s12 m4">
            <div class="publicity publicity-big"></div>
        </div>
    </div>
</div>

<div class="container">
    <div class="links-section">
        <div class="title-section">
            <h2>Los maś populares</h2>
        </div>
        <ul class="links-container">
            <li class="links">
                <div class="links-title">
                    <h3>galerías</h3>
                </div>
                <ul>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                </ul>
            </li>
            <li class="links">
                <div class="links-title">
                    <h3>empresas</h3>
                </div>
                <ul>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                </ul>
            </li>
            <li class="links">
                <div class="links-title">
                    <h3>cuerpos</h3>
                </div>
                <ul>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                </ul>
            </li>
            <li class="links">
                <div class="links-title">
                    <h3>chasis</h3>
                </div>
                <ul>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                </ul>
            </li>
            <li class="links">
                <div class="links-title">
                    <h3>ciudades</h3>
                </div>
                <ul>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                    <li><a href="#">lorem (9999)</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="info-blocks">
        <div class="row">
            <div class="col s12 m4">
                <div class="title-section">
                    <h2>acerca de infobus</h2>
                </div>
                <div class="info-block">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                        nisi ut aliquip ex ea commodo consequat.
                    </p>
                </div>
            </div>
            <div class="col s12 m4">
                <div class="title-section">
                    <h2>conozca el hobby</h2>
                </div>
                <div class="info-block">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                        nisi ut aliquip ex ea commodo consequat.
                    </p>
                </div>
            </div>
            <div class="col s12 m4">
                <div class="title-section">
                    <h2>estadísticas</h2>
                </div>
                <div class="info-block stadistics-block">
                    <span>Tenemos más de</span>
                    <span class="number">9.999.999</span>
                    <div class="col s12 m4 no-padding">
                        <div class="option">
                            <span class="title">Miembros</span>
                            <span class="quantity">0000</span>
                        </div>
                    </div>
                    <div class="col s12 m4 no-padding">
                        <div class="option">
                            <span class="title">Galerias</span>
                            <span class="quantity">0000</span>
                        </div>
                    </div>
                    <div class="col s12 m4 no-padding">
                        <div class="option">
                            <span class="title">Fotos</span>
                            <span class="quantity">0000</span>
                        </div>
                    </div>
                    <div class="col s12 m4 no-padding">
                        <div class="option">
                            <span class="title">Fotos HD</span>
                            <span class="quantity">0000</span>
                        </div>
                    </div>
                    <div class="col s12 m4 no-padding">
                        <div class="option">
                            <span class="title">Empresas</span>
                            <span class="quantity">0000</span>
                        </div>
                    </div>
                    <div class="col s12 m4 no-padding">
                        <div class="option">
                <span class="title">Comentarios

                </span>
                            <span class="quantity">0000</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>