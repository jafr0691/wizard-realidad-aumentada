<form>
    <div>
        <div class="input-field">
            <input id="email" type="text" placeholder="Ingresa tu Email">
            <button type="submit" name="submit" class="submit">Subcribeme</button>
        </div>
    </div>
</form>